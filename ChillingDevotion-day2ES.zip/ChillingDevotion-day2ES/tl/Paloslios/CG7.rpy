


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



translate Paloslios strings:

    # game/script.rpy:980
    old "Look around the room"
    new "Mira alrededor de la habitación"

    # game/script.rpy:980
    old "Examine inventory"
    new "Examinar el inventario"


translate Paloslios strings:

    # game/CH1.rpy:80
    old "Lonely"
    new "solitario"

    # game/CH1.rpy:80
    old "Relaxed"
    new "Relajado"

    # game/CH1.rpy:80
    old "Nervous"
    new "Nervioso"

    # game/CH1.rpy:80
    old "Excited"
    new "emocionado"

    # game/CH1.rpy:80
    old "Unsure"
    new "Inseguro"

    # game/CH1.rpy:184
    old "Tea"
    new "té"

    # game/CH1.rpy:184
    old "Coffee"
    new "cafe"

    # game/CH1.rpy:184
    old "Hot cocoa"
    new "cacao caliente"

    # game/CH1.rpy:228
    old "Open the door"
    new "abre la puerta"

    # game/CH1.rpy:228
    old "\"Who it is?\""
    new "\"¿Quién es?\""

    # game/CH1.rpy:228
    old "..."
    new "..."

    # game/CH1.rpy:273
    old "\"...Hi, can I help you?\""
    new "\"...Hola, ¿puedo ayudarte?\""

    # game/CH1.rpy:273
    old "\"Who are you?\""
    new "\"¿Quién eres?\""
    # game/CH1.rpy:273
    old "\"...\""
    new "\"...\""

    # game/CH1.rpy:290
    old "Freeze"
    new "congelar"

    # game/CH1.rpy:290
    old "Attack"
    new "ataque"

    # game/CH1.rpy:290
    old "Run"
    new "correr"

    old "What is your name?"
    new "¿Cuál es tu nombre?"

    # game/CH1.rpy:332
    old "\"Please, let me go...\""
    new "\"Por favor, déjame ir...\""

    # game/CH1.rpy:332
    old "Struggle"
    new "lucha"

    # game/CH1.rpy:432
    old "Tell him your name"
    new "Dile tu nombre"

    # game/CH1.rpy:432
    old "'I don't want to tell you my name.'"
    new "\"No quiero decirte mi nombre\"."

    # game/CH1.rpy:454
    old "Sit down"
    new "siéntate"

    # game/CH1.rpy:454
    old "'I don't want to sit.'"
    new "\"No quiero sentarme\"."

    # game/CH1.rpy:454
    old "'I'm going to leave now.'"
    new "\"Me voy a ir ahora\"."

    # game/CH1.rpy:466
    old "'It's okay. It's all just a misunderstanding.'"
    new "'Está bien. Todo es sólo un malentendido."

    # game/CH1.rpy:466
    old "'You really scared me!'"
    new "'¡Realmente me asustaste!'"

    # game/CH1.rpy:466
    old "'I'm so sorry, I must have gotten turned around in the snow.'"
    new "\"Lo siento mucho, debí haberme dado vuelta en la nieve\"."

    # game/CH1.rpy:466
    old "'Why did you knock on your own door and didn't say anything eariler?'"
    new "—¿Por qué llamaste a tu puerta y no dijiste nada antes?"

    # game/CH1.rpy:498
    old "'I think I should leave now.'"
    new "\"Creo que debería irme ahora\"."

    # game/CH1.rpy:589
    old "'I guess I don't have a choice...'"
    new "'Supongo que no tengo otra opción...'"

    # game/CH1.rpy:589
    old "'Thank you so much.'"
    new "'Muchas gracias.'"

    # game/CH1.rpy:589
    old "'I'm not staying here.'"
    new "\"No me quedaré aquí.\\"

    # game/CH1.rpy:634
    old "Sure, thanks."
    new "Claro, gracias."

    # game/CH1.rpy:634
    old "Nevermind, I just want to go to my room for today."
    new "No importa, solo quiero ir a mi habitación por hoy."

    # game/CH1.rpy:690
    old "Ask him some questions"
    new "Hazle algunas preguntas"

    # game/CH1.rpy:690
    old "Continue the silence"
    new "continúa el silencio"

    # game/CH1.rpy:690
    old "Ask him if he'd like to talk or stay silent"
    new "Pregúntale si le gustaría hablar o permanecer en silencio."

    # game/CH1.rpy:694
    old "'What were you doing outside just now?'"
    new "'¿Qué estabas haciendo afuera hace un momento?'"

    # game/CH1.rpy:694
    old "'Do you live out here all the time?'"
    new "—¿Vives aquí todo el tiempo?"

    # game/CH1.rpy:694
    old "'The storm seems pretty rough.'"
    new "\"La tormenta parece bastante fuerte\"."

    # game/CH1.rpy:694
    old "'What do you do out here?'"
    new "'¿Qué haces aquí?'"

    # game/CH1.rpy:694
    old "'You said you don't see many people around here?'"
    new "—¿Dijiste que no ves mucha gente por aquí?"

    # game/CH1.rpy:694
    old "You're done asking questions"
    new "Ya terminaste de hacer preguntas"

    # game/CH1.rpy:722
    old "I understand, me too"
    new "lo entiendo yo también"

    # game/CH1.rpy:722
    old "I don't get that"
    new "no entiendo eso"

    # game/CH1.rpy:722
    old "I get that sometimes"
    new "lo entiendo a veces"

    # game/CH1.rpy:739
    old "Laugh"
    new "reír"

    # game/CH1.rpy:739
    old "Groan"
    new "gemido"

    # game/CH1.rpy:861
    old "You like it here so far but look forward to leaving"
    new "Te gusta estar aquí hasta ahora pero esperas irte."

    # game/CH1.rpy:861
    old "You can't wait to leave and get away from this guy"
    new "No puedes esperar para irte y alejarte de este tipo."

    # game/CH1.rpy:861
    old "You would like to stay here longer ❤️"
    new "Te gustaría quedarte aquí más tiempo ❤️"

    # game/CH1.rpy:861
    old "You don't want to say anything for now"
    new "No quieres decir nada por ahora."

    # game/CH1.rpy:921
    old "'Nothing...' ❤️"
    new "'Nada...' ❤️"

    # game/CH1.rpy:921
    old "'You're handsome' ❤️"
    new "'Eres guapo' ❤️"

    # game/CH1.rpy:921
    old "'Sorry, I didn't mean to stare'"
    new "'Lo siento, no quise mirar fijamente'"

    # game/CH1.rpy:921
    old "'Just getting a better look at you.'"
    new "\"Sólo estoy para poder verte mejor\"."

    # game/CH1.rpy:1003
    old "'Good night, Jim.'"
    new "\"Buenas noches, Jim.\\"

    # game/CH1.rpy:1003
    old "'Thank you...'"
    new "'Gracias...'"

    # game/CH1.rpy:1003
    old "'Can I stay in your room?'"
    new "'¿Puedo quedarme en tu habitación?'"

    # game/CH1.rpy:1016
    old "You blush, unable to say...❤️"
    new "Te sonrojas, sin poder decir...❤️"

    # game/CH1.rpy:1016
    old "'I think there are other ways we can stay warm.' ❤️"
    new "\"Creo que hay otras maneras de mantenernos calientes\". ❤️"

    # game/CH1.rpy:1016
    old "'I don't feel safe...'"
    new "'No me siento seguro...'"

    # game/CH1.rpy:1016
    old "'Nevermind...'"
    new "'No importa...'"

    # game/CH1.rpy:1094
    old "Attraction"
    new "Atracción"

    # game/CH1.rpy:1094
    old "Grateful"
    new "agradecido"

    # game/CH1.rpy:1094
    old "Hopeful"
    new "esperanzado"

    # game/CH1.rpy:1094
    old "Embarrassed"
    new "avergonzado"

    # game/CH1.rpy:1094
    old "Wary"
    new "cauteloso"

    # game/CH1.rpy:1212
    old "Keep going"
    new "sigue adelante"

    # game/CH1.rpy:1212
    old "Look back"
    new "mirar hacia atrás"

    # game/CH1.rpy:1212
    old "Go back"
    new "volver"

    # game/CH1.rpy:1240
    old "Floor it again."
    new "Piso de nuevo."

    # game/CH1.rpy:1240
    old "Stay out in your car"
    new "Quédate afuera en tu auto"

    # game/CH1.rpy:1240
    old "Stop and look at Jim"
    new "Detente y mira a Jim."

    # game/CH1.rpy:1240
    old "Abandon the car and walk."
    new "Abandona el coche y camina."

    # game/CH1.rpy:1240
    old "Give up"
    new "rendirse"

    # game/CH1.rpy:1291
    old "Unlock the door."
    new "Abre la puerta."

    # game/CH1.rpy:1291
    old "Don't give up."
    new "No te rindas."

    # game/CH1.rpy:1418
    old "'Yes...'"
    new "'Sí...'"

    # game/CH1.rpy:1418
    old "'No, I'm just going to go to my room.'"
    new "'No, sólo voy a ir a mi habitación'."

    old "Are you sure you want to overwrite your save?"
    new "¿Estás seguro de que quieres sobrescribir tu guardado?"




translate Paloslios strings:

    # game/day2.rpy:35
    old "'Thank you...For bringing me in last night.'"
    new "\"Gracias... por traerme anoche\"."

    # game/day2.rpy:35
    old "'Good Morning'"
    new "'Buenos días'"

    # game/day2.rpy:35
    old "Say nothing. Take your seat at the table."
    new "No digas nada. Tome asiento en la mesa."

    # game/day2.rpy:80
    old "Take the mug"
    new "toma la taza"

    # game/day2.rpy:80
    old "Wait for him to speak"
    new "Espera a que hable"

    # game/day2.rpy:80
    old "Push it away"
    new "Empújalo lejos"

    # game/day2.rpy:87
    old "Drink"
    new "beber"

    # game/day2.rpy:87
    old "Pretend to drink"
    new "pretender beber"

    # game/day2.rpy:87
    old "Refuse to drink"
    new "Negarse a beber"

    # game/day2.rpy:137
    old "Refuse"
    new "Rechazar"

    # game/day2.rpy:137
    old "Accept"
    new "Aceptar"

    # game/day2.rpy:158
    old "Nod that it's perfect"
    new "Asiente que es perfecto"

    # game/day2.rpy:158
    old "'Hmm, could be better'"
    new "'Hmm, podría ser mejor'"

    # game/day2.rpy:187
    old "'Yes, I'm waiting for it to cool'"
    new "'Sí, estoy esperando que se enfríe'"

    # game/day2.rpy:187
    old "'I'm actually not thirsty...'"
    new "'En realidad no tengo sed...'"

    # game/day2.rpy:216
    old "'No, that's not-'"
    new "'No, eso no es-'"

    # game/day2.rpy:216
    old "'Maybe.'"
    new "\"Tal vez.\\"

    # game/day2.rpy:303
    old "Read a book by the fire"
    new "Leer un libro junto al fuego"

    # game/day2.rpy:303
    old "Cook some food"
    new "cocinar algo de comida"

    # game/day2.rpy:303
    old "Try calling someone"
    new "Intenta llamar a alguien"

    # game/day2.rpy:303
    old "Rest in bed"
    new "Descansa en la cama"

    # game/day2.rpy:318
    old "Read journal"
    new "leer diario"

    # game/day2.rpy:318
    old "Read something else"
    new "leer algo mas"

    # game/day2.rpy:374
    old "'Nope, not at all.'"
    new "\"No, en absoluto.\\"

    # game/day2.rpy:374
    old "'What is this?'"
    new "'¿Qué es esto?'"

    # game/day2.rpy:420
    old "'This was in your journal.'"
    new "\"Esto estaba en tu diario.\\"

    # game/day2.rpy:420
    old "'Did you put this here?'"
    new "'¿Pusiste esto aquí?'"

    # game/day2.rpy:420
    old "Crush the flower"
    new "aplastar la flor"

    # game/day2.rpy:420
    old "'It's not mine...'"
    new "'No es mío...'"

    # game/day2.rpy:505
    old "'I don't want to read this.'"
    new "\"No quiero leer esto\"."

    # game/day2.rpy:505
    old "'Ok...'"
    new "'Está bien...'"

    # game/day2.rpy:566
    old "Where's all the food?"
    new "¿Dónde está toda la comida?"

    # game/day2.rpy:566
    old "Start cooking with what's there"
    new "Empieza a cocinar con lo que hay"

    # game/day2.rpy:604
    old "Accept help"
    new "Aceptar ayuda"

    # game/day2.rpy:604
    old "Climb for it"
    new "Sube por ello"

    # game/day2.rpy:750
    old "'When will it be fixed?'"
    new "'¿Cuándo se arreglará?'"

    # game/day2.rpy:750
    old "'You're lying.'"
    new "\"Estás mintiendo\"."

    # game/day2.rpy:750
    old "Try to push past him"
    new "Intenta pasarlo"

    # game/day2.rpy:852
    old "Think about what you've seen"
    new "Piensa en lo que has visto"

    # game/day2.rpy:852
    old "Try to nap"
    new "intenta tomar una siesta"

    # game/day2.rpy:953
    old "Go to help"
    new "ir a ayudar"

    # game/day2.rpy:953
    old "Watch him work"
    new "Míralo trabajar"

    # game/day2.rpy:1055
    old "'A puzzle sounds nice.'"
    new "\"Un rompecabezas suena bien\"."

    # game/day2.rpy:1055
    old "'Do you have any novels?'"
    new "'¿Tienes alguna novela?'"

    # game/day2.rpy:1055
    old "'I'd rather just talk.'"
    new "\"Prefiero simplemente hablar.\\"

    # game/day2.rpy:1055
    old "Go back to your room"
    new "Vuelve a tu habitación"

    # game/day2.rpy:1104
    old "'You've done this before?'"
    new "'¿Has hecho esto antes?'"

    # game/day2.rpy:1104
    old "Pull your hand away."
    new "Aparta tu mano."

    # game/day2.rpy:1104
    old "Lean into his touch."
    new "Apóyate en su toque."

    # game/day2.rpy:1209
    old "Keep it"
    new "Guárdalo"

    # game/day2.rpy:1209
    old "Return it"
    new "Devuélvelo"

    # game/day2.rpy:1224
    old "'It feels...familiar.'"
    new "\"Se siente... familiar.\\"

    # game/day2.rpy:1224
    old "'It's a pretty flower.'"
    new "\"Es una flor bonita.\\"

    # game/day2.rpy:1224
    old "'I don't know...'"
    new "'No lo sé...'"

    # game/day2.rpy:1296
    old "'I remember running away once.'"
    new "\"Recuerdo que una vez me escapé\"."

    # game/day2.rpy:1296
    old "'I had a nightmare last night.'"
    new "\"Tuve una pesadilla anoche\"."

    # game/day2.rpy:1296
    old "'I don't remember much.'"
    new "\"No recuerdo mucho.\\"

    # game/day2.rpy:1296
    old "'I had a dog like this once.'"
    new "\"Una vez tuve un perro así\"."

    # game/day2.rpy:1418
    old "Watch quietly"
    new "Mira en silencio"

    # game/day2.rpy:1418
    old "Gently alert him to you"
    new "Avisarlo suavemente sobre ti"

    # game/day2.rpy:1418
    old "'What are you making?'"
    new "'¿Qué estás haciendo?'"

    # game/day2.rpy:1467
    old "Take it"
    new "Tómalo"

    # game/day2.rpy:1467
    old "Ignore it"
    new "ignorarlo"

    # game/day2.rpy:1467
    old "Break it"
    new "romperlo"

    # game/day2.rpy:1506
    old "Stop him"
    new "detenerlo"

    # game/day2.rpy:1506
    old "Let him go"
    new "déjalo ir"

    # game/day2.rpy:1544
    old "Accept it and wear it"
    new "Acéptalo y úsalo"

    # game/day2.rpy:1544
    old "Accept it, but don't wear it"
    new "Acéptalo, pero no lo uses."

    # game/day2.rpy:1544
    old "Reject it"
    new "Rechazarlo"

    # game/day2.rpy:1570
    old "'Can you put it on me?'"
    new "'¿Puedes ponérmelo?'"

    # game/day2.rpy:1570
    old "Put it on yourself"
    new "Póntelo tú mismo"

    # game/day2.rpy:1784
    old "'Jim...'"
    new "'Jim...'"

    # game/day2.rpy:1784
    old "Approach him quietly"
    new "Acércate a él en silencio"

    # game/day2.rpy:1805
    old "'I couldn't sleep either.'"
    new "\"Yo tampoco podía dormir.\\"

    # game/day2.rpy:1805
    old "'I heard you were awake.'"
    new "\"Escuché que estabas despierto.\\"

    # game/day2.rpy:1805
    old "You agree and head back to your room"
    new "Aceptas y regresas a tu habitación."

    # game/day2.rpy:1821
    old "Step forward slowly"
    new "Da un paso adelante lentamente"

    # game/day2.rpy:1821
    old "'Kiss me.'"
    new "\"Bésame.\\"

    # game/day2.rpy:1821
    old "Turn away"
    new "alejarse"

    # game/day2.rpy:1911
    old "Kiss him"
    new "Besarlo"

    # game/day2.rpy:1970
    old "Follow him"
    new "Síguelo"

    # game/day2.rpy:1970
    old "Look at the door"
    new "mira la puerta"

    # game/day2.rpy:1970
    old "Look out the window"
    new "mira por la ventana"

    # game/day2.rpy:1970
    old "Go back to bed"
    new "volver a la cama"

    # game/day2.rpy:1980
    old "Pound on the door"
    new "Golpe en la puerta"

    old "Are you sure you want to quit?"
    new "¿Estás seguro de que quieres salir?"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "¿Estás seguro de que quieres volver al menú principal?\nEsto perderá el progreso no guardado."
