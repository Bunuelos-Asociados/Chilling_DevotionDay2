


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



# game/CH1.rpy:38
translate Paloslios CH1_20ed6aa9:

    # "The car's engine purred softly as it glided along the snow-covered road, creating a rhythmic hum that harmonized with the tranquility of the winter landscape."
    "El motor del coche ronroneaba suavemente mientras se deslizaba por la carretera cubierta de nieve, creando un zumbido rítmico que armonizaba con la tranquilidad del paisaje invernal."

# game/CH1.rpy:39
translate Paloslios CH1_9a84f3e9:

    # "The world outside seemed hushed and still as if nature itself had been silenced by a blanket of pristine snow."
    "El mundo exterior parecía silencioso y quieto, como si la naturaleza misma hubiera sido silenciada por un manto de nieve prístina."

# game/CH1.rpy:48
translate Paloslios CH1_b113e630:

    # "Through the windshield, the scene unfolded like a postcard come to life. The snow-laden trees stood tall, their branches delicately adorned with glistening crystals."
    "A través del parabrisas, la escena se desarrolló como una postal cobrada vida. Los árboles cargados de nieve se alzaban altos, con sus ramas delicadamente adornadas con cristales relucientes."

# game/CH1.rpy:49
translate Paloslios CH1_32ca1fd5:

    # "Each limb reached out towards the sky as if yearning to touch the falling snowflakes. The weight of the snow bent some branches, creating graceful arches that framed the road ahead."
    "Cada miembro se extendía hacia el cielo como si anhelara tocar los copos de nieve que caían. El peso de la nieve dobló algunas ramas, creando elegantes arcos que enmarcaban el camino por delante."

# game/CH1.rpy:54
translate Paloslios CH1_d1d8de1a:

    # "As the car made its way through the winter wonderland, the snowscape seemed to stretch out infinitely in every direction. The vastness of the scenery was both awe-inspiring and humbling."
    "A medida que el coche atravesaba el paraíso invernal, el paisaje nevado parecía extenderse infinitamente en todas direcciones. La inmensidad del paisaje era a la vez impresionante y humillante."

# game/CH1.rpy:55
translate Paloslios CH1_510c63c7:

    # "You continue to look around in wonder from the warmth and comfort of your vehicle."
    "Continúas mirando a tu alrededor con asombro desde la calidez y comodidad de tu vehículo."

# game/CH1.rpy:56
translate Paloslios CH1_2d014096:

    # "For you, this is a whole new experience coming from a busy city life."
    "Para usted, esta es una experiencia completamente nueva proveniente de una vida urbana ocupada."

# game/CH1.rpy:57
translate Paloslios CH1_4c6203bb:

    # "'The Little Cub Cabin Retreat'."
    "\"El retiro en la cabaña del pequeño cachorro\"."

# game/CH1.rpy:58
translate Paloslios CH1_6f6ac2a7:

    # "It was advertised as 'The coziest escape in the heart of snowy mountain wilderness.'"
    "Se anunciaba como \"La escapada más acogedora en el corazón de la naturaleza montañosa nevada\"."

# game/CH1.rpy:59
translate Paloslios CH1_a33a08d5:

    # "'Unplug and experience tranquility and the unforgettable views of snow-capped peaks and towering pine trees right outside your window.'"
    "\"Desconéctese y experimente la tranquilidad y las vistas inolvidables de los picos nevados y los imponentes pinos justo afuera de su ventana\"."

# game/CH1.rpy:60
translate Paloslios CH1_a340549d:

    # "It sounded like exactly what you needed at the time...and you immediately booked a cabin for one- just for a week."
    "Parecía exactamente lo que necesitabas en ese momento... e inmediatamente reservaste una cabaña para una persona, solo por una semana."

# game/CH1.rpy:61
translate Paloslios CH1_1c755353:

    # "You look down at the directions you downloaded again."
    "Miras las instrucciones que descargaste nuevamente."

# game/CH1.rpy:62
translate Paloslios CH1_8f1a99d7:

    # "'Turn onto Little Cub Trail and it's the first cabin on the left.'"
    "\"Gire hacia Little Cub Trail y será la primera cabaña a la izquierda\"."

# game/CH1.rpy:63
translate Paloslios CH1_2ff62169:

    # "You slow the car as you approach a sign. Some of the letters of 'little cub' peek out from under the snow."
    "Reduces la velocidad del auto cuando te acercas a una señal. Algunas de las letras de 'pequeño cachorro' se asoman debajo de la nieve."

# game/CH1.rpy:64
translate Paloslios CH1_ed10d34b:

    # "You turn into the trail and your car bumps along the unpaved snowy dirt path. You look around attentively for the first cabin you see through the increasing snowfall."
    "Entras en el sendero y tu coche avanza por el camino de tierra nevado sin pavimentar. Miras atentamente a tu alrededor en busca de la primera cabaña que ves a través de la creciente nevada."

# game/CH1.rpy:67
translate Paloslios CH1_7e83a1ae:

    # "The wind suddenly starts whipping the snow around with fervor and the road ahead of you quickly disappears."
    "De repente, el viento empieza a azotar la nieve con fervor y el camino que tienes delante desaparece rápidamente."

# game/CH1.rpy:68
translate Paloslios CH1_c7fa3f2a:

    # "You feel a pang in your chest at the sight and your breath quickens."
    "Sientes una punzada en el pecho al verlo y tu respiración se acelera."

# game/CH1.rpy:69
translate Paloslios CH1_154d7e97:

    # "Your eyes begin darting between the trees looking for this damn cabin."
    "Tus ojos comienzan a moverse entre los árboles buscando esta maldita cabaña."

# game/CH1.rpy:70
translate Paloslios CH1_fc6c31ab:

    # "So much for the forecast of light snow today. Hopefully, you get there soon in case the snow gets worse."
    "Hasta aquí el pronóstico de nieve ligera para hoy. Con suerte, llegarás pronto en caso de que la nieve empeore."

# game/CH1.rpy:76
translate Paloslios CH1_0f4d29ba:

    # "Finally!"
    "¡Finalmente!"

# game/CH1.rpy:77
translate Paloslios CH1_8a39d130:

    # "You had been looking forward to this getaway for a couple of weeks and there it is..."
    "Llevabas un par de semanas esperando con ansias esta escapada y ahí está..."

# game/CH1.rpy:78
translate Paloslios CH1_85fbe2f7:

    # "You take some time to fully take in the exterior from the safety of your car."
    "Te tomas un tiempo para disfrutar plenamente del exterior desde la seguridad de tu coche."

# game/CH1.rpy:79
translate Paloslios CH1_7d5e710a:

    # "Now, the idea of a private snowy cabin makes you..."
    "Ahora, la idea de una cabaña privada en la nieve te hace..."

# game/CH1.rpy:83
translate Paloslios CH1_c6f9917d:

    # "You could have invited a friend or something to come with you."
    "Podrías haber invitado a un amigo o algo a venir contigo."

# game/CH1.rpy:84
translate Paloslios CH1_7efa53a4:

    # "Being completely alone and unplugged is starting to sound like a bad idea."
    "Estar completamente solo y desconectado empieza a parecer una mala idea."

# game/CH1.rpy:85
translate Paloslios CH1_8e196d30:

    # "Maybe...you would come to miss the noise and chaos of everyday life."
    "Tal vez... llegarías a extrañar el ruido y el caos de la vida cotidiana."

# game/CH1.rpy:86
translate Paloslios CH1_ab7287f2:

    # "You're already missing the idea of using the internet and your phone."
    "Ya te estás perdiendo la idea de utilizar Internet y tu teléfono."

# game/CH1.rpy:87
translate Paloslios CH1_9226e102:

    # "But maybe this is what you need to appreciate the conveniences of modern society."
    "Pero tal vez esto sea lo que necesita para apreciar las comodidades de la sociedad moderna."

# game/CH1.rpy:90
translate Paloslios CH1_5fd6f601:

    # "You've rented out a cabin for a week to get away from your troubles back in reality."
    "Has alquilado una cabaña durante una semana para alejarte de tus problemas y volver a la realidad."

# game/CH1.rpy:91
translate Paloslios CH1_ec9aaaad:

    # "You can just appreciate nature and do some things that you haven't been able to do in a while."
    "Puedes simplemente apreciar la naturaleza y hacer algunas cosas que no has podido hacer desde hace tiempo."

# game/CH1.rpy:92
translate Paloslios CH1_adccc440:

    # "There's so much you can do. Like reading next to the fire or going on a hike to see some of the sights they talked about on the website."
    "Hay tantas cosas que puedes hacer. Como leer junto al fuego o hacer una caminata para ver algunos de los lugares de los que hablaron en el sitio web."

# game/CH1.rpy:93
translate Paloslios CH1_b342ffa2:

    # "You don't remember the last time you just had some quiet time to yourself."
    "No recuerdas la última vez que tuviste un momento de tranquilidad para ti mismo."

# game/CH1.rpy:94
translate Paloslios CH1_5207b7ce:

    # "It's time to relax and rest finally."
    "Es hora de relajarse y descansar finalmente."

# game/CH1.rpy:97
translate Paloslios CH1_01621c43:

    # "You're nervous about it now."
    "Estás nervioso por eso ahora."

# game/CH1.rpy:98
translate Paloslios CH1_d0e6ff1e:

    # "You've never been somewhere like this before and you're not sure what will happen up here in the mountains."
    "Nunca has estado en un lugar como este antes y no estás seguro de lo que sucederá aquí en las montañas."

# game/CH1.rpy:99
translate Paloslios CH1_0b5ce476:

    # "Judging from the unexpected shift in the weather already, the drive here was already a bit more stressful than anticipated."
    "A juzgar por el cambio inesperado del tiempo, el viaje hasta aquí ya fue un poco más estresante de lo previsto."

# game/CH1.rpy:100
translate Paloslios CH1_01e8c969:

    # "Being alone on a mountain far from anyone and anywhere familiar is making you more nervous by the second."
    "Estar solo en una montaña, lejos de cualquier persona y de cualquier lugar familiar, te pone cada vez más nervioso."

# game/CH1.rpy:101
translate Paloslios CH1_a1bb33b5:

    # "Maybe you'd calm down once you get to your destination and get a chance to settle in."
    "Tal vez te calmes una vez que llegues a tu destino y tengas la oportunidad de instalarte."

# game/CH1.rpy:104
translate Paloslios CH1_aaa3074d:

    # "You're excited! You've been looking forward to this ever since you've booked it."
    "¡Estás emocionado! Has estado esperando esto desde que lo reservaste."

# game/CH1.rpy:105
translate Paloslios CH1_b90e21a4:

    # "Everything is so new and fascinating. And you've mentally planned out various activities you could do."
    "Todo es tan nuevo y fascinante. Y ha planificado mentalmente varias actividades que podría realizar."

# game/CH1.rpy:106
translate Paloslios CH1_e999e947:

    # "From staying by the fire with a good book or hiking to see some of these snowcapped peaks. There would be something for whatever mood you'd be in."
    "Desde quedarse junto al fuego con un buen libro o hacer una caminata para ver algunos de estos picos nevados. Habría algo para cualquier estado de ánimo en el que te encuentres."

# game/CH1.rpy:107
translate Paloslios CH1_f72c8363:

    # "Maybe just catching up on sleep and resting would be enough to look forward to."
    "Tal vez simplemente recuperar el sueño y descansar sería suficiente para esperar."

# game/CH1.rpy:110
translate Paloslios CH1_d2ee78b7:

    # "You're not really sure yet."
    "No estás realmente seguro todavía."

# game/CH1.rpy:111
translate Paloslios CH1_92888632:

    # "You want to reserve judgment for now until you see how things go."
    "Quieres reservarte el juicio por ahora hasta que veas cómo van las cosas."

# game/CH1.rpy:112
translate Paloslios CH1_639225ed:

    # "This is a completely new experience for you so you're not sure what to expect."
    "Esta es una experiencia completamente nueva para ti, por lo que no estás seguro de qué esperar."

# game/CH1.rpy:113
translate Paloslios CH1_3d368385:

    # "Hopefully, you'll be able to get a better idea of what's in store for you once you get there."
    "Con suerte, podrás tener una mejor idea de lo que te espera una vez que llegues allí."

# game/CH1.rpy:115
translate Paloslios CH1_a2230249:

    # "You squint through the falling snow trying to make out the numbers on the cabin."
    "Entrecierras los ojos a través de la nieve que cae tratando de distinguir los números en la cabaña."

# game/CH1.rpy:116
translate Paloslios CH1_94a1a863:

    # "The snow is really starting to come down quickly...and you feel an urgency to get indoors."
    "La nieve está empezando a caer rápidamente... y sientes la urgencia de entrar al interior."

# game/CH1.rpy:117
translate Paloslios CH1_c76268cd:

    # "Snow had covered the sign, but this one looked like the picture in the booking so you pulled onto the snow-covered path."
    "La nieve había cubierto el cartel, pero este se parecía a la imagen de la reserva, así que te detuviste en el camino cubierto de nieve."

# game/CH1.rpy:124
translate Paloslios CH1_7f2d98a2:

    # "You feel a wave of relief to have finally arrived. The drive up the mountain was like rainbow road. And then the snow, while beautiful, made for an even more challenging drive."
    "Sientes una oleada de alivio por haber llegado finalmente. El camino hacia la montaña fue como un camino de arcoíris. Y luego la nieve, aunque hermosa, hizo que el viaje fuera aún más desafiante."

# game/CH1.rpy:125
translate Paloslios CH1_3c6a412a:

    # "Your little cabin is surrounded by trees and there are no neighbors in sight."
    "Tu pequeña cabaña está rodeada de árboles y no hay vecinos a la vista."

# game/CH1.rpy:126
translate Paloslios CH1_30812ec5:

    # "A large stretch of wilderness ensures you plenty of privacy."
    "Una gran extensión de naturaleza le garantiza mucha privacidad."

# game/CH1.rpy:130
translate Paloslios CH1_3862f9d7:

    # "You hurriedly lug your stuff out of your car up to the cabin. It's not much, just a suitcase for the week."
    "Rápidamente sacas tus cosas de tu auto y las llevas a la cabina. No es mucho, sólo una maleta para la semana."

# game/CH1.rpy:131
translate Paloslios CH1_1fdd6edd:

    # "Looking at the snow...maybe you should have packed even thicker winter clothes."
    "Mirando la nieve... tal vez deberías haber empacado ropa de invierno aún más gruesa."

# game/CH1.rpy:132
translate Paloslios CH1_92e403ef:

    # "The icy environment chills the delicate skin on your face."
    "El ambiente helado enfría la delicada piel de tu rostro."

# game/CH1.rpy:141
translate Paloslios CH1_7bdc1823:

    # "You bound up to the cabin, eager to get out of the cold."
    "Corriste a la cabaña, ansioso por salir del frío."

# game/CH1.rpy:143
translate Paloslios CH1_505a0865:

    # "Ah- It's already unlocked. Is this normal for remote cabins?"
    "Ah- Ya está desbloqueado. ¿Es esto normal en cabañas remotas?"

# game/CH1.rpy:151
translate Paloslios CH1_a219a6d6:

    # "As you step inside, the warmth of being out of the elements immediately greets you, but it could certainly be warmer."
    "Al entrar, la calidez de estar fuera de los elementos te saluda de inmediato, pero ciertamente podría ser más cálida."

# game/CH1.rpy:157
translate Paloslios CH1_a703d213:

    # "You set down your things by the door and quickly set about lighting a fire in the fireplace. Conveniently, there's some wood and a lighter by the hearth."
    "Dejas tus cosas junto a la puerta y rápidamente te pones a encender el fuego de la chimenea. Convenientemente, hay algo de leña y un encendedor junto al hogar."

# game/CH1.rpy:158
translate Paloslios CH1_fc232e60:

    # "You take in the cabin's interior and it's as cozy as described if not a bit more messy than expected."
    "Se contempla el interior de la cabina y es tan acogedor como se describe, si no un poco más desordenado de lo esperado."

# game/CH1.rpy:159
translate Paloslios CH1_0e5bdbf6:

    # "Did they not clean up the place...there's stuff still laid out on the table."
    "¿No limpiaron el lugar? Todavía hay cosas sobre la mesa."

# game/CH1.rpy:160
translate Paloslios CH1_0b6ad460:

    # "Looks like the place hasn't been swept in a while too."
    "Parece que el lugar tampoco ha sido barrido desde hace tiempo."

# game/CH1.rpy:161
translate Paloslios CH1_48ea30bf:

    # "It has a lived-in feel and is ready for someone to move in."
    "Tiene una sensación de estar habitado y está listo para que alguien se mude."

# game/CH1.rpy:162
translate Paloslios CH1_bb6f6c35:

    # "The warm glow from the hearth dancing across the rustic wooden walls and furniture was cozy and inviting."
    "El cálido resplandor de la chimenea que danzaba sobre las rústicas paredes y muebles de madera era acogedor y atractivo."

# game/CH1.rpy:163
translate Paloslios CH1_37d0123e:

    # "Some books are resting on the worn wooden table and shelves."
    "Algunos libros descansan sobre la mesa y los estantes de madera desgastada."

# game/CH1.rpy:174
translate Paloslios CH1_0f6d5a58:

    # "You hurry over to inspect the tiny kitchenette and you are pleasantly surprised that it is fully stocked."
    "Te apresuras a inspeccionar la pequeña cocina y te sorprende gratamente que esté completamente equipada."

# game/CH1.rpy:175
translate Paloslios CH1_5011c103:

    # "Wow, it looks like mystery meat and...a lot of junk food."
    "Vaya, parece carne misteriosa y... mucha comida chatarra."

# game/CH1.rpy:176
translate Paloslios CH1_71b39242:

    # "Still, that's pretty generous of the people running this place. You had expected to get food later in town when the snow let up."
    "Aún así, es bastante generoso por parte de la gente que dirige este lugar. Esperabas conseguir comida más tarde en la ciudad, cuando amainara la nieve."

# game/CH1.rpy:177
translate Paloslios CH1_0532e8fd:

    # "It's a bit of a drive, but there is a small town with a grocery store around here."
    "Es un poco largo en coche, pero hay un pequeño pueblo con una tienda de comestibles por aquí."

# game/CH1.rpy:178
translate Paloslios CH1_cad38604:

    # "You can look more closely around the rest of the cabin later- right now you just wanted a warm drink."
    "Podrás observar más de cerca el resto de la cabina más tarde; en este momento solo querías una bebida caliente."

# game/CH1.rpy:180
translate Paloslios CH1_0f8e0506:

    # "You look in the kitchen's drawers and find a couple of options to choose from."
    "Buscas en los cajones de la cocina y encuentras un par de opciones para elegir."

# game/CH1.rpy:181
translate Paloslios CH1_d91b1ee9:

    # "All of them are of the 'instant drink' variety, but beggars can't be choosers."
    "Todos ellos son de la variedad de \"bebida instantánea\", pero los mendigos no pueden elegir."

# game/CH1.rpy:182
translate Paloslios CH1_1ae35dda:

    # "What do you want to drink?"
    "¿Qué quieres beber?"

# game/CH1.rpy:193
translate Paloslios CH1_f3776613:

    # "You grab a packet for an instant [drink]. Then, you find a pot and start to heat some water on the gas stove."
    "Coges un paquete por un instante [drink]. Luego, buscas una olla y empiezas a calentar un poco de agua en la estufa de gas."

# game/CH1.rpy:194
translate Paloslios CH1_c2a5bf05:

    # "It's been a while since you've used one of these."
    "Ha pasado un tiempo desde que usaste uno de estos."

# game/CH1.rpy:195
translate Paloslios CH1_c1ca821e:

    # "You check your phone and there's no signal. You do spot a landline on the countertop if you need to call anyone."
    "Revisas tu teléfono y no hay señal. Ves un teléfono fijo en la encimera si necesitas llamar a alguien."

# game/CH1.rpy:196
translate Paloslios CH1_5967ed7a:

    # "Been a while since you've seen one of those too...another reminder of how far from civilization you are."
    "Ha pasado un tiempo desde que viste uno de esos... otro recordatorio de lo lejos que estás de la civilización."

# game/CH1.rpy:198
translate Paloslios CH1_8e5908fb:

    # "The pot of water simmers on the stove and you pour some into a cup for your [drink]."
    "La olla de agua hierve a fuego lento en la estufa y viertes un poco en una taza para tu [drink]."

# game/CH1.rpy:199
translate Paloslios CH1_3d189ba9:

    # "The smell of [drink] fills the room and the warmth from the cup warms your frozen hands."
    "El olor de [drink] llena la habitación y el calor de la taza calienta tus manos heladas."

# game/CH1.rpy:201
translate Paloslios CH1_fadec8cf:

    # "The window rattles suddenly and you jump from your thoughts."
    "La ventana suena de repente y saltas de tus pensamientos."

# game/CH1.rpy:202
translate Paloslios CH1_f544fb34:

    # "The snowing from earlier has really picked up into a storm now, the heavy fall of snow blurring the landscape out the window."
    "La nevada de antes realmente se ha convertido en una tormenta ahora, la fuerte caída de nieve desdibuja el paisaje por la ventana."

# game/CH1.rpy:203
translate Paloslios CH1_b7d565fb:

    # "The wind howls and rattles the windows again. The sharp, erratic bursts made you flinch every time."
    "El viento aúlla y vuelve a hacer vibrar las ventanas. Las ráfagas agudas y erráticas te hacían estremecer cada vez."

# game/CH1.rpy:204
translate Paloslios CH1_179e915c:

    # "Snow now slams against the cabin in chaotic flurries."
    "La nieve ahora golpea la cabaña en caóticas ráfagas."

# game/CH1.rpy:205
translate Paloslios CH1_b99d7760:

    # "You wonder if the windows would hold against the storm's fury."
    "Uno se pregunta si las ventanas resistirían la furia de la tormenta."

# game/CH1.rpy:206
translate Paloslios CH1_2efb502b:

    # "That's a bit concerning, but it's a perfect contrast to the safety of the cabin."
    "Esto es un poco preocupante, pero contrasta perfectamente con la seguridad de la cabina."

# game/CH1.rpy:207
translate Paloslios CH1_76a8906f:

    # "The cabin was a small sanctuary that was holding back the icy wilderness beyond its walls."
    "La cabaña era un pequeño santuario que contenía la naturaleza helada más allá de sus muros."

# game/CH1.rpy:208
translate Paloslios CH1_1d196e23:

    # "Luckily, you have food here and made it before the weather took a turn for the worse."
    "Afortunadamente, aquí tienes comida y la preparaste antes de que el clima empeorara."

# game/CH1.rpy:210
translate Paloslios CH1_c18157f5:

    # "Snowed in or not, you were planning on bunkering down here initially anyway."
    "Nevado o no, inicialmente planeabas refugiarte aquí de todos modos."

# game/CH1.rpy:216
translate Paloslios CH1_7751548a:

    # "Just as you started settling in near the hearth with your hot drink, there was knocking at the door."
    "Justo cuando empezabas a instalarte cerca del hogar con tu bebida caliente, alguien llamó a la puerta."

# game/CH1.rpy:219
translate Paloslios CH1_d4ccc2df:

    # "You snap your head towards the sound and you feel your heart racing with fear."
    "Giras la cabeza hacia el sonido y sientes que tu corazón se acelera de miedo."

# game/CH1.rpy:220
translate Paloslios CH1_8890b0e8:

    # "You weren't expecting anyone, and the thought of a stranger out here in the middle of nowhere during a snowstorm sent a shiver down your spine."
    "No esperabas a nadie, y la idea de un extraño aquí en medio de la nada durante una tormenta de nieve te provocó un escalofrío."

# game/CH1.rpy:221
translate Paloslios CH1_9ea240bb:

    # "But maybe it was the cabin host...or someone that needed help."
    "Pero tal vez era el anfitrión de la cabaña... o alguien que necesitaba ayuda."

# game/CH1.rpy:222
translate Paloslios CH1_f3b66b86:

    # "You set down your drink on the table gently and look toward the door."
    "Dejas tu bebida sobre la mesa con cuidado y miras hacia la puerta."

# game/CH1.rpy:223
translate Paloslios CH1_28b6f1fe:

    # "What will you do now?"
    "¿Qué harás ahora?"

# game/CH1.rpy:234
translate Paloslios door1_386d2923:

    # "You take a deep breath and make your way to the door, steeling yourself for whoever is on the other side."
    "Respiras profundamente y te diriges hacia la puerta, preparándote para quien esté al otro lado."

# game/CH1.rpy:239
translate Paloslios door1_6ad56164:

    # "You try to calm your nerves while you wait for an answer."
    "Intentas calmar tus nervios mientras esperas una respuesta."

# game/CH1.rpy:240
translate Paloslios door1_00ab846e:

    # "And an answer doesn't come."
    "Y no llega una respuesta."

# game/CH1.rpy:245
translate Paloslios door1_cd5f8692:

    # "You hold your breath and wait to see what happens."
    "Aguantas la respiración y esperas a ver qué pasa."

# game/CH1.rpy:246
translate Paloslios door1_4836404d:

    # "For what feels like a couple of minutes there is no more knocking or sounds over the freezing winds."
    "Durante lo que parecieron un par de minutos, no se oyeron más golpes ni sonidos del viento helado."

# game/CH1.rpy:249
translate Paloslios menu1_slow_2740e60c:

    # "You froze on the spot and ended up staying quiet."
    "Te quedaste paralizado en el acto y terminaste quedándote callado."

# game/CH1.rpy:268
translate Paloslios opendoor1_8c87cf55:

    # "When you open the door, you are greeted by a tall figure wearing a mask, their expression hidden."
    "Cuando abres la puerta, te saluda una figura alta que lleva una máscara y cuya expresión está oculta."

# game/CH1.rpy:269
translate Paloslios opendoor1_b6301dfc:

    # "Your breath catches in your throat at the looming sight, fear threatening to overwhelm you."
    "Se te queda el aliento en la garganta ante la vista que se avecina, el miedo amenaza con abrumarte."

# game/CH1.rpy:271
translate Paloslios opendoor1_83901444:

    # "A bitting and cold wind rushes in from the cracked open door."
    "Un viento frío y cortante entra por la puerta entreabierta."

# game/CH1.rpy:272
translate Paloslios opendoor1_4cf0ac2d:

    # "The unknown visitor is bundled in thick clothes and covered in snow. The huffs of their breath still show through their mask."
    "El visitante desconocido está envuelto en ropas gruesas y cubierto de nieve. Los resoplidos de su aliento todavía se notan a través de su máscara."

# game/CH1.rpy:280
translate Paloslios opendoor1_4cb054bf:

    # "The figure says nothing- the silence somehow chilling the air further."
    "La figura no dice nada; el silencio de alguna manera enfría aún más el aire."

# game/CH1.rpy:281
translate Paloslios opendoor1_91cfc365:

    # "You reflexively take a step back and grip the door's handle, ready to slam the door shut and lock it."
    "Por reflejo das un paso atrás y agarras la manija de la puerta, listo para cerrarla de golpe y bloquearla."

# game/CH1.rpy:284
translate Paloslios opendoor1_3858ed4d:

    # "The stranger seems to notice this and slams his hand on the door- preventing you from closing it!"
    "El extraño parece darse cuenta de esto y golpea la puerta con la mano, ¡impidiendo que puedas cerrarla!"

# game/CH1.rpy:285
translate Paloslios opendoor1_3748e8dc:

    # "At the sudden movement you..."
    "Ante el movimiento repentino tú..."

# game/CH1.rpy:298
translate Paloslios menu2_slow_d4d9d1b5:

    # "Your fear takes over and you feel your body tense up like a statue."
    "Tu miedo se apodera de ti y sientes que tu cuerpo se tensa como una estatua."

# game/CH1.rpy:299
translate Paloslios menu2_slow_fe216396:

    # "Your eyes widen looking up at the stranger and even your breath stops in your chest."
    "Tus ojos se abren al mirar al extraño e incluso tu respiración se detiene en tu pecho."

# game/CH1.rpy:300
translate Paloslios menu2_slow_3c787f13:

    # "To your horror, the stranger reaches over to grip your arm which is still holding onto the door."
    "Para tu horror, el extraño se acerca para agarrarte del brazo que todavía sostiene la puerta."

# game/CH1.rpy:301
translate Paloslios menu2_slow_038d4338:

    # "You are still too shocked to do anything."
    "Todavía estás demasiado conmocionado para hacer algo."

# game/CH1.rpy:307
translate Paloslios menu2_slow_ef1e4aa5:

    # "You don't think you can win a fight against this man, but maybe you catch him by surprise and get the upper hand."
    "No crees que puedas ganar una pelea contra este hombre, pero tal vez lo pilles por sorpresa y tomes ventaja."

# game/CH1.rpy:308
translate Paloslios menu2_slow_119ee0be:

    # "With adrenaline coursing through your veins you lunge at the stranger."
    "Con la adrenalina corriendo por tus venas te abalanzas hacia el extraño."

# game/CH1.rpy:311
translate Paloslios menu2_slow_8805ec13:

    # "But the man's reflexes are faster than you anticipated."
    "Pero los reflejos del hombre son más rápidos de lo que esperabas."

# game/CH1.rpy:312
translate Paloslios menu2_slow_5dfe5947:

    # "He easily dodges your attack and he catches your arm to stop you."
    "Él esquiva fácilmente tu ataque y te agarra el brazo para detenerte."

# game/CH1.rpy:313
translate Paloslios menu2_slow_fc47490f:

    # j "I wouldn't try that again if I were you..."
    j "No lo volvería a intentar si fuera tú..."

# game/CH1.rpy:319
translate Paloslios menu2_slow_2628ca7e:

    # "You don't think you can fight your way out of this one. Maybe you can push past him if you're quick."
    "No crees que puedas salir de esto luchando. Quizás puedas pasarlo si eres rápido."

# game/CH1.rpy:320
translate Paloslios menu2_slow_70cafdda:

    # "You don't hesitate as you lower your shoulder and try to push past him, desperate to escape the menacing man in front of you."
    "No dudas mientras bajas el hombro y tratas de pasar a su lado, desesperada por escapar del hombre amenazador frente a ti."

# game/CH1.rpy:323
translate Paloslios menu2_slow_c69a93b8:

    # "But the man's reflexes are quicker than you anticipated."
    "Pero los reflejos del hombre son más rápidos de lo que esperabas."

# game/CH1.rpy:324
translate Paloslios menu2_slow_6a6ad8f2:

    # "You feel the firm, immovable wall of his chest collide with your shoulder. Unyielding."
    "Sientes la pared firme e inamovible de su pecho chocar con tu hombro. Inflexible."

# game/CH1.rpy:325
translate Paloslios menu2_slow_73ffa78e:

    # "He doesn't budge even an inch and he grabs you by the arm."
    "No se mueve ni un centímetro y te agarra del brazo."

# game/CH1.rpy:327
translate Paloslios menu2_slow_4047fa5a:

    # "His hands are strong but not painful, and they anchor you firmly in place in front of him."
    "Sus manos son fuertes pero no dolorosas y te anclan firmemente en tu lugar frente a él."

# game/CH1.rpy:328
translate Paloslios menu2_slow_c8e4da0a:

    # "His face is unreadable- neither angry nor amused, just...unreadable."
    "Su rostro es ilegible, ni enojado ni divertido, simplemente... ilegible."

# game/CH1.rpy:330
translate Paloslios menu2_slow_ea11f929:

    # "The storm outside howls louder, as if taunting you in this situation."
    "La tormenta afuera aúlla más fuerte, como burlándose de ti en esta situación."

# game/CH1.rpy:331
translate Paloslios menu2_slow_3e02bbc5:

    # "What do you do now?"
    "¿Qué haces ahora?"

# game/CH1.rpy:336
translate Paloslios menu2_slow_29ab8896:

    # "The stranger's grip on your arm tightens."
    "El extraño agarre de tu brazo se hace más fuerte."

# game/CH1.rpy:337
translate Paloslios menu2_slow_8aadf6a4:

    # ji "I'm afraid I can't do that."
    ji "Me temo que no puedo hacer eso."

# game/CH1.rpy:341
translate Paloslios menu2_slow_a6569fd0:

    # "You try to pull against his gloved hand, but it's no use."
    "Intentas tirar de su mano enguantada, pero es inútil."

# game/CH1.rpy:342
translate Paloslios menu2_slow_b9c03a05:

    # "The stranger is much stronger than you."
    "El extraño es mucho más fuerte que tú."

# game/CH1.rpy:343
translate Paloslios menu2_slow_1c8da45b:

    # ji "You're not going anywhere."
    ji "No irás a ninguna parte."

# game/CH1.rpy:346
translate Paloslios menu2_slow_f515a29b:

    # "You only stare back at the stranger's eyes peering emotionlessly back at you."
    "Sólo te devuelves la mirada a los ojos del extraño que te miran sin emociones."

# game/CH1.rpy:347
translate Paloslios menu2_slow_b0bbbce0:

    # "Finally, he's the one to speak up."
    "Finalmente, es él quien habla."

# game/CH1.rpy:348
translate Paloslios menu2_slow_a2ecc0df:

    # ji "I don't think you'll be leaving."
    ji "No creo que te vayas."

# game/CH1.rpy:350
translate Paloslios menu2_slow_223ebb22:

    # "A chill runs through you as you hear that low, cold, and menacing voice. There's a slight southern drawl to it."
    "Un escalofrío te recorre cuando escuchas esa voz baja, fría y amenazante. Tiene un ligero acento sureño."

# game/CH1.rpy:351
translate Paloslios menu2_slow_bb5f9699:

    # "His words hang heavy in the air, mingling with your labored breaths and the roar of the winds."
    "Sus palabras flotan pesadas en el aire, mezclándose con sus respiraciones laboriosas y el rugido de los vientos."

# game/CH1.rpy:352
translate Paloslios menu2_slow_c8960c58:

    # "Just as you're starting to feel lightheaded, the stranger adds matter-of-factly..."
    "Justo cuando empiezas a sentirte mareado, el extraño añade con total naturalidad..."

# game/CH1.rpy:354
translate Paloslios menu2_slow_4e733fc7:

    # ji "Especially not in this weather. There's a snowstorm."
    ji "Especialmente no con este clima. Hay una tormenta de nieve."

# game/CH1.rpy:355
translate Paloslios menu2_slow_1b68545b:

    # ji "You won't survive out there alone. You won't even make it five minutes in the storm by the looks of you."
    ji "No sobrevivirás solo ahí fuera. Por tu aspecto, ni siquiera podrás aguantar cinco minutos en la tormenta."

# game/CH1.rpy:356
translate Paloslios menu2_slow_4cbe89e4:

    # "Huh?"
    "¿Eh?"

# game/CH1.rpy:357
translate Paloslios menu2_slow_ca2ad0de:

    # "He suddenly lets go of you."
    "De repente te suelta."

# game/CH1.rpy:363
translate Paloslios menu2_slow_1c7a879f:

    # "The action is so sudden that you stumble back into the cabin's interior and the stranger takes a step in."
    "La acción es tan repentina que regresas al interior de la cabaña y el extraño entra."

# game/CH1.rpy:372
translate Paloslios closedoor1_afb895c7:

    # "There's no peephole on the door so you can't see who it is from the door."
    "No hay mirilla en la puerta, por lo que no puedes ver quién es desde la puerta."

# game/CH1.rpy:379
translate Paloslios closedoor1_eb94543c:

    # "Eventually, you quietly sneak over to the window and try to peak out, but you don't see anyone."
    "Finalmente, te acercas sigilosamente a la ventana e intentas asomarte, pero no ves a nadie."

# game/CH1.rpy:380
translate Paloslios closedoor1_874718b2:

    # "It's hard to see with the snow already frosting the glass and forming an icy crust along the edges of the panes."
    "Es difícil ver con la nieve que ya congela el vidrio y forma una costra helada a lo largo de los bordes de los cristales."

# game/CH1.rpy:381
translate Paloslios closedoor1_263a6289:

    # "Hopefully, whoever it was just left. Maybe they got the wrong place."
    "Con suerte, quienquiera que haya sido, acaba de irse. Quizás se equivocaron de lugar."

# game/CH1.rpy:383
translate Paloslios closedoor1_ebf38817:

    # "As you are about to return to your seat, you hear the click of the lock."
    "Cuando estás a punto de regresar a tu asiento, escuchas el clic de la cerradura."

# game/CH1.rpy:384
translate Paloslios closedoor1_1517a19f:

    # "Time slows and your body tenses from the noise."
    "El tiempo se ralentiza y tu cuerpo se tensa por el ruido."

# game/CH1.rpy:387
translate Paloslios closedoor1_e12f83f6:

    # "The hinges of the door creak open as the biting and cold wind rushes in. The snow briefly obscures your vision as it flurries towards you."
    "Las bisagras de la puerta se abren con un chirrido cuando entra el viento frío y cortante. La nieve oscurece brevemente tu visión mientras se arremolina hacia ti."

# game/CH1.rpy:390
translate Paloslios closedoor1_e29568e9:

    # "And there, a tall looming figure towers over you before you can act."
    "Y allí, una figura alta y amenazante se eleva sobre ti antes de que puedas actuar."

# game/CH1.rpy:391
translate Paloslios closedoor1_674b7d0d:

    # "Your mind races with fear and uncertainty. Who are they? What do they want?"
    "Tu mente se acelera con miedo e incertidumbre. ¿Quiénes son? ¿Qué quieren?"

# game/CH1.rpy:392
translate Paloslios closedoor1_608a6003:

    # "You take a hesitant step back, your heart pounding in your chest."
    "Das un paso atrás vacilante y el corazón te late con fuerza en el pecho."

# game/CH1.rpy:400
translate Paloslios closedoor1_84054d91:

    # "You wait for them to speak, to move, to do anything. But they just stand there, unmoving, like a statue."
    "Esperas a que hablen, se muevan, hagan cualquier cosa. Pero se quedan ahí, inmóviles, como una estatua."

# game/CH1.rpy:401
translate Paloslios closedoor1_143f853e:

    # "His eyes glint faintly as they're fixed on you. The intensity is heavy enough to make you shiver."
    "Sus ojos brillan débilmente mientras están fijos en ti. La intensidad es lo suficientemente fuerte como para hacerte temblar."

# game/CH1.rpy:402
translate Paloslios closedoor1_1897c6a9:

    # "You can't help but feel trapped under his gaze."
    "No puedes evitar sentirte atrapado bajo su mirada."

# game/CH1.rpy:403
translate Paloslios closedoor1_ae759e09:

    # "As you are about to utter a word, the stranger's voice finally cuts through the silence..."
    "Cuando estás a punto de pronunciar una palabra, la voz del extraño finalmente corta el silencio..."

# game/CH1.rpy:404
translate Paloslios closedoor1_f02860fc:

    # "It's a deep voice that matches his intimidating form. There's a slight southern drawl to it."
    "Es una voz profunda que coincide con su forma intimidante. Tiene un ligero acento sureño."

# game/CH1.rpy:405
translate Paloslios closedoor1_bcb674a5:

    # ji "What're you doing in my house?"
    ji "¿Qué haces en mi casa?"

# game/CH1.rpy:406
translate Paloslios closedoor1_4cbe89e4:

    # "Huh?"
    "¿Eh?"

# game/CH1.rpy:417
translate Paloslios scene1_32b4f9c8:

    # "The stranger's masked face remains unreadable as they shut the door behind them, sealing you both inside."
    "El rostro enmascarado del extraño permanece ilegible mientras cierran la puerta detrás de ellos, sellándolos a ambos adentro."

# game/CH1.rpy:419
translate Paloslios scene1_a6f6b3ee:

    # "The stranger pulls down his mask to reveal his face."
    "El extraño se baja la máscara para revelar su rostro."

# game/CH1.rpy:423
translate Paloslios scene1_9240e16b:

    # "He begins dusting off the snow from his clothes and goes to hang up his overcoat by the door naturally."
    "Comienza a quitarse el polvo de la nieve de la ropa y va a colgar su abrigo junto a la puerta con naturalidad."

# game/CH1.rpy:425
translate Paloslios scene1_23f6e3a6:

    # ji "Um, I'm Jim. This is my place."
    ji "Eh, soy Jim. Este es mi lugar."

# game/CH1.rpy:426
translate Paloslios scene1_2bc131e4:

    # "You stare speechlessly at this casual statement as if he's not aware of the scare he just gave you."
    "Te quedas mirando sin palabras ante esta declaración casual como si él no fuera consciente del susto que acaba de darte."

# game/CH1.rpy:429
translate Paloslios scene1_d942ea3b:

    # ji "What's...your name?"
    ji "¿Cómo te llamas?"

# game/CH1.rpy:441
translate Paloslios scene1_023a5fc6:

    # j "[povname]..."
    j "[povname]..."

# game/CH1.rpy:444
translate Paloslios scene1_b45b681b:

    # "You keep your mouth shut and eye the stranger warily."
    "Mantienes la boca cerrada y miras al extraño con recelo."

# game/CH1.rpy:445
translate Paloslios scene1_e036a478:

    # "Jim avoids your gaze and nods in understanding."
    "Jim evita tu mirada y asiente comprendiendo."

# game/CH1.rpy:446
translate Paloslios scene1_ed30525a:

    # ji "Ok...That's fine, I guess."
    ji "Ok... Está bien, supongo."

# game/CH1.rpy:449
translate Paloslios scene1_494457a3:

    # "Jim flinches at your words, but his flat expression returns quickly."
    "Jim se estremece ante tus palabras, pero su expresión plana regresa rápidamente."

# game/CH1.rpy:450
translate Paloslios scene1_ed30525a_1:

    # ji "Ok...That's fine, I guess."
    ji "Ok... Está bien, supongo."

# game/CH1.rpy:453
translate Paloslios scene1_6200e700:

    # "There's an awkward beat before he gestures for you to take a seat by the fireplace."
    "Hay un momento incómodo antes de que te indique que te sientes junto a la chimenea."

# game/CH1.rpy:461
translate Paloslios scene1_81a079ca:

    # "Jim looks like he wants to say something, but stops himself. Then, reluctantly he replies."
    "Jim parece querer decir algo, pero se detiene. Luego, de mala gana, responde."

# game/CH1.rpy:462
translate Paloslios scene1_17f986a2:

    # j "Ok...That's fine."
    j "Vale... Está bien."

# game/CH1.rpy:463
translate Paloslios scene1_fc48fcad:

    # "You both stand there awkwardly until he nervously speaks up."
    "Ambos se quedan ahí, incómodos, hasta que él habla nerviosamente."

# game/CH1.rpy:465
translate Paloslios scene1_dce3895a:

    # ji "I'm, um, real sorry about before."
    ji "Lo siento mucho por lo de antes."

# game/CH1.rpy:470
translate Paloslios scene1_18b878ad:

    # ji "Yeah...But still..."
    ji "Sí... pero aún así..."

# game/CH1.rpy:471
translate Paloslios scene1_5ad276ae:

    # "You reassure him that it's really okay."
    "Le aseguras que está realmente bien."

# game/CH1.rpy:473
translate Paloslios scene1_58e15045:

    # ji "Okay..."
    ji "Está bien..."

# game/CH1.rpy:474
translate Paloslios scene1_1342cb39:

    # "Jim lets out a heavy sigh but still looks apologetic."
    "Jim deja escapar un profundo suspiro pero todavía parece disculparse."

# game/CH1.rpy:478
translate Paloslios scene1_93d35aa5:

    # "He looks down even more guiltily."
    "Él mira hacia abajo aún más culpable."

# game/CH1.rpy:479
translate Paloslios scene1_a345a0c6:

    # ji "I've been told I have that effect on people sometimes..."
    ji "Me han dicho que a veces tengo ese efecto en la gente..."

# game/CH1.rpy:481
translate Paloslios scene1_bd797ba0:

    # ji "..."
    ji "..."

# game/CH1.rpy:485
translate Paloslios scene1_560e669f:

    # ji "It's ok...These things happen sometimes."
    ji "Está bien... Estas cosas pasan a veces."

# game/CH1.rpy:488
translate Paloslios scene1_0333a49d:

    # "Jim looks away guiltily and then hurridly explains himself."
    "Jim aparta la mirada con sentimiento de culpabilidad y luego se apresura a explicarse."

# game/CH1.rpy:489
translate Paloslios scene1_246e29c7:

    # j "I saw your car and I was trying not to scare you...Just tryin' to let you know I'm there."
    j "Vi tu auto y estaba tratando de no asustarte... Sólo intentaba hacerte saber que estoy allí."

# game/CH1.rpy:491
translate Paloslios scene1_e4ea6018:

    # j "And then when I saw you, I got...Nervous."
    j "Y luego, cuando te vi, me puse... nervioso."

# game/CH1.rpy:492
translate Paloslios scene1_a3cddbfe:

    # "This guy did all of that because he got nervous..?"
    "¿Este tipo hizo todo eso porque se puso nervioso...?"

# game/CH1.rpy:493
translate Paloslios scene1_a3157547:

    # "You are taken aback by the contrast of the man in front of you and your first impression of him."
    "Te sorprende el contraste entre el hombre que tienes delante y tu primera impresión de él."

# game/CH1.rpy:494
translate Paloslios scene1_2244a4a3:

    # "Besides that, you are still confused about how all of this happened."
    "Además de eso, todavía estás confundido acerca de cómo sucedió todo esto."

# game/CH1.rpy:496
translate Paloslios scene1_29c21740:

    # "He gestures again towards the chair by the fireplace."
    "Vuelve a señalar la silla junto a la chimenea."

# game/CH1.rpy:497
translate Paloslios scene1_a8ee4a36:

    # j "...Please? I'll answer you the best I can, promise."
    j "...¿Por favor? Te responderé lo mejor que pueda, lo prometo."

# game/CH1.rpy:502
translate Paloslios scene1_dae8ef6f:

    # "You stiffly follow his suggestion and sit down in a chair with a creak."
    "Sigues rígidamente su sugerencia y te sientas en una silla con un crujido."

# game/CH1.rpy:505
translate Paloslios scene1_4fefe9d6:

    # "He takes off his hat and dusts off the snow before following you and taking a seat as well."
    "Se quita el sombrero y quita el polvo de la nieve antes de seguirte y tomar asiento también."

# game/CH1.rpy:506
translate Paloslios scene1_800e65bc:

    # "You are both sitting by the hearth now after your misunderstanding. You feel a mixture of adrenaline and embarrassment."
    "Ahora ambos estáis sentados junto al hogar después de vuestro malentendido. Sientes una mezcla de adrenalina y vergüenza."

# game/CH1.rpy:508
translate Paloslios scene1_760b7944:

    # j "So...What I think happened..."
    j "Entonces... lo que creo que pasó..."

# game/CH1.rpy:512
translate Paloslios scene1_955f8193:

    # "You've heard enough. You just wanted to be out of this situation."
    "Ya has oído suficiente. Sólo querías salir de esta situación."

# game/CH1.rpy:516
translate Paloslios scene1_9e9edbab:

    # "You were feeling very uncomfortable in this small space with this intimidating stranger."
    "Te sentías muy incómodo en este pequeño espacio con este intimidante extraño."

# game/CH1.rpy:526
translate Paloslios fireplacescene_day1_dae8ef6f:

    # "You stiffly follow his suggestion and sit down in a chair with a creak."
    "Sigues rígidamente su sugerencia y te sientas en una silla con un crujido."

# game/CH1.rpy:529
translate Paloslios fireplacescene_day1_4fefe9d6:

    # "He takes off his hat and dusts off the snow before following you and taking a seat as well."
    "Se quita el sombrero y quita el polvo de la nieve antes de seguirte y tomar asiento también."

# game/CH1.rpy:530
translate Paloslios fireplacescene_day1_800e65bc:

    # "You are both sitting by the hearth now after your misunderstanding. You feel a mixture of adrenaline and embarrassment."
    "Ahora ambos estáis sentados junto al hogar después de vuestro malentendido. Sientes una mezcla de adrenalina y vergüenza."

# game/CH1.rpy:532
translate Paloslios fireplacescene_day1_dce3895a:

    # ji "I'm, um, real sorry about before."
    ji "Lo siento mucho por lo de antes."

# game/CH1.rpy:537
translate Paloslios fireplacescene_day1_18b878ad:

    # ji "Yeah...But still..."
    ji "Sí... pero aún así..."

# game/CH1.rpy:538
translate Paloslios fireplacescene_day1_5ad276ae:

    # "You reassure him that it's really okay."
    "Le aseguras que está realmente bien."

# game/CH1.rpy:539
translate Paloslios fireplacescene_day1_58e15045:

    # ji "Okay..."
    ji "Está bien..."

# game/CH1.rpy:541
translate Paloslios fireplacescene_day1_1342cb39:

    # "Jim lets out a heavy sigh but still looks apologetic."
    "Jim deja escapar un profundo suspiro pero todavía parece disculparse."

# game/CH1.rpy:545
translate Paloslios fireplacescene_day1_93d35aa5:

    # "He looks down even more guiltily."
    "Él mira hacia abajo aún más culpable."

# game/CH1.rpy:546
translate Paloslios fireplacescene_day1_a345a0c6:

    # ji "I've been told I have that effect on people sometimes..."
    ji "Me han dicho que a veces tengo ese efecto en la gente..."

# game/CH1.rpy:548
translate Paloslios fireplacescene_day1_bd797ba0:

    # ji "..."
    ji "..."

# game/CH1.rpy:552
translate Paloslios fireplacescene_day1_560e669f:

    # ji "It's ok...These things happen sometimes."
    ji "Está bien... Estas cosas pasan a veces."

# game/CH1.rpy:555
translate Paloslios fireplacescene_day1_0333a49d:

    # "Jim looks away guiltily and then hurridly explains himself."
    "Jim aparta la mirada con sentimiento de culpabilidad y luego se apresura a explicarse."

# game/CH1.rpy:556
translate Paloslios fireplacescene_day1_246e29c7:

    # j "I saw your car and I was trying not to scare you...Just tryin' to let you know I'm there."
    j "Vi tu auto y estaba tratando de no asustarte... Sólo intentaba hacerte saber que estoy allí."

# game/CH1.rpy:558
translate Paloslios fireplacescene_day1_e4ea6018:

    # j "And then when I saw you, I got...Nervous."
    j "Y luego, cuando te vi, me puse... nervioso."

# game/CH1.rpy:559
translate Paloslios fireplacescene_day1_a3cddbfe:

    # "This guy did all of that because he got nervous..?"
    "¿Este tipo hizo todo eso porque se puso nervioso...?"

# game/CH1.rpy:561
translate Paloslios fireplacescene_day1_a3157547:

    # "You are taken aback by the contrast of the man in front of you and your first impression of him."
    "Te sorprende el contraste entre el hombre que tienes delante y tu primera impresión de él."

# game/CH1.rpy:562
translate Paloslios fireplacescene_day1_2244a4a3:

    # "Besides that, you are still confused about how all of this happened."
    "Además de eso, todavía estás confundido acerca de cómo sucedió todo esto."

# game/CH1.rpy:565
translate Paloslios sit_part2_72d89518:

    # "Jim thinks for a moment and speaks more quietly because of self-consciousness about how his voice sounds."
    "Jim piensa por un momento y habla más bajo debido a la timidez sobre cómo suena su voz."

# game/CH1.rpy:566
translate Paloslios sit_part2_659f6afa:

    # "His voice still comes out as a low rumble."
    "Su voz todavía suena como un estruendo bajo."

# game/CH1.rpy:567
translate Paloslios sit_part2_f3998c1d:

    # ji "Were you trying to go to that...tiny bear house?"
    ji "¿Estabas intentando ir a esa... pequeña casa de osos?"

# game/CH1.rpy:568
translate Paloslios sit_part2_8ebbc0c0:

    # pov "Ugh, you mean the Little Cub Cabin? Then, yes."
    pov "Uf, ¿te refieres a la cabaña Little Cub? Entonces sí."

# game/CH1.rpy:570
translate Paloslios sit_part2_46724fe9:

    # ji "Right. You went way too far down the trail then."
    ji "Bien. Entonces fuiste demasiado lejos en el camino."

# game/CH1.rpy:571
translate Paloslios sit_part2_222cda1a:

    # ji "Probably missed it with all the snow and pines. Easy to happen when the snow gets like this."
    ji "Probablemente me lo perdí con toda la nieve y los pinos. Es fácil que suceda cuando la nieve se pone así."

# game/CH1.rpy:572
translate Paloslios sit_part2_f25f3b35:

    # "Your face burned with embarrassment at your mistake and the whole misunderstanding. So much for a relaxing getaway."
    "Tu cara ardía de vergüenza por tu error y todo el malentendido. Hasta aquí una escapada relajante."

# game/CH1.rpy:573
translate Paloslios sit_part2_baa217c9:

    # pov "That makes sense..."
    pov "Eso tiene sentido..."

# game/CH1.rpy:575
translate Paloslios sit_part2_cfc08cc2:

    # "An awkward silence stretches between you two until Jim speaks up again."
    "Un silencio incómodo se extiende entre ustedes dos hasta que Jim vuelve a hablar."

# game/CH1.rpy:577
translate Paloslios sit_part2_40d15348:

    # ji "I think the storm will pass in a couple of days. You can stay here until then."
    ji "Creo que la tormenta pasará en un par de días. Puedes quedarte aquí hasta entonces."

# game/CH1.rpy:578
translate Paloslios sit_part2_d63a8434:

    # "A couple of days?!"
    "¡¿Un par de días?!"

# game/CH1.rpy:582
translate Paloslios stayday1_c41e93fa:

    # j "Well, now that we've gotten to know each other more...Can I know what your name is?"
    j "Bueno, ahora que nos conocemos más... ¿Puedo saber cómo te llamas?"

# game/CH1.rpy:587
translate Paloslios stayday1_023a5fc6:

    # j "[povname]..."
    j "[povname]..."

# game/CH1.rpy:588
translate Paloslios stayday1_0c2bddbd:

    # "You sit there and process what's happened."
    "Te sientas ahí y procesas lo que pasó."

# game/CH1.rpy:594
translate Paloslios stayday1_c8925eb0:

    # "Jim nods sympathetically."
    "Jim asiente con simpatía."

# game/CH1.rpy:596
translate Paloslios stayday1_ab422021:

    # j "...It's for the best, you can trust me on that."
    j "...Es lo mejor, puedes confiar en mí en eso."

# game/CH1.rpy:597
translate Paloslios stayday1_f3ea697a:

    # "You slump in your chair a bit in defeat at your own helplessness."
    "Te desplomas en tu silla un poco derrotado por tu propia impotencia."

# game/CH1.rpy:601
translate Paloslios stayday1_7dad00d9:

    # "Jim nods, a small smile tugging at the corners of his lips."
    "Jim asiente, una pequeña sonrisa tirando de las comisuras de sus labios."

# game/CH1.rpy:602
translate Paloslios stayday1_558d6a87:

    # "As if you have a choice, but now you feel even more grateful after inconveniencing your cabin neighbor."
    "Como si tuvieras opción, pero ahora te sientes aún más agradecido después de molestar a tu vecino de cabaña."

# game/CH1.rpy:603
translate Paloslios stayday1_f7fb2932:

    # "At least he seemed to be nonchalant about the whole situation."
    "Al menos parecía indiferente ante toda la situación."

# game/CH1.rpy:605
translate Paloslios stayday1_9f913548:

    # ji "It can get lonely out here sometimes, haven't had company in a long time."
    ji "A veces puede resultar muy solitario aquí, no he tenido compañía en mucho tiempo."

# game/CH1.rpy:606
translate Paloslios stayday1_c87475ce:

    # "You nod back, feeling a bit more at ease now that you know he's not some deranged stranger. If anything, you were the stranger in his house now and yet he is being so welcoming."
    "Usted asiente en respuesta, sintiéndose un poco más a gusto ahora que sabe que no es un extraño trastornado. En todo caso, ahora eras el extraño en su casa y, sin embargo, él está siendo muy acogedor."

# game/CH1.rpy:611
translate Paloslios stayday1_c50142a1:

    # j "W-what? I just told you there's a storm-"
    j "¿Q-qué? Te acabo de decir que hay una tormenta."

# game/CH1.rpy:612
translate Paloslios stayday1_5ec01d19:

    # "You didn't care as you got up from your seat, picked up your luggage, and headed out the door."
    "No te importó cuando te levantaste de tu asiento, recogiste tu equipaje y saliste por la puerta."

# game/CH1.rpy:614
translate Paloslios stayday1_2210cd68:

    # "Jim moves to stand up and starts gesturing around the room."
    "Jim se levanta y comienza a hacer gestos por la habitación."

# game/CH1.rpy:619
translate Paloslios fireplace_seen_044de8f9:

    # j "So...The bathroom is in the corner there."
    j "Entonces... El baño está allí en la esquina."

# game/CH1.rpy:621
translate Paloslios fireplace_seen_0c99d094:

    # ji "Oh, and feel free to put your things in the spare room over there on your right."
    ji "Ah, y siéntete libre de dejar tus cosas en la habitación de invitados que está a tu derecha."

# game/CH1.rpy:623
translate Paloslios fireplace_seen_348ecbe4:

    # j "My room's the one to your left by the front door."
    j "Mi habitación está a tu izquierda junto a la puerta principal."

# game/CH1.rpy:626
translate Paloslios fireplace_seen_1e5b4b84:

    # ji "It's not much but-"
    ji "No es mucho pero-"

# game/CH1.rpy:627
translate Paloslios fireplace_seen_6066c9c7:

    # ji "You're safe here..."
    ji "Estás a salvo aquí..."

# game/CH1.rpy:629
translate Paloslios fireplace_seen_e14e0740:

    # "Jim points to the pot on the stove next."
    "Jim señala a continuación la olla en la estufa."

# game/CH1.rpy:630
translate Paloslios fireplace_seen_e0483755:

    # ji "I'll have some hot cocoa too after all of that."
    ji "Yo también tomaré un poco de chocolate caliente después de todo eso."

# game/CH1.rpy:632
translate Paloslios fireplace_seen_d94f3230:

    # j "Want your [drink] reheated since you've helped yourself to some already?"
    j "¿Quieres recalentar tu [drink] ya que ya te has servido un poco?"

# game/CH1.rpy:633
translate Paloslios fireplace_seen_f6a5e1b6:

    # "You groan at any reminders of your unfortunate beginnings here."
    "Te quejas ante cualquier recordatorio de tus desafortunados comienzos aquí."

# game/CH1.rpy:637
translate Paloslios fireplace_seen_7cd88173:

    # "Jim gives you a curt nod and grabs your cup."
    "Jim asiente brevemente y agarra tu taza."

# game/CH1.rpy:638
translate Paloslios fireplace_seen_eba2fc30:

    # "Things are still pretty awkward, but it was kinda sweet that he was trying to be a good host."
    "Las cosas siguen siendo bastante incómodas, pero fue un poco dulce que estuviera tratando de ser un buen anfitrión."

# game/CH1.rpy:639
translate Paloslios fireplace_seen_e7db0751:

    # j "How 'bout you check out your room while I reheat the drinks?"
    j "¿Qué tal si revisas tu habitación mientras recaliento las bebidas?"

# game/CH1.rpy:640
translate Paloslios fireplace_seen_11b7237e:

    # "You nod and grab your luggage to take to your room."
    "Asientes y agarras tu equipaje para llevarlo a tu habitación."

# game/CH1.rpy:642
translate Paloslios fireplace_seen_e34bc9bc:

    # "Jim looks disappointed but lets you go."
    "Jim parece decepcionado pero te deja ir."

# game/CH1.rpy:644
translate Paloslios fireplace_seen_7424c14a:

    # j "Oh, Ok..."
    j "Ah, vale..."

# game/CH1.rpy:651
translate Paloslios fireplace_seen_1aeaf8d1:

    # "The room is small, but just as cozy as the rest of the cabin. Simple with its furnishings, but it's all you need."
    "La habitación es pequeña, pero tan acogedora como el resto de la cabaña. Sencillo con su mobiliario, pero es todo lo que necesitas."

# game/CH1.rpy:652
translate Paloslios fireplace_seen_7a8e9675:

    # "It's minimally decorated like the rest of his cabin, but it has a bed, a nightstand, and a lamp."
    "Está mínimamente decorada como el resto de su cabaña, pero tiene una cama, una mesita de noche y una lámpara."

# game/CH1.rpy:654
translate Paloslios fireplace_seen_40d85ade:

    # "And now it has your suitcase and belongings in a corner."
    "Y ahora tiene tu maleta y pertenencias en un rincón."

# game/CH1.rpy:663
translate Paloslios fireplace_seen_58ae9cb4:

    # "You sit down on the bed with a creak. The bed feels impossibly soft beneath you, urging your tense muscles from earlier to uncoil."
    "Te sientas en la cama con un crujido. La cama se siente increíblemente suave debajo de ti, lo que insta a tus músculos tensos de antes a relajarse."

# game/CH1.rpy:664
translate Paloslios fireplace_seen_ca45eedd:

    # "You let out a long breath and your hand traces absentmindedly over the quilted blanket. Its fabric is worn, but comforting."
    "Dejas escapar un largo suspiro y tu mano recorre distraídamente la manta acolchada. Su tejido es desgastado, pero reconfortante."

# game/CH1.rpy:666
translate Paloslios fireplace_seen_036c6be2:

    # "What a situation- You hear the muffled clattering of Jim in the kitchen and snow battering against the walls."
    "Qué situación... Se oye el ruido sordo de Jim en la cocina y la nieve golpeando las paredes."

# game/CH1.rpy:667
translate Paloslios fireplace_seen_72adc556:

    # "This was not what you had expected at all and you wonder how it'll all go..."
    "Esto no era lo que esperabas en absoluto y te preguntas cómo irá todo..."

# game/CH1.rpy:668
translate Paloslios fireplace_seen_ab39daaa:

    # ji "Um, your [drink] is ready."
    ji "Um, tu [drink] está listo."

# game/CH1.rpy:669
translate Paloslios fireplace_seen_c8e8a14a:

    # "Jim's voice from the other room pulls you from your thoughts and you get up to join him."
    "La voz de Jim desde la otra habitación te saca de tus pensamientos y te levantas para unirte a él."

# game/CH1.rpy:678
translate Paloslios fireplace_seen_b8defa53:

    # "You sit across from Jim as he hands you a reheated [drink]."
    "Te sientas frente a Jim mientras te entrega un [drink] recalentado."

# game/CH1.rpy:681
translate Paloslios fireplace_seen_88343946:

    # "Jim cradles his own mug in his hands, savoring its warmth before taking little sips. His posture is more relaxed, but still seems a bit shy."
    "Jim sostiene su propia taza en sus manos, saboreando su calidez antes de tomar pequeños sorbos. Su postura es más relajada, pero todavía parece un poco tímido."

# game/CH1.rpy:682
translate Paloslios fireplace_seen_1a88e1ac:

    # "You get a better look at him now that things are less intense."
    "Puedes verlo mejor ahora que las cosas son menos intensas."

# game/CH1.rpy:684
translate Paloslios fireplace_seen_2657b628:

    # "His pale hair is damp and disheveled from the snowstorm. And he keeps it pretty long."
    "Su cabello pálido está húmedo y despeinado por la tormenta de nieve. Y lo mantiene bastante tiempo."

# game/CH1.rpy:686
translate Paloslios fireplace_seen_2e714cd7:

    # "His eyes flick to you occasionally before glancing back down at his drink."
    "Sus ojos te miran de vez en cuando antes de volver a mirar su bebida."

# game/CH1.rpy:688
translate Paloslios fireplace_seen_e50326c7:

    # ji "Sorry...I'm not used to having company I guess..."
    ji "Lo siento... Supongo que no estoy acostumbrado a tener compañía..."

# game/CH1.rpy:689
translate Paloslios fireplace_seen_33184fb0:

    # "What do you do?"
    "¿Qué haces?"

# game/CH1.rpy:693
translate Paloslios fireplace_seen_efa9b966:

    # pov "So..."
    pov "Entonces..."

# game/CH1.rpy:699
translate Paloslios fireq_d9717f36:

    # ji "Hmm, just checking some traps I set out in the woods nearby."
    ji "Hmm, solo estoy revisando algunas trampas que puse en el bosque cercano."

# game/CH1.rpy:700
translate Paloslios fireq_806fc40c:

    # pov "Traps?"
    pov "¿Trampas?"

# game/CH1.rpy:702
translate Paloslios fireq_b9066ba7:

    # ji "Traps for small game like...rabbits and such. Mostly..."
    ji "Trampas para caza menor como... conejos y demás. Mayormente..."

# game/CH1.rpy:704
translate Paloslios fireq_70bb6f0d:

    # ji "Nothing in the traps today. Probably all hiding from the storm."
    ji "Nada en las trampas hoy. Probablemente todos se esconden de la tormenta."

# game/CH1.rpy:705
translate Paloslios fireq_b6a0b230:

    # pov "Oh, I see."
    pov "Ah, claro."

# game/CH1.rpy:706
translate Paloslios fireq_2d862710:

    # "That would explain the mystery game meat in the fridge earlier."
    "Eso explicaría la misteriosa carne de caza en el refrigerador antes."

# game/CH1.rpy:707
translate Paloslios fireq_efa9b966:

    # pov "So..."
    pov "Entonces..."

# game/CH1.rpy:712
translate Paloslios fireq_891637ca:

    # "He glances at you and then answers while looking into the fire."
    "Él te mira y luego responde mientras mira al fuego."

# game/CH1.rpy:713
translate Paloslios fireq_6dd16579:

    # ji "Used to be not all of the time. Just...when I needed to get away. But now, yeah...this is where I live."
    ji "Solía no serlo todo el tiempo. Justo... cuando necesitaba escapar. Pero ahora, sí... aquí es donde vivo."

# game/CH1.rpy:715
translate Paloslios fireq_ac2fb1de:

    # "His voice is steady, but there's something vulnerable in his tone like he's not used to explaining himself."
    "Su voz es firme, pero hay algo vulnerable en su tono, como si no estuviera acostumbrado a explicarse."

# game/CH1.rpy:716
translate Paloslios fireq_cdfaec1a:

    # pov "Get away from what?"
    pov "¿Alejarnos de qué?"

# game/CH1.rpy:717
translate Paloslios fireq_b0fa9b5b:

    # "He seems to hesitate. Maybe from trying to find the right words before settling on what to say."
    "Parece dudar. Tal vez por tratar de encontrar las palabras adecuadas antes de decidir qué decir."

# game/CH1.rpy:719
translate Paloslios fireq_d9d50f95:

    # ji "Everything."
    ji "Todo."

# game/CH1.rpy:721
translate Paloslios fireq_1fddbed0:

    # ji "The noise. The people. It's just...too much."
    ji "El ruido. Pueblo. Es simplemente... demasiado."

# game/CH1.rpy:725
translate Paloslios fireq_d801649e:

    # "You nod, feeling a strange sense of understanding."
    "Asientes, sintiendo una extraña sensación de comprensión."

# game/CH1.rpy:726
translate Paloslios fireq_7ca45fec:

    # pov "I get it. It's why I wanted to come out here too. Just...needed a break from it all."
    pov "Lo entiendo. Por eso quería venir aquí también. Sólo... necesitaba un descanso de todo."

# game/CH1.rpy:727
translate Paloslios fireq_75178c5e:

    # pov "I wish I could be away all the time, but I have responsibilities."
    pov "Desearía poder estar fuera todo el tiempo, pero tengo responsabilidades."

# game/CH1.rpy:729
translate Paloslios fireq_a454b16c:

    # "You don't really feel that way about living in the city like Jim's saying."
    "Realmente no te sientes así viviendo en la ciudad como dice Jim."

# game/CH1.rpy:730
translate Paloslios fireq_381365ee:

    # pov "Hmm, I don't have a problem with that part of city life."
    pov "Hmm, no tengo ningún problema con esa parte de la vida de la ciudad."

# game/CH1.rpy:731
translate Paloslios fireq_f8087df1:

    # pov "But it's nice getting a change of scenery sometimes."
    pov "Pero a veces es agradable cambiar de escenario."

# game/CH1.rpy:733
translate Paloslios fireq_7d01798d:

    # "You nod in understanding, although not to the extent that Jim is talking about it."
    "Asientes con comprensión, aunque no hasta el punto de que Jim esté hablando de ello."

# game/CH1.rpy:734
translate Paloslios fireq_0b677f74:

    # pov "I'm sure I'd miss the city eventually."
    pov "Estoy seguro de que eventualmente extrañaría la ciudad."

# game/CH1.rpy:735
translate Paloslios fireq_e06ee8ca:

    # pov "But I get it. It's why I wanted to come out here too. Just...needed a break from it all sometimes."
    pov "Pero lo entiendo. Por eso quería venir aquí también. Sólo... a veces necesitaba un descanso de todo."

# game/CH1.rpy:737
translate Paloslios fireq_35f472be:

    # "Jim's lips twitched into a faint smile. And for the first time since talking, his gaze holds yours for a while."
    "Los labios de Jim se torcieron en una leve sonrisa. Y por primera vez desde que hablamos, su mirada sostiene la tuya por un momento."

# game/CH1.rpy:738
translate Paloslios fireq_6823cf46:

    # ji "And instead, you end up in the wrong cabin."
    ji "Y en lugar de eso, terminas en la cabina equivocada."

# game/CH1.rpy:742
translate Paloslios fireq_70540d93:

    # "Your cheeks warm as you let out a soft laugh."
    "Tus mejillas se calientan mientras dejas escapar una suave risa."

# game/CH1.rpy:743
translate Paloslios fireq_eadafa6e:

    # pov "Yeah, not exactly the peaceful getaway I had in mind."
    pov "Sí, no es exactamente la escapada pacífica que tenía en mente."

# game/CH1.rpy:745
translate Paloslios fireq_c826187a:

    # ji "Hahaha..."
    ji "Jajaja..."

# game/CH1.rpy:746
translate Paloslios fireq_a2af749f:

    # "You're surprised by the rich depth of his chuckle despite how he tried to quiet it. It sends a pleasant warmth through you."
    "Te sorprende la rica profundidad de su risa a pesar de cómo intentó calmarla. Envía un calor agradable a través de ti."

# game/CH1.rpy:748
translate Paloslios fireq_7c0f1c41:

    # ji "Well, I guess it's not every day you accidentally break into someone else's house."
    ji "Bueno, supongo que no todos los días entras accidentalmente en la casa de otra persona."

# game/CH1.rpy:749
translate Paloslios fireq_c69a7acd:

    # "The initial tension between you is melted away as you both laugh about it."
    "La tensión inicial entre ustedes se desvanece cuando ambos se ríen de ello."

# game/CH1.rpy:751
translate Paloslios fireq_03429e6e:

    # ji "I hope you do get what you came here for..."
    ji "Espero que consigas lo que viniste a buscar..."

# game/CH1.rpy:752
translate Paloslios fireq_b303c482:

    # "You can't help, but smile at his gentle words."
    "No puedes evitar sonreír ante sus amables palabras."

# game/CH1.rpy:754
translate Paloslios fireq_4627ba28:

    # "You groan at the reminder."
    "Gimes ante el recordatorio."

# game/CH1.rpy:756
translate Paloslios fireq_7dee50d0:

    # j "Heh, sorry...I didn't mean to rub it in."
    j "Je, lo siento... no era mi intención restregárselo."

# game/CH1.rpy:758
translate Paloslios fireq_b60ee5b2:

    # "You silently look at him."
    "Lo miras en silencio."

# game/CH1.rpy:760
translate Paloslios fireq_67094553:

    # "Jim clears his throat awkwardly and takes a sip of his drink."
    "Jim se aclara la garganta con torpeza y toma un sorbo de su bebida."

# game/CH1.rpy:761
translate Paloslios fireq_b9e2499a:

    # j "Nevermind."
    j "No importa."

# game/CH1.rpy:762
translate Paloslios fireq_efa9b966_1:

    # pov "So..."
    pov "Entonces..."

# game/CH1.rpy:767
translate Paloslios fireq_fab07821:

    # ji "Yeah...but it should calm down in a day or two."
    ji "Sí... pero debería calmarse en uno o dos días."

# game/CH1.rpy:769
translate Paloslios fireq_92d39bb5:

    # ji "And, if you want, I can make sure you get to the right cabin then."
    ji "Y, si quieres, puedo asegurarme de que llegues a la cabina correcta."

# game/CH1.rpy:771
translate Paloslios fireq_601b1172:

    # ji "The mountain weather can be unpredictable. One moment, it's clear. Then, dangerous in an instant."
    ji "El clima de montaña puede ser impredecible. Un momento, está claro. Entonces, peligroso en un instante."

# game/CH1.rpy:772
translate Paloslios fireq_1affad28:

    # ji "It's snowing a bit early this year...but it's not uncommon. The snow falls hard, and the wind...well it howls like it's got something to prove."
    ji "Está nevando un poco temprano este año... pero no es raro. La nieve cae fuerte y el viento... bueno, aúlla como si tuviera algo que demostrar."

# game/CH1.rpy:773
translate Paloslios fireq_af398ed0:

    # "You nod along at his explanation. You weren't aware of how it was in the mountains."
    "Asientes con la cabeza ante su explicación. No eras consciente de cómo eran las montañas."

# game/CH1.rpy:775
translate Paloslios fireq_d277c2c8:

    # "He lets out a soft sigh before continuing, running a hand through his messy hair."
    "Deja escapar un suave suspiro antes de continuar, pasando una mano por su cabello desordenado."

# game/CH1.rpy:776
translate Paloslios fireq_712b26bf:

    # ji "I knew the second I saw you that you were not used to this."
    ji "En cuanto te vi supe que no estabas acostumbrado a esto."

# game/CH1.rpy:777
translate Paloslios fireq_ada5a3d4:

    # j "If you don't know what you're doing and you try to go out there...well, you're pretty much asking for trouble then."
    j "Si no sabes lo que estás haciendo e intentas salir... bueno, entonces te estás buscando problemas."

# game/CH1.rpy:778
translate Paloslios fireq_1f52cef8:

    # "You notice a shift in his tone when talking about the storm- there's something protective about it."
    "Notas un cambio en su tono cuando habla de la tormenta: hay algo protector en ello."

# game/CH1.rpy:779
translate Paloslios fireq_884591cc:

    # "Like he's trying to prepare you or maybe even shield you from the wildness of the mountain."
    "Como si estuviera tratando de prepararte o tal vez incluso protegerte de lo salvaje de la montaña."

# game/CH1.rpy:781
translate Paloslios fireq_f5a8e525:

    # ji "Just wait it out. Don't...venture out if you don't have to."
    ji "Sólo espera. No... te aventures si no es necesario."

# game/CH1.rpy:782
translate Paloslios fireq_750ebb96:

    # "The storm outside wails a bit louder for a moment as if protesting, and Jim shifts his gaze out the window."
    "La tormenta afuera aúlla un poco más fuerte por un momento, como si protestara, y Jim desvía la mirada por la ventana."

# game/CH1.rpy:784
translate Paloslios fireq_d6081434:

    # ji "I've been stuck in here before. You just get used to it and then it's not so bad."
    ji "He estado atrapado aquí antes. Simplemente te acostumbras y ya no es tan malo."

# game/CH1.rpy:785
translate Paloslios fireq_5cc6363d:

    # "You take in his words. You get the impression that he's used to navigating the chaos of the mountain, and with him, maybe you could too."
    "Asimilas sus palabras. Da la impresión de que está acostumbrado a navegar en el caos de la montaña y, con él, tal vez tú también puedas hacerlo."

# game/CH1.rpy:786
translate Paloslios fireq_efa9b966_2:

    # pov "So..."
    pov "Entonces..."

# game/CH1.rpy:792
translate Paloslios fireq_c46d5561:

    # ji "Uh, I like to be in nature...and be alone."
    ji "Uh, me gusta estar en la naturaleza... y estar solo."

# game/CH1.rpy:793
translate Paloslios fireq_8fb72aa7:

    # pov "Yeah? Like hiking?"
    pov "¿Sí? ¿Te gusta el senderismo?"

# game/CH1.rpy:795
translate Paloslios fireq_23ae8139:

    # ji "Hmm, I hunt and fish when the weather's better. Sometimes I make stuff..."
    ji "Hmm, cazo y pesco cuando hace mejor tiempo. A veces hago cosas..."

# game/CH1.rpy:797
translate Paloslios fireq_1b2e4057:

    # ji "There's a town a ways from here, but I mostly just keep to myself..."
    ji "Hay un pueblo muy lejos de aquí, pero sobre todo me mantengo en secreto..."

# game/CH1.rpy:799
translate Paloslios fireq_965c5201:

    # "His eyes dart nervously around and you get the impression that he's not used to talking about himself like this."
    "Sus ojos se mueven nerviosamente alrededor y da la impresión de que no está acostumbrado a hablar así de sí mismo."

# game/CH1.rpy:801
translate Paloslios fireq_fe0dfebb:

    # "You decide not to get into it for now, for his sake, but you are curious."
    "Decides no entrar en detalles por ahora, por su bien, pero sientes curiosidad."

# game/CH1.rpy:803
translate Paloslios fireq_0dd05cac:

    # "He seems like the type to say things when he's ready."
    "Parece del tipo que dice cosas cuando está listo."

# game/CH1.rpy:804
translate Paloslios fireq_efa9b966_3:

    # pov "So..."
    pov "Entonces..."

# game/CH1.rpy:809
translate Paloslios fireq_e341a429:

    # ji "Yeah...to be honest, you're the first person I've really talked to in a couple of months."
    ji "Sí... para ser honesto, eres la primera persona con la que realmente he hablado en un par de meses."

# game/CH1.rpy:811
translate Paloslios fireq_e3d3f3ba:

    # ji "Other than when I'm picking up supplies in town."
    ji "Aparte de cuando estoy recogiendo suministros en la ciudad."

# game/CH1.rpy:813
translate Paloslios fireq_00d179ab:

    # "He awkwardly shifts in his seat and rubs the back of his neck like he's unsure of how to continue."
    "Se mueve torpemente en su asiento y se frota la nuca como si no estuviera seguro de cómo continuar."

# game/CH1.rpy:815
translate Paloslios fireq_94afed0a:

    # ji "I guess you could probably tell with how out of practice I am with all of this social stuff."
    ji "Supongo que probablemente te darás cuenta de lo poco que tengo con todas estas cosas sociales."

# game/CH1.rpy:817
translate Paloslios fireq_d3b7b21a:

    # "He gives a dry laugh, but it's not exactly a happy one."
    "Él suelta una risa seca, pero no es exactamente una risa feliz."

# game/CH1.rpy:819
translate Paloslios fireq_a2a413d4:

    # ji "The isolation, it...it's easier this way. And I've never minded being by myself. It's...peaceful."
    ji "El aislamiento, es... es más fácil de esta manera. Y nunca me ha importado estar solo. Es... tranquilo."

# game/CH1.rpy:821
translate Paloslios fireq_5567bc31:

    # ji "I don't...generally like people, but it's been nice...talking with you."
    ji "No... generalmente me gusta la gente, pero ha sido agradable... hablar contigo."

# game/CH1.rpy:822
translate Paloslios fireq_51c42b21:

    # "This admission lingers in the air as you both take it in. You're touched by his openness and vulnerability in this moment."
    "Esta admisión permanece en el aire mientras ambos la asimilan. Te conmueve su franqueza y vulnerabilidad en este momento."

# game/CH1.rpy:823
translate Paloslios fireq_525e2c87:

    # pov "Well, I'm glad I could be the one you talked to."
    pov "Bueno, me alegro de poder ser con quien hablaste."

# game/CH1.rpy:825
translate Paloslios fireq_f985a26e:

    # "Jim smiles at this and takes another shy sip from his mug."
    "Jim sonríe ante esto y toma otro tímido sorbo de su taza."

# game/CH1.rpy:826
translate Paloslios fireq_cb64a08c:

    # "A moment of warmth settles between both of you and you feel a bit closer."
    "Un momento de calidez se instala entre ambos y os sentís un poco más cerca."

# game/CH1.rpy:827
translate Paloslios fireq_efa9b966_4:

    # pov "So..."
    pov "Entonces..."

# game/CH1.rpy:830
translate Paloslios fireq_02cce33d:

    # "You're done asking questions for now."
    "Ya terminaste de hacer preguntas por ahora."

# game/CH1.rpy:831
translate Paloslios fireq_e550811c:

    # "You both finish up the rest of your drinks in silence."
    "Ambos terminan el resto de sus bebidas en silencio."

# game/CH1.rpy:834
translate Paloslios fireq_acf0b829:

    # "You don't mind the silence and it seems like Jim doesn't either."
    "No te importa el silencio y parece que a Jim tampoco."

# game/CH1.rpy:835
translate Paloslios fireq_1c5818e3:

    # "Soon the silence stretches long enough to become a comfortable one rather than an awkward lull."
    "Pronto el silencio se prolonga lo suficiente como para convertirse en una pausa cómoda en lugar de una pausa incómoda."

# game/CH1.rpy:837
translate Paloslios fireq_ca22641c:

    # "The fire crackles and the warm glow fills you with a pleasant calm."
    "El fuego crepita y el cálido resplandor te infunde una agradable calma."

# game/CH1.rpy:839
translate Paloslios fireq_e28f8bbd:

    # "You both enjoy your drinks and warm up together by the fire."
    "Ambos disfrutan de sus bebidas y se calientan juntos junto al fuego."

# game/CH1.rpy:841
translate Paloslios fireq_4e3a5ae6:

    # pov "That's alright, I am quite the...unexpected guest right now."
    pov "Está bien, soy todo un... invitado inesperado en este momento."

# game/CH1.rpy:843
translate Paloslios fireq_d6bc7dca:

    # pov "What would you prefer? We can just enjoy the silence if you'd like."
    pov "¿Qué preferirías? Podemos simplemente disfrutar del silencio si quieres."

# game/CH1.rpy:845
translate Paloslios fireq_0dafdd57:

    # ji "Oh...well, of course, I don't mind not talking..."
    ji "Oh... bueno, por supuesto, no me importa no hablar..."

# game/CH1.rpy:847
translate Paloslios fireq_1661c50d:

    # ji "-But since this is a bit of a special occasion, I'd like to try talking."
    ji "-Pero como esta es una ocasión un poco especial, me gustaría intentar hablar."

# game/CH1.rpy:849
translate Paloslios fireq_94523e92:

    # ji "If that's aight with you?"
    ji "¿Si te parece bien?"

# game/CH1.rpy:850
translate Paloslios fireq_a216cd11:

    # ji "I'm not...really sure where to start though."
    ji "Aunque no estoy... muy seguro de por dónde empezar."

# game/CH1.rpy:851
translate Paloslios fireq_89354cc0:

    # "Jim looks at you expectantly. He's hopeful that you'll start the conversation."
    "Jim te mira expectante. Tiene la esperanza de que usted inicie la conversación."

# game/CH1.rpy:852
translate Paloslios fireq_efa9b966_5:

    # pov "So..."
    pov "Entonces..."

# game/CH1.rpy:855
translate Paloslios fireq_550d2560:

    # "Jim looks at you and finally asks you a question himself."
    "Jim te mira y finalmente te hace una pregunta."

# game/CH1.rpy:856
translate Paloslios fireq_4cdfd913:

    # ji "So...how are you feeling about being stuck here?"
    ji "Entonces... ¿cómo te sientes al estar atrapado aquí?"

# game/CH1.rpy:858
translate Paloslios fireq_a0d22bc2:

    # "He quickly looks away again while anticipating your answer. He has a complicated look on his face."
    "Rápidamente aparta la mirada mientras anticipa su respuesta. Tiene una expresión complicada en su rostro."

# game/CH1.rpy:859
translate Paloslios fireq_3a39384e:

    # "You wonder why that is. He's a hard man to read."
    "Te preguntas por qué es así. Es un hombre difícil de leer."

# game/CH1.rpy:860
translate Paloslios fireq_0f5de544:

    # "You..."
    "Tu..."

# game/CH1.rpy:864
translate Paloslios fireq_94f9321e:

    # pov "I appreciate all that you've done for me. But I'd like to get to where I'm supposed to be as soon as I can."
    pov "Aprecio todo lo que has hecho por mí. Pero me gustaría llegar a donde se supone que debo estar tan pronto como pueda."

# game/CH1.rpy:866
translate Paloslios fireq_d90e4b89:

    # ji "I see...of course, that makes sense."
    ji "Ya veo... por supuesto, eso tiene sentido."

# game/CH1.rpy:867
translate Paloslios fireq_9097005c:

    # "You are grateful for the shelter and how helpful Jim has been."
    "Estás agradecido por el refugio y por lo útil que ha sido Jim."

# game/CH1.rpy:868
translate Paloslios fireq_70c8d085:

    # "You'll be happy to get along with Jim while you're here and go your separate ways when possible."
    "Estarás feliz de llevarte bien con Jim mientras estés aquí y tomar caminos separados cuando sea posible."

# game/CH1.rpy:869
translate Paloslios fireq_64de1e73:

    # "You did come here for a private cabin getaway after all."
    "Después de todo, viniste aquí para una escapada en una cabaña privada."

# game/CH1.rpy:872
translate Paloslios fireq_9d6a643b:

    # pov "I'd really like to go the second the weather allows it."
    pov "Realmente me gustaría ir en cuanto el clima lo permita."

# game/CH1.rpy:874
translate Paloslios fireq_794812d2:

    # ji "Right...I'll make sure to let you know as soon as that happens..."
    ji "Bien... Me aseguraré de avisarte tan pronto como eso suceda..."

# game/CH1.rpy:875
translate Paloslios fireq_486e5a56:

    # "It can't be helped that you're unwilling stuck here. So far it's been okay, but you don't want to push your luck."
    "No se puede evitar que no estés dispuesto a quedarte atrapado aquí. Hasta ahora todo ha ido bien, pero no quieres tentar a la suerte."

# game/CH1.rpy:876
translate Paloslios fireq_ca1f03dd:

    # "He is still a complete stranger and you don't want to be stuck in such a small space with him."
    "Sigue siendo un completo desconocido y no querrás quedarte atrapado en un espacio tan pequeño con él."

# game/CH1.rpy:877
translate Paloslios fireq_64de1e73_1:

    # "You did come here for a private cabin getaway after all."
    "Después de todo, viniste aquí para una escapada en una cabaña privada."

# game/CH1.rpy:882
translate Paloslios fireq_39301ce0:

    # pov "I actually really like it here...I could see myself spending my whole stay here honestly."
    pov "De hecho, me gusta mucho estar aquí... Sinceramente, me veo pasando toda mi estancia aquí."

# game/CH1.rpy:883
translate Paloslios fireq_9588442a:

    # pov "It's been nice having you as company."
    pov "Ha sido un placer tenerte como compañía."

# game/CH1.rpy:885
translate Paloslios fireq_4b7df3d2:

    # ji "I- Well..."
    ji "Yo- Bueno..."

# game/CH1.rpy:887
translate Paloslios fireq_6e40462f:

    # ji "I- I'll be honest too, I've been liking your company too-"
    ji "Yo también seré honesto, a mí también me ha gustado tu compañía."

# game/CH1.rpy:889
translate Paloslios fireq_7e2dc27b:

    # ji "What I'm trying to say is-"
    ji "Lo que estoy tratando de decir es-"

# game/CH1.rpy:891
translate Paloslios fireq_51b0d5ce:

    # ji "You could stay here longer...if you want..."
    ji "Podrías quedarte aquí más tiempo... si quieres..."

# game/CH1.rpy:893
translate Paloslios fireq_da50d5fd:

    # ji "But you don't gotta decide now. And maybe your feelings will change."
    ji "Pero no tienes que decidir ahora. Y tal vez tus sentimientos cambien."

# game/CH1.rpy:895
translate Paloslios fireq_e5b6b538:

    # ji "Although, I am happy you feel that way right now."
    ji "Aunque me alegra que te sientas así en este momento."

# game/CH1.rpy:896
translate Paloslios fireq_6994eb57:

    # "You smile at his flustered, but sincere response. You guess you'll have to see how things go."
    "Sonríes ante su respuesta nerviosa pero sincera. Supongo que tendrás que ver cómo van las cosas."

# game/CH1.rpy:898
translate Paloslios fireq_8cf9f77e:

    # "The facts are that you are going to be stuck here with Jim until the storm lets up."
    "El hecho es que vas a quedar atrapado aquí con Jim hasta que la tormenta amaine."

# game/CH1.rpy:899
translate Paloslios fireq_9e9eaccf:

    # "Either from uncertainty or not wanting to disclose your thoughts right now, you elect to not answer Jim's question."
    "Ya sea por incertidumbre o por no querer revelar tus pensamientos en este momento, eliges no responder la pregunta de Jim."

# game/CH1.rpy:900
translate Paloslios fireq_dd4de98e:

    # pov "I...couldn't really say right now."
    pov "Yo... realmente no podría decirlo ahora."

# game/CH1.rpy:902
translate Paloslios fireq_7777ad96:

    # "A flash of...frustration passes by Jim's face, but he nods in response."
    "Un destello de... frustración pasa por el rostro de Jim, pero él asiente en respuesta."

# game/CH1.rpy:903
translate Paloslios fireq_1513c5dc:

    # "He seems to be letting it go for now."
    "Parece que lo está dejando pasar por ahora."

# game/CH1.rpy:905
translate Paloslios fireq_3c6238fa:

    # "Jim looks back into the flickering embers of the fire and seems to be weighing your response in his head."
    "Jim vuelve a mirar las brasas parpadeantes del fuego y parece estar sopesando tu respuesta en su cabeza."

# game/CH1.rpy:906
translate Paloslios fireq_5063cd70:

    # "You wonder what he's thinking, but can't bring yourself to interrupt his thoughts."
    "Te preguntas qué está pensando, pero no te atreves a interrumpir sus pensamientos."

# game/CH1.rpy:907
translate Paloslios fireq_e03d5ded:

    # "You ultimately look into the fire too. The dancing flames lull you into its trance as your mind wanders."
    "Al final también miras hacia el fuego. Las llamas danzantes te adormecen en su trance mientras tu mente divaga."

# game/CH1.rpy:912
translate Paloslios fireq_33b3410f:

    # "The time flows as the sun disappears from the sky and you both are left with a dying fire."
    "El tiempo fluye mientras el sol desaparece del cielo y ambos os quedáis con un fuego agonizante."

# game/CH1.rpy:913
translate Paloslios fireq_a4433ea2:

    # "At some point, you find yourself watching him. His features are softer in the firelight. Warmer too than before."
    "En algún momento, te encuentras observándolo. Sus rasgos son más suaves a la luz del fuego. Más cálido también que antes."

# game/CH1.rpy:914
translate Paloslios fireq_c82dd9be:

    # "He looks much more friendly now that he's taken off his outerwear and is relaxing in his more casual outfit."
    "Se ve mucho más amigable ahora que se ha quitado la ropa de abrigo y se relaja con su ropa más informal."

# game/CH1.rpy:916
translate Paloslios fireq_3750e179:

    # "He doesn't seem to talk much, but his voice carries a quiet intensity, like every word matters."
    "No parece hablar mucho, pero su voz transmite una intensidad tranquila, como si cada palabra importara."

# game/CH1.rpy:918
translate Paloslios fireq_e82f3554:

    # "He glances at you and catches you staring. You quickly look down at your empty mug, feeling the heat rise in your face from being caught."
    "Él te mira y te pilla mirándolo. Rápidamente miras tu taza vacía y sientes que el calor sube a tu cara por haber sido atrapado."

# game/CH1.rpy:919
translate Paloslios fireq_859b8c2c:

    # "He doesn't say anything at first, but now you feel him observing you back."
    "Al principio no dice nada, pero ahora sientes que te observa."

# game/CH1.rpy:920
translate Paloslios fireq_d53b1212:

    # ji "What?"
    ji "¿Qué?"

# game/CH1.rpy:925
translate Paloslios fireq_b7c28aef:

    # pov "Nothing..."
    pov "Nada..."

# game/CH1.rpy:927
translate Paloslios fireq_3c217235:

    # "You reply quickly, a little too quickly, and Jim notices."
    "Respondes rápido, demasiado rápido, y Jim se da cuenta."

# game/CH1.rpy:929
translate Paloslios fireq_4673b3b5:

    # "He chuckles and the sound of it sends a shiver through you- one that has nothing to do with the storm outside."
    "Él se ríe y su sonido te provoca un escalofrío, uno que no tiene nada que ver con la tormenta de afuera."

# game/CH1.rpy:931
translate Paloslios fireq_b1004189:

    # ji "You sure about that?"
    ji "¿Estás seguro de eso?"

# game/CH1.rpy:932
translate Paloslios fireq_2723712a:

    # "Your chest tightens in a funny way at his teasing tone, his voice warmer now. The shyness from before fading ever so slightly."
    "Tu pecho se contrae de una manera divertida ante su tono burlón, su voz ahora es más cálida. La timidez de antes se desvaneció ligeramente."

# game/CH1.rpy:933
translate Paloslios fireq_2f3a3d09:

    # pov "Y-yeah."
    pov "S-sí."

# game/CH1.rpy:935
translate Paloslios fireq_4dd0b974:

    # "His gaze lingers on you for a moment, but then he smiles and looks away. Seems like he'll let it go...this time."
    "Su mirada se detiene en ti por un momento, pero luego sonríe y mira hacia otro lado. Parece que lo dejará pasar... esta vez."

# game/CH1.rpy:940
translate Paloslios fireq_fb688a44:

    # "As the words come out of your mouth, Jim's eyes widen for a moment."
    "Mientras las palabras salen de tu boca, los ojos de Jim se abren por un momento."

# game/CH1.rpy:942
translate Paloslios fireq_e6da78a4:

    # "His cheeks flush a soft shade of red and he shifts awkwardly in his seat and looks back to the fire as if it can offer him some comfort."
    "Sus mejillas se sonrojan con un suave tono rojo y se mueve torpemente en su asiento y mira hacia el fuego como si pudiera ofrecerle algo de consuelo."

# game/CH1.rpy:943
translate Paloslios fireq_96ec7ca3:

    # ji "Uh, thanks."
    ji "Gracias."

# game/CH1.rpy:945
translate Paloslios fireq_be17b209:

    # "He clears his throat and then raises his gaze slightly up to you again."
    "Se aclara la garganta y luego levanta ligeramente la mirada hacia ti nuevamente."

# game/CH1.rpy:946
translate Paloslios fireq_8dc1f643:

    # ji "I, uh, don't really get called that a lot."
    ji "A mí, uh, realmente no me llaman así mucho."

# game/CH1.rpy:947
translate Paloslios fireq_224b700d:

    # "There's something incredibly endearing about his genuine nervousness."
    "Hay algo increíblemente entrañable en su nerviosismo genuino."

# game/CH1.rpy:949
translate Paloslios fireq_6ee95330:

    # ji "But, uh, I guess I'll take it. It's...very nice of you to say."
    ji "Pero supongo que lo aceptaré. Es... muy amable de tu parte decirlo."

# game/CH1.rpy:951
translate Paloslios fireq_e47f5cef:

    # "He lets out a slow breath and glances at you."
    "Deja escapar un suspiro lento y te mira."

# game/CH1.rpy:952
translate Paloslios fireq_496978ec:

    # ji "You're not so bad yourself...you know."
    ji "Tú no eres tan malo... ya sabes."

# game/CH1.rpy:955
translate Paloslios fireq_56b953f5:

    # "You were mindlessly staring for a little too long before you had even realized it."
    "Estuviste mirando sin pensar durante demasiado tiempo antes de que te dieras cuenta."

# game/CH1.rpy:957
translate Paloslios fireq_745ba0d8:

    # ji "That's aight. No harm, no foul. You can stare, I don't mind."
    ji "Eso está bien. Sin daño, sin falta. Puedes mirar, no me importa."

# game/CH1.rpy:959
translate Paloslios fireq_a3a13126:

    # ji "You were just, uh, kinda obvious about it."
    ji "Fuiste un poco obvio al respecto."

# game/CH1.rpy:960
translate Paloslios fireq_2b6fbcd0:

    # "He's surprisingly easygoing despite first impressions. His words ease the embarrassment. Just a little."
    "Es sorprendentemente tranquilo a pesar de las primeras impresiones. Sus palabras alivian la vergüenza. Sólo un poco."

# game/CH1.rpy:962
translate Paloslios fireq_876a58ca:

    # pov "I get lost in my thoughts sometimes..."
    pov "A veces me pierdo en mis pensamientos..."

# game/CH1.rpy:964
translate Paloslios fireq_0335bf5b:

    # ji "Well, who doesn't every now and then?"
    ji "Bueno, ¿quién no lo hace de vez en cuando?"

# game/CH1.rpy:967
translate Paloslios fireq_0dabeb6a:

    # "You just state it matter-of-factly. It's what you were doing after all."
    "Simplemente lo dices con total naturalidad. Después de todo, es lo que estabas haciendo."

# game/CH1.rpy:969
translate Paloslios fireq_ffaea4a6:

    # j "Ah...I see."
    j "Ah... ya veo."

# game/CH1.rpy:971
translate Paloslios fireq_3c0d1f08:

    # "He continues to look back at you for a moment longer."
    "Él continúa mirándote por un momento más."

# game/CH1.rpy:973
translate Paloslios fireq_23b688f2:

    # j "You're a bold one, aren't you? Just starin' like that."
    j "Eres atrevido, ¿no? Simplemente mirando así."

# game/CH1.rpy:976
translate Paloslios fireq_8ca23ea6:

    # "Then, Jim looks into his empty mug- now cold."
    "Entonces, Jim mira su taza vacía, ahora fría."

# game/CH1.rpy:978
translate Paloslios fireq_918f97b4:

    # ji "Well...I think I'll call it a night..."
    ji "Bueno... creo que terminaré la noche..."

# game/CH1.rpy:982
translate Paloslios fireq_9a314510:

    # "Jim gets up and holds out a hand to take my empty mug from you too. Trying to be a gracious host to you."
    "Jim se levanta y extiende una mano para quitarte mi taza vacía también. Tratando de ser un anfitrión amable para usted."

# game/CH1.rpy:985
translate Paloslios fireq_d375b615:

    # "You give him your cup too and his lips curve into a small smile."
    "Le das tu taza también y sus labios se curvan en una pequeña sonrisa."

# game/CH1.rpy:988
translate Paloslios fireq_ee958d1a:

    # "He walks to the kitchen and places both your mugs in the tiny sink there with a clink."
    "Él camina hacia la cocina y coloca ambas tazas en el pequeño fregadero con un tintineo."

# game/CH1.rpy:994
translate Paloslios fireq_7fb447da:

    # "Then, Jim goes over to the hearth and puts out the rest of the fire before heading to his room."
    "Luego, Jim se acerca a la chimenea y apaga el resto del fuego antes de dirigirse a su habitación."

# game/CH1.rpy:995
translate Paloslios fireq_38443064:

    # "You get up and walk over to your room. You peer out to Jim, closing the door to your room. Jim lingers by his door and glances back at you."
    "Te levantas y caminas hacia tu habitación. Miras a Jim y cierras la puerta de tu habitación. Jim se queda junto a su puerta y te mira."

# game/CH1.rpy:998
translate Paloslios fireq_ed503c77:

    # "Jim eyes you a bit wearily again."
    "Jim te mira un poco cansado otra vez."

# game/CH1.rpy:999
translate Paloslios fireq_84632e1a:

    # j "I hope you don't try to leave again like earlier...Especially at night."
    j "Espero que no intentes irte otra vez como antes... Especialmente por la noche."

# game/CH1.rpy:1000
translate Paloslios fireq_8edab37a:

    # "His tone sounds similar to a disappointed parent..."
    "Su tono suena similar al de un padre decepcionado..."

# game/CH1.rpy:1002
translate Paloslios fireq_e8dfa39d:

    # ji "Okay...well, good night [povname]."
    ji "Vale... bueno, buenas noches [povname]."

# game/CH1.rpy:1005
translate Paloslios fireq_d11cc89a:

    # "You say your good nights and go to your respective rooms."
    "Se despiden de buenas noches y se dirigen a sus respectivas habitaciones."

# game/CH1.rpy:1009
translate Paloslios fireq_49c29d20:

    # "Jim's eyes sparkle with your words of appreciation."
    "Los ojos de Jim brillan con tus palabras de agradecimiento."

# game/CH1.rpy:1010
translate Paloslios fireq_54036db2:

    # j "You're welcome. Sleep well."
    j "De nada. Dormir bien."

# game/CH1.rpy:1014
translate Paloslios fireq_22e586b4:

    # "Jim gives you a perplexed look."
    "Jim te mira perplejo."

# game/CH1.rpy:1015
translate Paloslios fireq_d7139f2c:

    # j "Why would you want to do that?"
    j "¿Por qué querrías hacer eso?"

# game/CH1.rpy:1021
translate Paloslios fireq_d15f5c03:

    # "Jim notices your blushing and slowly starts blushing himself!"
    "¡Jim nota tu sonrojo y lentamente comienza a sonrojarse él mismo!"

# game/CH1.rpy:1023
translate Paloslios fireq_e086bff8:

    # j "Um- I-"
    j "Um-yo-"

# game/CH1.rpy:1025
translate Paloslios fireq_240cb4d2:

    # j "I don't think that's a good idea-"
    j "No creo que sea una buena idea-"

# game/CH1.rpy:1027
translate Paloslios fireq_0c9425a3:

    # "Jim stands there quietly- his blush deepening as his thoughts continue."
    "Jim se queda allí en silencio, su sonrojo se profundiza a medida que sus pensamientos continúan."

# game/CH1.rpy:1028
translate Paloslios fireq_5e3c2b9f:

    # j "G-good night!"
    j "¡Buenas noches!"

# game/CH1.rpy:1032
translate Paloslios fireq_7d486755:

    # "Jim rushes away before you can say anything else."
    "Jim se aleja corriendo antes de que puedas decir algo más."

# game/CH1.rpy:1033
translate Paloslios fireq_83ce835d:

    # "Oh...You turn to go to your room then."
    "Oh... Entonces te giras para ir a tu habitación."

# game/CH1.rpy:1038
translate Paloslios fireq_a1095a41:

    # j "Huh? Um-"
    j "¿Eh? Um-"

# game/CH1.rpy:1040
translate Paloslios fireq_20c4bee9:

    # "Jim's eyes dart around the room. Anywhere but you."
    "Los ojos de Jim recorren la habitación. En cualquier lugar menos en ti."

# game/CH1.rpy:1041
translate Paloslios fireq_b3cff480:

    # j "That's..."
    j "Eso es..."

# game/CH1.rpy:1043
translate Paloslios fireq_00b7bbee:

    # j "There are extra blankets in your room if you get too cold!"
    j "¡Hay mantas adicionales en tu habitación si tienes demasiado frío!"

# game/CH1.rpy:1047
translate Paloslios fireq_7d486755_1:

    # "Jim rushes away before you can say anything else."
    "Jim se aleja corriendo antes de que puedas decir algo más."

# game/CH1.rpy:1048
translate Paloslios fireq_83ce835d_1:

    # "Oh...You turn to go to your room then."
    "Oh... Entonces te giras para ir a tu habitación."

# game/CH1.rpy:1051
translate Paloslios fireq_279875e0:

    # "Jim looks at you with sympathy and tries to reassure you."
    "Jim te mira con simpatía y trata de tranquilizarte."

# game/CH1.rpy:1052
translate Paloslios fireq_818d9d31:

    # j "I promise you'll be safe here..."
    j "Te prometo que estarás a salvo aquí..."

# game/CH1.rpy:1054
translate Paloslios fireq_ffa94135:

    # j "I'll just be in my room if anything happens."
    j "Estaré en mi habitación si pasa algo."

# game/CH1.rpy:1055
translate Paloslios fireq_4e7f65e4:

    # "His words are helping, but you're not entirely convinced."
    "Sus palabras ayudan, pero no estás del todo convencido."

# game/CH1.rpy:1056
translate Paloslios fireq_c076c8b1:

    # "He seems glad that you're turning to him for help, but he gently waves you off as he heads to his room."
    "Parece contento de que le pidas ayuda, pero te despide suavemente mientras se dirige a su habitación."

# game/CH1.rpy:1057
translate Paloslios fireq_acac0b1b:

    # "You head to your respective room as well."
    "También te diriges a tu habitación respectiva."

# game/CH1.rpy:1059
translate Paloslios fireq_5cc9ee0d:

    # "Jim continues to look at you with a confused look."
    "Jim continúa mirándote con una mirada confusa."

# game/CH1.rpy:1060
translate Paloslios fireq_aaaf8673:

    # j "Aight then...Well, good night again."
    j "Bien entonces... Bueno, buenas noches de nuevo."

# game/CH1.rpy:1061
translate Paloslios fireq_15f871be:

    # "You go to close your door without another word."
    "Vas a cerrar la puerta sin decir una palabra más."

# game/CH1.rpy:1063
translate Paloslios fireq_15f871be_1:

    # "You go to close your door without another word."
    "Vas a cerrar la puerta sin decir una palabra más."

# game/CH1.rpy:1069
translate Paloslios endday1_919a1272:

    # "Your door creaks as you close it all the way and you turn towards what will be your room for the next couple days."
    "Tu puerta cruje cuando la cierras del todo y te giras hacia la que será tu habitación durante los próximos días."

# game/CH1.rpy:1071
translate Paloslios endday1_57987696:

    # "That was much nicer than how your first meeting started."
    "Eso fue mucho mejor que cómo comenzó tu primera reunión."

# game/CH1.rpy:1072
translate Paloslios endday1_dd378fc4:

    # "You are getting to know Jim a lot more and you both are getting along."
    "Estás conociendo mucho más a Jim y ambos se llevan bien."

# game/CH1.rpy:1073
translate Paloslios endday1_1bd0fc79:

    # "Your unexpected host is turning out to be a pleasant surprise."
    "Su anfitrión inesperado está resultando ser una agradable sorpresa."

# game/CH1.rpy:1075
translate Paloslios endday1_57987696_1:

    # "That was much nicer than how your first meeting started."
    "Eso fue mucho mejor que cómo comenzó tu primera reunión."

# game/CH1.rpy:1076
translate Paloslios endday1_cb0424ba:

    # "Jim's not so bad so far."
    "Jim no está tan mal hasta ahora."

# game/CH1.rpy:1077
translate Paloslios endday1_969e37fc:

    # "Maybe it wouldn't be so bad getting to know each other more."
    "Quizás no sería tan malo conocernos más."

# game/CH1.rpy:1079
translate Paloslios endday1_22ba065e:

    # "You're stuck here with this stranger..."
    "Estás atrapado aquí con este extraño..."

# game/CH1.rpy:1088
translate Paloslios endday1_95c2176d:

    # "You change into your sleeping clothes and jump under the covers for warmth. The storm is still raging outside as much as it was earlier."
    "Te pones tu ropa de dormir y saltas debajo de las sábanas para abrigarte. Afuera la tormenta sigue arrasando como antes."

# game/CH1.rpy:1091
translate Paloslios walkedday1_02910938:

    # "You start to relax and soon the storm outside starts to sound like white noise. The events of the day are taking their toll on you."
    "Empiezas a relajarte y pronto la tormenta afuera comienza a sonar como ruido blanco. Los acontecimientos del día te están pasando factura."

# game/CH1.rpy:1092
translate Paloslios walkedday1_a957bddc:

    # "Before you arrived, you were feeling [feel1]."
    "Antes de llegar, te sentías [feel1]."

# game/CH1.rpy:1093
translate Paloslios walkedday1_1a639cd5:

    # "Now, after everything that has happened, you feel..."
    "Ahora, después de todo lo que ha pasado, te sientes..."

# game/CH1.rpy:1097
translate Paloslios walkedday1_604546cd:

    # "Honestly, you're attracted to Jim."
    "Sinceramente, te atrae Jim."

# game/CH1.rpy:1098
translate Paloslios walkedday1_65b399a5:

    # "He has been...not what you expected and you're looking forward to learning more about him."
    "Él no ha sido... lo que esperabas y estás deseando aprender más sobre él."

# game/CH1.rpy:1100
translate Paloslios walkedday1_56893bd8:

    # "You're grateful for this cabin and Jim's hospitality so far."
    "Estás agradecido por esta cabaña y por la hospitalidad de Jim hasta ahora."

# game/CH1.rpy:1101
translate Paloslios walkedday1_f9f2ea65:

    # "Things could've gone a lot worse all things considered."
    "Considerando todo, las cosas podrían haber ido mucho peor."

# game/CH1.rpy:1103
translate Paloslios walkedday1_a27ce908:

    # "You're hopeful that you can still have a good time on your vacation. All things considered, it could be a lot worse."
    "Tienes la esperanza de poder pasar un buen rato en tus vacaciones. A fin de cuentas, podría ser mucho peor."

# game/CH1.rpy:1104
translate Paloslios walkedday1_7816ccb1:

    # "Tomorrow will be a brand new day and you'll try to make the most of the situation."
    "Mañana será un nuevo día e intentarás aprovechar la situación al máximo."

# game/CH1.rpy:1107
translate Paloslios walkedday1_37fdab8c:

    # "You are still feeling so embarrassed about the events of today."
    "Todavía te sientes muy avergonzado por los acontecimientos de hoy."

# game/CH1.rpy:1108
translate Paloslios walkedday1_c96ccdf4:

    # "First, you miss your cabin and then you end up in a stranger's place."
    "Primero, extrañas tu cabaña y luego terminas en la casa de un extraño."

# game/CH1.rpy:1109
translate Paloslios walkedday1_3c757ce0:

    # "And then Jim..."
    "Y luego Jim..."

# game/CH1.rpy:1110
translate Paloslios walkedday1_d793d0a7:

    # "Argh!!!! You pull the covers towards your burning face. It's all just too embarrassing!"
    "Argh!!!! Tiras de las mantas hacia tu cara ardiente. ¡Es todo demasiado vergonzoso!"

# game/CH1.rpy:1113
translate Paloslios walkedday1_420c94b8:

    # "You are feeling wary about this whole situation with Jim and being snowed in with him."
    "Te sientes desconfiado por toda esta situación con Jim y por estar atrapado con él."

# game/CH1.rpy:1114
translate Paloslios walkedday1_40003536:

    # "There's just so many unknowns that you have to deal with now."
    "Hay tantas incógnitas con las que tienes que lidiar ahora."

# game/CH1.rpy:1115
translate Paloslios walkedday1_3e014fb0:

    # "This is turning out to be a much more complicated getaway than you bargained for."
    "Esta está resultando ser una escapada mucho más complicada de lo que esperaba."

# game/CH1.rpy:1118
translate Paloslios walkedday1_cc2369a2:

    # "You're not sure about how to feel right now. A lot has happened and it might take some time to process it all."
    "No estás seguro de cómo sentirte en este momento. Han pasado muchas cosas y puede que lleve algún tiempo procesarlo todo."

# game/CH1.rpy:1119
translate Paloslios walkedday1_d7b84af8:

    # "All you know for sure right now is that the storm will be keeping you in this cabin with Jim for a couple of days."
    "Lo único que sabes con certeza ahora es que la tormenta te mantendrá en esta cabaña con Jim durante un par de días."

# game/CH1.rpy:1120
translate Paloslios walkedday1_484d58d8:

    # "At least, Jim said it would be for just a couple of days."
    "Al menos, Jim dijo que sería sólo por un par de días."

# game/CH1.rpy:1122
translate Paloslios walkedday1_3a51cf0c:

    # "As you think about how you feel, you drift off to sleep wondering what the rest of the week has in store for you."
    "Mientras piensas en cómo te sientes, te quedas dormido preguntándote qué te depara el resto de la semana."

# game/CH1.rpy:1130
translate Paloslios day1dream_4e811684:

    # "The darkness takes you and you dream of being deep in the mountains. The air is viscous, thick with the scent of old blood."
    "La oscuridad te lleva y sueñas con estar en lo profundo de las montañas. El aire es viscoso, espeso con el olor a sangre vieja."

# game/CH1.rpy:1133
translate Paloslios day1dream_cad37df9:

    # "From the abyss, a pair of gold moon-like eyes glow from a towering figure."
    "Desde el abismo, un par de ojos dorados parecidos a una luna brillan desde una figura imponente."

# game/CH1.rpy:1134
translate Paloslios day1dream_1254deff:

    # "The shadow moves- too fluid, too silent- just beyond your grasp."
    "La sombra se mueve, demasiado fluida, demasiado silenciosa, justo fuera de tu alcance."

# game/CH1.rpy:1135
translate Paloslios day1dream_a7b28db1:

    # "The trees scream. The ground heaves. And then-"
    "Los árboles gritan. El suelo se agita. Y entonces-"

# game/CH1.rpy:1136
translate Paloslios day1dream_b21fc7c1:

    # "A sound. Low. Guttural. Laughing."
    "Un sonido. Bajo. Gutural. Reír."

# game/CH1.rpy:1137
translate Paloslios day1dream_2574c40a:

    # "Its voice is not sound, but vibration- the hum of a wasp's nest, the groan of a noose tightening."
    "Su voz no es sonido, sino vibración: el zumbido de un nido de avispas, el gemido de una soga apretándose."

# game/CH1.rpy:1140
translate Paloslios day1dream_966009a7:

    # "{sc=3}{color=#de0d0d}You are such a delicate thing. A rabbit on my altar- you are the perfect sacrifice.{/color}{/sc}"
    "{sc=3}{color=#de0d0d}Eres una cosa tan delicada. Un conejo en mi altar, eres el sacrificio perfecto.{/color}{/sc}"

# game/CH1.rpy:1142
translate Paloslios day1dream_1b3a9a65:

    # "{sc=3}{color=#de0d0d}I see you're a clever creature. A cunning fox. Do you think you can outplay me?{/color}{/sc}"
    "{sc=3}{color=#de0d0d}Veo que eres una criatura inteligente. Un zorro astuto. ¿Crees que puedes superarme?{/color}{/sc}"

# game/CH1.rpy:1144
translate Paloslios day1dream_8ddd7a15:

    # "{sc=3}{color=#de0d0d}You have your own fangs. A wolf...We will see if you are worthy.{/color}{/sc}"
    "{sc=3}{color=#de0d0d}Tienes tus propios colmillos. Un lobo... Veremos si eres digno.{/color}{/sc}"

# game/CH1.rpy:1147
translate Paloslios day1dream_1502ce59:

    # "Your breath comes fast, not with fear, but rapture."
    "Tu respiración se acelera, no con miedo, sino con éxtasis."

# game/CH1.rpy:1148
translate Paloslios day1dream_60bb19c5:

    # "You seem to recognize something. To be known is to press your rotting heart against something equally ruined."
    "Parece reconocer algo. Ser conocido es presionar tu corazón podrido contra algo igualmente arruinado."

# game/CH1.rpy:1150
translate Paloslios day1dream_bc500df9:

    # "{sc=3}{color=#de0d0d}See how we match?{/color}{/sc}"
    "{sc=3}{color=#de0d0d}¿Ves cómo coincidimos?{/color}{/sc}"

# game/CH1.rpy:1151
translate Paloslios day1dream_25c8f12a:

    # "You barely even notice when the gnarled roots from below wrap around your leg lovingly."
    "Apenas te das cuenta cuando las raíces retorcidas de abajo se envuelven con amor alrededor de tu pierna."

# game/CH1.rpy:1153
translate Paloslios day1dream_f07e9ef6:

    # "The voice scares you...you don't understand what it is."
    "La voz te asusta... no entiendes lo que es."

# game/CH1.rpy:1154
translate Paloslios day1dream_8c8c31e4:

    # "You try to get away from this haunting visage, but the damp, cold earth under your feet clings to you."
    "Intentas alejarte de este rostro inquietante, pero la tierra húmeda y fría bajo tus pies se aferra a ti."

# game/CH1.rpy:1155
translate Paloslios day1dream_4b9bbfac:

    # "Branches claw at your arms, leaving thin red trails in their wake. The less you understand, the rougher things get."
    "Las ramas te arañan los brazos, dejando finos rastros rojos a su paso. Cuanto menos entiendes, más difíciles se ponen las cosas."

# game/CH1.rpy:1156
translate Paloslios day1dream_e178f1df:

    # "The trees loom and shadows laugh."
    "Los árboles se alzan y las sombras ríen."

# game/CH1.rpy:1158
translate Paloslios day1dream_51fe82b9:

    # "The creature taunts you further."
    "La criatura se burla aún más de ti."

# game/CH1.rpy:1160
translate Paloslios day1dream_4f68fb1f:

    # "{sc=3}{color=#de0d0d}You tried to leave. You try to run from the inevitable. I am the door you cannot close.\n You are Home.{/color}{/sc}"
    "{sc=3}{color=#de0d0d}Intentaste irte. Intentas huir de lo inevitable. Yo soy la puerta que no puedes cerrar.\n Tú estás en casa.{/color}{/sc}"

# game/CH1.rpy:1161
translate Paloslios day1dream_6a433b30:

    # "The forest, it screams to you..."
    "El bosque, te grita..."

# game/CH1.rpy:1163
translate Paloslios day1dream_0183ea26:

    # "{sc=4}{color=#de0d0d}{b}THE ONE WHO DREAMS THE WOLVES{/b}{/color}{/sc}"
    "{sc=4}{color=#de0d0d}{b}EL QUE SUEÑA LOS LOBOS{/b}{/color}{/sc}"

# game/CH1.rpy:1164
translate Paloslios day1dream_f3a826e4:

    # "And then the darkness reaches for you."
    "Y entonces la oscuridad te alcanza."

# game/CH1.rpy:1165
translate Paloslios day1dream_fb7064ea:

    # "The voice calls to you once more."
    "La voz te llama una vez más."

# game/CH1.rpy:1167
translate Paloslios day1dream_a6c5690e:

    # "{sc=3}{color=#de0d0d}I'll let the whelp have you. Just for a little while.{/color}{/sc}"
    "{sc=3}{color=#de0d0d}Dejaré que el cachorro te tenga. Sólo por un rato.{/color}{/sc}"

# game/CH1.rpy:1177
translate Paloslios leaveday1_d46c4811:

    # "Jim has a panicked look on his face as he takes in your words."
    "Jim tiene una expresión de pánico en su rostro mientras asimila tus palabras."

# game/CH1.rpy:1178
translate Paloslios leaveday1_9a60d606:

    # j "But- It's not safe to leave right now. You can stay here and leave later."
    j "Pero... No es seguro irse ahora. Puedes quedarte aquí e irte más tarde."

# game/CH1.rpy:1179
translate Paloslios leaveday1_58a07ac0:

    # "This time you have enough room to move past him while grabbing your luggage on the way out."
    "Esta vez tienes suficiente espacio para pasar junto a él mientras tomas tu equipaje al salir."

# game/CH1.rpy:1208
translate Paloslios leaveday1v2_d9c033af:

    # "You stepped back outside towards your car."
    "Retrocediste hacia tu auto."

# game/CH1.rpy:1209
translate Paloslios leaveday1v2_c42001a6:

    # "The icy wind whips across your form as you trudge outside with faltering determination."
    "El viento helado azota tu forma mientras caminas penosamente afuera con determinación vacilante."

# game/CH1.rpy:1210
translate Paloslios leaveday1v2_f24a0573:

    # "How long has it been since you've gotten here? It looks like the snow on the ground has already doubled! And more was coming down angrily."
    "¿Cuánto tiempo ha pasado desde que llegaste aquí? ¡Parece que la nieve en el suelo ya se ha duplicado! Y caían más enojados."

# game/CH1.rpy:1211
translate Paloslios leaveday1v2_6e21b2e7:

    # "Maybe this isn't such a good idea..."
    "Quizás esto no sea tan buena idea..."

# game/CH1.rpy:1217
translate Paloslios leave_option1_498f2c3f:

    # "You steel your determination again and push through the snow."
    "Reforzas tu determinación de nuevo y avanzas a través de la nieve."

# game/CH1.rpy:1219
translate Paloslios leave_option1_4ba5b65b:

    # j "Wait-!"
    j "Esperar-!"

# game/CH1.rpy:1220
translate Paloslios leave_option1_c7a53cd5:

    # "You ignore Jim's pleas as you reach for your car door."
    "Ignoras las súplicas de Jim mientras alcanzas la puerta de tu auto."

# game/CH1.rpy:1221
translate Paloslios leave_option1_09d6e33b:

    # "Just get to the car- Just go!"
    "Sólo ve al auto. ¡Solo vete!"

# game/CH1.rpy:1222
translate Paloslios leave_option1_6ae247ff:

    # "The cold bites your bare hands as you wrench open the driver's door."
    "El frío muerde tus manos desnudas mientras abres la puerta del conductor."

# game/CH1.rpy:1226
translate Paloslios leave_option1_16d1d698:

    # "Your luggage is thrown unceremoniously over to the passenger side. And you focus on the sole goal of getting away from here."
    "Su equipaje es arrojado sin contemplaciones al lado del pasajero. Y te concentras en el único objetivo de alejarte de aquí."

# game/CH1.rpy:1228
translate Paloslios leave_option1_f31e39d3:

    # "You can feel Jim's eyes on you through the windshield, but you don't dare look up as you start your car."
    "Puedes sentir los ojos de Jim sobre ti a través del parabrisas, pero no te atreves a mirar hacia arriba cuando enciendes el auto."

# game/CH1.rpy:1232
translate Paloslios leave_option1_af7ac3d8:

    # "Keys in the ignition. Engine roaring to life. The tires spin once- twice before catching traction."
    "Llaves en el encendido. El motor cobra vida rugiendo. Los neumáticos giran una o dos veces antes de coger tracción."

# game/CH1.rpy:1234
translate Paloslios leave_option1_203065fb:

    # "The car lurches violently, throwing your luggage onto the floor. White-knuckling the wheel, you slam the gas again. The wheels scream. The car doesn't move."
    "El coche se tambalea violentamente, arrojando su equipaje al suelo. Con los nudillos blancos, vuelves a pisar el acelerador. Las ruedas chirrían. El auto no se mueve."

# game/CH1.rpy:1235
translate Paloslios leave_option1_27e989d1:

    # "Through the windshield, Jim strides toward you, his breath ragged plumes in the air. His expression isn't anger. It's concern."
    "A través del parabrisas, Jim avanza hacia ti, con su aliento entrecortado en columnas de aire. Su expresión no es de ira. Es preocupación."

# game/CH1.rpy:1236
translate Paloslios leave_option1_46cb375d:

    # "He yells at you from the other side of your car."
    "Te grita desde el otro lado de tu auto."

# game/CH1.rpy:1237
translate Paloslios leave_option1_698ee585:

    # j "You'll die out here!"
    j "¡Morirás aquí!"

# game/CH1.rpy:1239
translate Paloslios leave_option1_64f7fbc7:

    # "You jerk the gearshift into reverse. The tires spin uselessly, digging deeper into the ice."
    "Pones la palanca de cambios en reversa. Los neumáticos giran inútilmente, hundiéndose más profundamente en el hielo."

# game/CH1.rpy:1244
translate Paloslios leave_option2_31fbc1f5:

    # "Desperation fuels you. You'll burn out the engine if you have to."
    "La desesperación te alimenta. Quemarás el motor si es necesario."

# game/CH1.rpy:1246
translate Paloslios leave_option2_ac99c5d7:

    # "The engine shrieks in protest. Black smoke curls from the wheel wells. Jim doesn't flinch. He steps closer, palms slamming onto the hood."
    "El motor chirría en señal de protesta. De los pasos de rueda sale humo negro. Jim no se inmuta. Se acerca y sus palmas golpean el capó."

# game/CH1.rpy:1249
translate Paloslios leave_option2_db1dae07:

    # j "Stop! You're not getting anywhere in this snow!"
    j "¡Detener! ¡No llegarás a ninguna parte con esta nieve!"

# game/CH1.rpy:1250
translate Paloslios leave_option2_6da75190:

    # "The smell of burning rubber floods the cabin. The car groans- then dies with a shudder."
    "El olor a goma quemada inunda el habitáculo. El coche gime y luego se apaga con un estremecimiento."

# game/CH1.rpy:1251
translate Paloslios leave_option2_b2c85af3:

    # "Silence. Your breath fogs the glass as Jim slowly rounds your door. His shadow falls across you."
    "Silencio. Tu aliento empaña el cristal mientras Jim rodea lentamente la puerta. Su sombra cae sobre ti."

# game/CH1.rpy:1256
translate Paloslios leave_option2_d1288150:

    # "You refuse to stay in that cabin with a strange man...But leaving in this snowstorm doesn't seem like a good idea either."
    "Te niegas a quedarte en esa cabaña con un hombre extraño... Pero marcharte con esta tormenta de nieve tampoco parece buena idea."

# game/CH1.rpy:1257
translate Paloslios leave_option2_67bef8e8:

    # "The car's interior feels like a frozen tomb, you hurridly turn up the heat."
    "El interior del coche parece una tumba helada; subes rápidamente la calefacción."

# game/CH1.rpy:1259
translate Paloslios leave_option2_84bebc5e:

    # "The snowstorm picked up so much that you couldn't even tell if Jim was still out there."
    "La tormenta de nieve arreció tanto que ni siquiera se podía saber si Jim todavía estaba ahí afuera."

# game/CH1.rpy:1260
translate Paloslios leave_option2_4c75d8ae:

    # "You are safer inside the car, but the car's heater can't compete with the icy blast pelting the car with loud dings."
    "Estás más seguro dentro del auto, pero la calefacción del auto no puede competir con la ráfaga de hielo que golpea el auto con fuertes golpes."

# game/CH1.rpy:1262
translate Paloslios leave_option2_7de776d0:

    # "The winds howl at you mockingly as you try to curl into yourself for warm from the driver's seat."
    "Los vientos aúllan burlonamente mientras intentas acurrucarte para calentarte desde el asiento del conductor."

# game/CH1.rpy:1263
translate Paloslios leave_option2_7d012c2f:

    # "You're so tired...and so cold..."
    "Estás tan cansada... y con tanto frío..."

# game/CH1.rpy:1266
translate Paloslios leave_option2_a20cefa7:

    # "..."
    "..."

# game/CH1.rpy:1267
translate Paloslios leave_option2_a20cefa7_1:

    # "..."
    "..."

# game/CH1.rpy:1268
translate Paloslios leave_option2_a20cefa7_2:

    # "..."
    "..."

# game/CH1.rpy:1269
translate Paloslios leave_option2_1130f2b4:

    # "There's a faint whisper..."
    "Hay un leve susurro..."

# game/CH1.rpy:1270
translate Paloslios leave_option2_10679e17:

    # "{sc=2}{size=*0.75}'They wanted to take you...but I didn't let them.'{/size}{/sc}"
    "{sc=2}{size=*0.75}'Querían llevarte...pero no los dejé.'{/size}{/sc}"

# game/CH1.rpy:1273
translate Paloslios leave_option2_88005c19:

    # "...You feel warm."
    "...Te sientes cálido."

# game/CH1.rpy:1276
translate Paloslios leave_option2_46e4a886:

    # "Your eyes flutter open despite how tired you still feel."
    "Tus ojos se abren a pesar de lo cansado que todavía te sientes."

# game/CH1.rpy:1277
translate Paloslios leave_option2_4cd4b251:

    # "In a daze, you notice you're in an unknown room...It's nighttime now, but the storm sounds like it's still raging outside."
    "Aturdido, te das cuenta de que estás en una habitación desconocida... Ahora es de noche, pero parece que la tormenta todavía está arrasando afuera."

# game/CH1.rpy:1278
translate Paloslios leave_option2_61b25f15:

    # "Ah...Jim must have saved me."
    "Ah... Jim debe haberme salvado."

# game/CH1.rpy:1279
translate Paloslios leave_option2_de97f98f:

    # "You attempt to move, but your limbs feel so sluggish. And the bed is so warm..."
    "Intentas moverte, pero tus extremidades se sienten muy lentas. Y la cama es tan cálida..."

# game/CH1.rpy:1284
translate Paloslios leave_option2_9c5b6619:

    # "His voice and the situation crack something inside you."
    "Su voz y la situación rompen algo dentro de ti."

# game/CH1.rpy:1285
translate Paloslios leave_option2_2345bf38:

    # "Your fingers slip off the keys. Jim's eyes are round with worry."
    "Tus dedos se resbalan de las teclas. Los ojos de Jim están llenos de preocupación."

# game/CH1.rpy:1286
translate Paloslios leave_option2_5243d14d:

    # j "You think you can survive out here on your own? Look outside."
    j "¿Crees que podrás sobrevivir aquí por tu cuenta? Mira afuera."

# game/CH1.rpy:1287
translate Paloslios leave_option2_170a96ad:

    # "He gestures to the snowdrifts that are taller than you and the obliterated road."
    "Señala los ventisqueros que son más altos que tú y la carretera destruida."

# game/CH1.rpy:1288
translate Paloslios leave_option2_682bf9ad:

    # j "There's nowhere to go."
    j "No hay ningún lugar adonde ir."

# game/CH1.rpy:1290
translate Paloslios leave_option2_2_90a21814:

    # "His hand hovers over the door handle. Not pulling. Waiting."
    "Su mano se cierne sobre el pomo de la puerta. Sin tirar. Espera."

# game/CH1.rpy:1296
translate Paloslios leave_option2_2_a12aac3e:

    # "Defeat tastes like copper, but there's no way you can stay out in a blizzard like this."
    "La derrota sabe a cobre, pero no hay manera de que puedas permanecer fuera en una tormenta de nieve como ésta."

# game/CH1.rpy:1297
translate Paloslios leave_option2_2_7a20e37c:

    # "He gratefully opens the door for you and wordlessly leads you back to the cabin."
    "Él, agradecido, te abre la puerta y, sin decir palabra, te lleva de regreso a la cabaña."

# game/CH1.rpy:1301
translate Paloslios leave_option2_2_a15ca32d:

    # "No...You're not giving up yet..."
    "No... no te vas a rendir todavía..."

# game/CH1.rpy:1302
translate Paloslios leave_option2_2_56007bb7:

    # "What are you going to do about it?"
    "¿Qué vas a hacer al respecto?"

# game/CH1.rpy:1303
translate Paloslios leave_option2_2_aba3223b:

    # "Jim glares back at you wordlessly but steps back away from the car as you figure out what to do."
    "Jim te mira sin decir palabra, pero se aleja del auto mientras piensas qué hacer."

# game/CH1.rpy:1321
translate Paloslios leave_option2_2_8f82010e:

    # "In frustration, you leave your car and start walking down where the road used to be."
    "Frustrado, dejas tu auto y comienzas a caminar por donde solía estar la carretera."

# game/CH1.rpy:1322
translate Paloslios leave_option2_2_003782af:

    # "The cold instantly starts clawing at you to your core and it's made apparent to you that your clothes aren't nearly insulated enough for this kind of weather."
    "El frío instantáneamente comienza a arañarte hasta el fondo y te hace evidente que tu ropa no está lo suficientemente aislada para este tipo de clima."

# game/CH1.rpy:1323
translate Paloslios leave_option2_2_6945f32d:

    # "-But you've got to leave. There's no way you're staying in a cabin with this guy."
    "-Pero tienes que irte. No hay forma de que te quedes en una cabaña con este tipo."

# game/CH1.rpy:1324
translate Paloslios leave_option2_2_619c1011:

    # "You don't hear Jim move from his spot near your car or call out to you. He seemingly lets you go."
    "No escuchas a Jim moverse de su lugar cerca de tu auto ni llamarte. Aparentemente te deja ir."

# game/CH1.rpy:1326
translate Paloslios leave_option2_2_b311d179:

    # "The fire you had when you made the decision to walk is dimming as your body temperature drops."
    "El fuego que tenías cuando tomaste la decisión de caminar se va apagando a medida que tu temperatura corporal baja."

# game/CH1.rpy:1327
translate Paloslios leave_option2_2_2551fb7c:

    # "How long have you been walking? It's getting harder to see through all of the snow..."
    "¿Cuánto tiempo llevas caminando? Cada vez es más difícil ver a través de toda la nieve..."

# game/CH1.rpy:1328
translate Paloslios leave_option2_2_f3ca1baa:

    # "You reach out your arm in front of you and you can barely see your hand."
    "Extiendes el brazo frente a ti y apenas puedes ver tu mano."

# game/CH1.rpy:1329
translate Paloslios leave_option2_2_01ff6b86:

    # "Uh oh...You feel your limbs slowing down. When did the snow get so heavy?"
    "Uh oh...Sientes que tus extremidades se ralentizan. ¿Cuándo la nieve se volvió tan intensa?"

# game/CH1.rpy:1332
translate Paloslios leave_option2_2_5c47b8ba:

    # "It's all white."
    "Es todo blanco."

# game/CH1.rpy:1333
translate Paloslios leave_option2_2_88c3c662:

    # "Huh? When did I lay down in the snow?"
    "¿Eh? ¿Cuándo me acosté en la nieve?"

# game/CH1.rpy:1338
translate Paloslios leave_option2_2_30d4c8a9:

    # "I'm so tired..."
    "Estoy tan cansada..."

# game/CH1.rpy:1339
translate Paloslios leave_option2_2_3e8f0346:

    # "I can't...keep my eyes open anymore..."
    "Ya no puedo... mantener los ojos abiertos..."

# game/CH1.rpy:1343
translate Paloslios leave_option2_2_a20cefa7:

    # "..."
    "..."

# game/CH1.rpy:1344
translate Paloslios leave_option2_2_a20cefa7_1:

    # "..."
    "..."

# game/CH1.rpy:1345
translate Paloslios leave_option2_2_a20cefa7_2:

    # "..."
    "..."

# game/CH1.rpy:1347
translate Paloslios leave_option2_2_1130f2b4:

    # "There's a faint whisper..."
    "Hay un leve susurro..."

# game/CH1.rpy:1348
translate Paloslios leave_option2_2_10679e17:

    # "{sc=2}{size=*0.75}'They wanted to take you...but I didn't let them.'{/size}{/sc}"
    "{sc=2}{size=*0.75}'Querían llevarte...pero no los dejé.'{/size}{/sc}"

# game/CH1.rpy:1349
translate Paloslios leave_option2_2_88005c19:

    # "...You feel warm."
    "...Te sientes cálido."

# game/CH1.rpy:1355
translate Paloslios leave_option2_2_46e4a886:

    # "Your eyes flutter open despite how tired you still feel."
    "Tus ojos se abren a pesar de lo cansado que todavía te sientes."

# game/CH1.rpy:1356
translate Paloslios leave_option2_2_4cd4b251:

    # "In a daze, you notice you're in an unknown room...It's nighttime now, but the storm sounds like it's still raging outside."
    "Aturdido, te das cuenta de que estás en una habitación desconocida... Ahora es de noche, pero parece que la tormenta todavía está arrasando afuera."

# game/CH1.rpy:1357
translate Paloslios leave_option2_2_61b25f15:

    # "Ah...Jim must have saved me."
    "Ah... Jim debe haberme salvado."

# game/CH1.rpy:1358
translate Paloslios leave_option2_2_de97f98f:

    # "You attempt to move, but your limbs feel so sluggish. And the bed is so warm..."
    "Intentas moverte, pero tus extremidades se sienten muy lentas. Y la cama es tan cálida..."

# game/CH1.rpy:1365
translate Paloslios leave_option2_2_c4a393cf:

    # "With the weather worsening and the car unable to get through the snow...There's only one choice."
    "Con el tiempo empeorando y el coche incapaz de atravesar la nieve... Sólo hay una opción."

# game/CH1.rpy:1366
translate Paloslios leave_option2_2_2f6d28ed:

    # "Defeated, you grab your luggage and get out of your car."
    "Derrotado, tomas tu equipaje y sales de tu auto."

# game/CH1.rpy:1372
translate Paloslios leave_option2_2_3ff91189:

    # "Jim looks relieved as he sees you walk back towards the cabin."
    "Jim parece aliviado cuando te ve caminar de regreso hacia la cabaña."

# game/CH1.rpy:1374
translate Paloslios leave_option2_2_ea8d461b:

    # "He watches carefully as you walk past him and up the stairs. He silently follows after you."
    "Él observa atentamente mientras pasas junto a él y subes las escaleras. Él te sigue en silencio."

# game/CH1.rpy:1378
translate Paloslios leave_option2_2_b14edf47:

    # "You hesitantly look back towards the warm shelter after seeing the fury of the storm."
    "Vuelves a mirar vacilantemente hacia el cálido refugio después de ver la furia de la tormenta."

# game/CH1.rpy:1380
translate Paloslios leave_option2_2_5319b3b6:

    # "Jim is already there outside with you, putting his coat back on after you."
    "Jim ya está afuera contigo, poniéndose el abrigo detrás de ti."

# game/CH1.rpy:1381
translate Paloslios leave_option2_2_72ce7530:

    # "As he starts pulling up his mask, your eyes lock intensely and his eyes plead for you to change your mind."
    "Cuando comienza a levantarse la máscara, tus ojos se cruzan intensamente y sus ojos te suplican que cambies de opinión."

# game/CH1.rpy:1385
translate Paloslios leave_option2_2_5148aa62:

    # "After seeing how the weather seems to be worsening, you are starting to be more inclined to Jim's offer."
    "Después de ver cómo el tiempo parece empeorar, empiezas a inclinarte más por la oferta de Jim."

# game/CH1.rpy:1386
translate Paloslios leave_option2_2_4cbd7deb:

    # "You turn to head back inside with your tail between your legs."
    "Te giras para regresar al interior con la cola entre las piernas."

# game/CH1.rpy:1388
translate Paloslios leave_option2_2_3ff91189_1:

    # "Jim looks relieved as he sees you walk back towards the cabin."
    "Jim parece aliviado cuando te ve caminar de regreso hacia la cabaña."

# game/CH1.rpy:1389
translate Paloslios leave_option2_2_47f90871:

    # j "Really...This is the right choice."
    j "De verdad... Esta es la elección correcta."

# game/CH1.rpy:1391
translate Paloslios leave_option2_2_ea8d461b_1:

    # "He watches carefully as you walk past him and up the stairs. He silently follows after you."
    "Él observa atentamente mientras pasas junto a él y subes las escaleras. Él te sigue en silencio."

# game/CH1.rpy:1402
translate Paloslios returnday1_27fb9010:

    # "You drop your luggage back by the door with a dull thud as you reenter the cabin."
    "Dejas tu equipaje junto a la puerta con un ruido sordo al volver a entrar a la cabina."

# game/CH1.rpy:1403
translate Paloslios returnday1_7fdd408a:

    # "The warmth of the cabin embraces you pitifully after your failed attempt."
    "La calidez de la cabaña te abraza lastimosamente después de tu intento fallido."

# game/CH1.rpy:1405
translate Paloslios returnday1_e4eadbd4:

    # "Jim glances at you distrustfully now, as if you might try to run out into the snow again."
    "Jim te mira con desconfianza ahora, como si fueras a intentar correr hacia la nieve otra vez."

# game/CH1.rpy:1407
translate Paloslios returnday1_076d9437:

    # "Another uncomfortable silence falls between you two again until Jim's the first to speak up."
    "Otro silencio incómodo vuelve a caer entre ustedes dos hasta que Jim es el primero en hablar."

# game/CH1.rpy:1410
translate Paloslios returnday1_986ae4b7:

    # j "Well, if you're gonna stay...Can I know what your name is?"
    j "Bueno, si vas a quedarte... ¿Puedo saber cómo te llamas?"

# game/CH1.rpy:1415
translate Paloslios returnday1_023a5fc6:

    # j "[povname]..."
    j "[povname]..."

# game/CH1.rpy:1416
translate Paloslios returnday1_696a83fe:

    # j "Now...would you like to rest by the fireplace, [povname]?"
    j "Ahora... ¿te gustaría descansar junto a la chimenea, [povname]?"

# game/CH1.rpy:1417
translate Paloslios returnday1_64b5dae0:

    # j "I can try to answer any concerns you have..."
    j "Puedo intentar responder cualquier inquietud que tengas..."

# game/CH1.rpy:1420
translate Paloslios returnday1_f99c6c3e:

    # "You finally agree to his offer."
    "Finalmente aceptas su oferta."

# game/CH1.rpy:1424
translate Paloslios returnday1_f6d3625d:

    # j "Good...But first I can tell you about the place."
    j "Bien...Pero primero te puedo contar sobre el lugar."

# game/CH1.rpy:1425
translate Paloslios returnday1_c78da095:

    # "Jim takes off his hat and seems to relax somewhat."
    "Jim se quita el sombrero y parece relajarse un poco."

# game/CH1.rpy:1429
translate Paloslios returnday1_e34bc9bc:

    # "Jim looks disappointed but lets you go."
    "Jim parece decepcionado pero te deja ir."

# game/CH1.rpy:1431
translate Paloslios returnday1_660281e0:

    # j "Ok..."
    j "Bueno..."

# game/day2.rpy:8
translate Paloslios day2_0ae9bcd0:

    # ""
    ""

# game/day2.rpy:13
translate Paloslios day2_3c486604:

    # "You wake with a gasp, the remnants of the dream clinging to you like frost."
    "Te despiertas con un grito ahogado, los restos del sueño se adhieren a ti como escarcha."

# game/day2.rpy:14
translate Paloslios day2_d62e6fb9:

    # "Moonlit eyes burned into yours from the shadows of the pines. Something that knew your name with a voice like cracking ice."
    "Los ojos iluminados por la luna ardían en los tuyos desde las sombras de los pinos. Algo que sabía tu nombre con una voz como el hielo rompiéndose."

# game/day2.rpy:16
translate Paloslios day2_04d82c0d:

    # "Unconsciously your fingers buried in the quilt, your pulse hammering like a trapped thing."
    "Inconscientemente, tus dedos se enterraron en la colcha y tu pulso martilló como si estuviera atrapado."

# game/day2.rpy:18
translate Paloslios day2_d9dba13e:

    # "Morning light seeps through the frosted windows. You wake to the sound of the gas stove clicking on and the flash of the flames."
    "La luz de la mañana se cuela por las ventanas esmeriladas. Te despiertas con el sonido de la estufa de gas al encenderse y el destello de las llamas."

# game/day2.rpy:20
translate Paloslios day2_3b19304f:

    # "Jim is awake, moving through the cabin with the creak of floorboards under his careful steps."
    "Jim está despierto, moviéndose por la cabaña con el crujido de las tablas del piso bajo sus cuidadosos pasos."

# game/day2.rpy:21
translate Paloslios day2_85618677:

    # "The bedroom door squeaks as you step out."
    "La puerta del dormitorio chirría al salir."

# game/day2.rpy:28
translate Paloslios day2_d471b920:

    # "Jim keeps his back to you, fingers fumbling with the coffee tin like it's the most fascinating thing in the world."
    "Jim te da la espalda, sus dedos juguetean con la lata de café como si fuera la cosa más fascinante del mundo."

# game/day2.rpy:29
translate Paloslios day2_01523040:

    # j "Ah...you're finally awake."
    j "Ah... finalmente estás despierto."

# game/day2.rpy:32
translate Paloslios day2_60abdcf8:

    # "The weight of yesterday's events presses against your ribs like a bruise."
    "El peso de los acontecimientos de ayer presiona contra tus costillas como un hematoma."

# game/day2.rpy:33
translate Paloslios day2_4c0ad63f:

    # "Your failed escape attempt."
    "Tu fallido intento de fuga."

# game/day2.rpy:34
translate Paloslios day2_6df0cd67:

    # "The silence between you isn't empty. It's full of everything left unsaid about the storm, about the way he carried you inside, about how close you came to..."
    "El silencio entre ustedes no está vacío. Está lleno de todo lo que no se dijo sobre la tormenta, sobre la forma en que te llevó adentro, sobre lo cerca que estuviste de..."

# game/day2.rpy:38
translate Paloslios day2_d48f7d89:

    # "He stills for a couple of heartbeats."
    "Se queda quieto durante un par de latidos."

# game/day2.rpy:39
translate Paloslios day2_6182e336:

    # "When he finally turns, his eyes are dark with something you can't name."
    "Cuando finalmente se da vuelta, sus ojos están oscuros con algo que no puedes nombrar."

# game/day2.rpy:41
translate Paloslios day2_ce82a073:

    # j "Just...don't do that again."
    j "Simplemente... no vuelvas a hacer eso."

# game/day2.rpy:43
translate Paloslios day2_828cc54f:

    # j "Mornin'"
    j "Buenos días"

# game/day2.rpy:45
translate Paloslios day2_00d8dcb4:

    # "Jim mutters a small good morning- happy not to mention what happened."
    "Jim murmura un breve \"buenos días\", feliz de no mencionar lo que pasó."

# game/day2.rpy:51
translate Paloslios day2_2687cd6f:

    # "You sit down at the table."
    "Te sientas a la mesa."

# game/day2.rpy:54
translate Paloslios day2_494d1cc1:

    # "Jim sets a chipped mug on the table and joins you. Steam curls from it, ghostly in the cold air. He doesn't speak."
    "Jim coloca una taza desportillada sobre la mesa y se une a ti. De él sale vapor, fantasmal en el aire frío. Él no habla."

# game/day2.rpy:55
translate Paloslios day2_ef656c03:

    # "The silence stretches, taut as a tripwire."
    "El silencio se prolonga, tenso como un cable trampa."

# game/day2.rpy:59
translate Paloslios day2_8f894ea6:

    # j "Well, since you'll be..."
    j "Bueno, ya que estarás..."

# game/day2.rpy:60
translate Paloslios day2_f9c8ff00:

    # "His jaw works. 'Staying' hangs unspoken but palpable in the air."
    "Su mandíbula funciona. La palabra \"quedarse\" flota tácita pero palpable en el aire."

# game/day2.rpy:62
translate Paloslios day2_9ec95f06:

    # j "...here awhile."
    j "...aquí un rato."

# game/day2.rpy:63
translate Paloslios day2_f453a51f:

    # "His thumb rubs at a stain on the table that isn't there."
    "Su pulgar frota una mancha en la mesa que no está allí."

# game/day2.rpy:65
translate Paloslios day2_120900ba:

    # j "What do I call you?"
    j "¿Cómo te llamo?"

# game/day2.rpy:71
translate Paloslios day2_023a5fc6:

    # j "[povname]..."
    j "[povname]..."

# game/day2.rpy:73
translate Paloslios day2_2f571d44:

    # j "[povname], it's for you..."
    j "[povname], es para ti..."

# game/day2.rpy:75
translate Paloslios day2_ec453d68:

    # "Jim pushes the mug towards you. An offering."
    "Jim empuja la taza hacia ti. Una ofrenda."

# game/day2.rpy:79
translate Paloslios day2_a89cbaf4:

    # "His eyes dart around the room- a nervous habit you're beginning to recognize."
    "Sus ojos recorren la habitación, un hábito nervioso que estás empezando a reconocer."

# game/day2.rpy:83
translate Paloslios day2_drink_d65bd1c0:

    # "The drink inside is [drink]- hot and fragrant, exactly as you like it. The scent wraps around you, warm and familiar."
    "La bebida que contiene es [drink]: caliente y fragante, exactamente como a ti te gusta. El aroma te envuelve, cálido y familiar."

# game/day2.rpy:84
translate Paloslios day2_drink_6864d9bf:

    # "You hadn't realized how thirsty you were until now."
    "No te habías dado cuenta de la sed que tenías hasta ahora."

# game/day2.rpy:86
translate Paloslios day2_drink_dc8e3ab1:

    # "Jim watches you intently."
    "Jim te observa atentamente."

# game/day2.rpy:94
translate Paloslios day2_drink_menu_1ca458a8:

    # "You take a sip from the mug- and it's good. Really good!"
    "Tomas un sorbo de la taza y está bueno. ¡Realmente bueno!"

# game/day2.rpy:95
translate Paloslios day2_drink_menu_3d4549f9:

    # "You drink a big gulp before you even realize it."
    "Bebes un gran trago antes de darte cuenta."

# game/day2.rpy:97
translate Paloslios day2_drink_menu_c87769d2:

    # "Jim's shoulders unclench, just a fraction."
    "Los hombros de Jim se relajan, sólo una fracción."

# game/day2.rpy:99
translate Paloslios day2_drink_menu_1b7e59a7:

    # j "I'm glad you like it."
    j "Me alegro que te guste."

# game/day2.rpy:100
translate Paloslios day2_drink_menu_4e735ab7:

    # "Jim's posture softens. He watches you with something like gratitude, his fingers tapping an absent rhythm against the table."
    "La postura de Jim se suaviza. Te mira con algo así como gratitud, sus dedos golpean un ritmo ausente contra la mesa."

# game/day2.rpy:105
translate Paloslios day2_drink_menu_617cc720:

    # "You lift the mug, letting the liquid barely touch your lips."
    "Levantas la taza, dejando que el líquido apenas toque tus labios."

# game/day2.rpy:106
translate Paloslios day2_drink_menu_eeacc45a:

    # "Jim's gaze drops to your throat, waiting for the telltale movement of a swallow."
    "La mirada de Jim cae hasta tu garganta, esperando el movimiento revelador de un trago."

# game/day2.rpy:108
translate Paloslios day2_drink_menu_3e2dd240:

    # "You fake it."
    "Lo finges."

# game/day2.rpy:109
translate Paloslios day2_drink_menu_592ae131:

    # "He doesn't blink."
    "Él no parpadea."

# game/day2.rpy:111
translate Paloslios day2_drink_menu_1ec745db:

    # "Then- slowly he takes a sip of his drink, his eyes never leaving yours."
    "Luego, lentamente, toma un sorbo de su bebida, sin dejar de mirar a los tuyos."

# game/day2.rpy:112
translate Paloslios day2_drink_menu_00c29882:

    # "At that moment, you spit the liquid gently back into the mug, the liquid swirling dark and unnoticed."
    "En ese momento, escupes el líquido suavemente de nuevo en la taza, el líquido se arremolina oscuro e inadvertido."

# game/day2.rpy:113
translate Paloslios day2_drink_menu_444b987a:

    # "His fingers tighten around his cup and he says nothing."
    "Sus dedos se aprietan alrededor de su taza y no dice nada."

# game/day2.rpy:114
translate Paloslios day2_drink_menu_af437abf:

    # "You occasionally lift your cup to appear to drink it."
    "De vez en cuando levantas tu taza para que parezca que la bebes."

# game/day2.rpy:118
translate Paloslios day2_drink_menu_28f676c3:

    # "He clears his throat as you look at him patiently."
    "Se aclara la garganta mientras lo miras pacientemente."

# game/day2.rpy:120
translate Paloslios day2_drink_menu_22a5b20d:

    # j "It's...[drink]. That's what you like, right? You had made this yesterday?"
    j "Es...[drink]. Eso es lo que te gusta, ¿verdad? ¿Habías hecho esto ayer?"

# game/day2.rpy:121
translate Paloslios day2_drink_menu_6186867a:

    # "You nod."
    "Asientes."

# game/day2.rpy:123
translate Paloslios day2_drink_menu_dd35c592:

    # "He exhales, just slightly, and nudges the mug closer."
    "Exhala, sólo ligeramente, y acerca la taza."

# game/day2.rpy:131
translate Paloslios day2_drink_refuse_1056e1f5:

    # "You push the mug back and it scrapes across the table."
    "Empujas la taza hacia atrás y raspa la mesa."

# game/day2.rpy:133
translate Paloslios day2_drink_refuse_7a484412:

    # "Jim goes very still."
    "Jim se queda muy quieto."

# game/day2.rpy:134
translate Paloslios day2_drink_refuse_b1ba4757:

    # "Jim's expression flickers- something between hurt and frustration."
    "La expresión de Jim parpadea, algo entre dolor y frustración."

# game/day2.rpy:135
translate Paloslios day2_drink_refuse_433d2093:

    # j "You...don't want it?"
    j "¿Tú... no lo quieres?"

# game/day2.rpy:136
translate Paloslios day2_drink_refuse_48148bbf:

    # "It's not a question. It's a challenge."
    "No es una pregunta. Es un desafío."

# game/day2.rpy:141
translate Paloslios day2_drink_refuse_53976138:

    # "You shake your head."
    "Sacudes la cabeza."

# game/day2.rpy:143
translate Paloslios day2_drink_refuse_7ed8b737:

    # "A muscle jumps in his jaw. The silence in the room grows teeth."
    "Un músculo salta en su mandíbula. Al silencio en la habitación le crecen los dientes."

# game/day2.rpy:144
translate Paloslios day2_drink_refuse_20a95ca1:

    # "Your mug stays untouched and Jim doesn't drink."
    "Tu taza permanece intacta y Jim no bebe."

# game/day2.rpy:145
translate Paloslios day2_drink_refuse_3888b370:

    # "The air in the cabin thickens, the quiet now a living thing between you- heavy, suffocating."
    "El aire en la cabina se vuelve más espeso, el silencio ahora es algo vivo entre ustedes: pesado, sofocante."

# game/day2.rpy:149
translate Paloslios day2_drink_refuse_f3415fd9:

    # "You reluctantly reach out for the mug and Jim watches the movement carefully."
    "De mala gana, tomas la taza y Jim observa el movimiento con atención."

# game/day2.rpy:152
translate Paloslios day2_drink_refuse_840125a3:

    # "The steam from your mug curls between you like a disorienting fog."
    "El vapor de tu taza se enrolla entre ustedes como una niebla desorientadora."

# game/day2.rpy:155
translate Paloslios day2_drink_refuse_17ec5238:

    # "Jim watches- not the drink, not your hands, but the space where your lips will meet the rim. The silence stretches, charged with something unspoken."
    "Jim observa, no la bebida, ni tus manos, sino el espacio donde tus labios se unen con el borde. El silencio se prolonga, cargado de algo no dicho."

# game/day2.rpy:156
translate Paloslios day2_drink_refuse_e693278b:

    # "The warmth of your drink spreads through your chest, familiar and comforting."
    "El calor de tu bebida se esparce por tu pecho, familiar y reconfortante."

# game/day2.rpy:157
translate Paloslios day2_drink_refuse_f87f63aa:

    # j "Is it good? How's the temperature?"
    j "¿Es bueno? ¿Cómo está la temperatura?"

# game/day2.rpy:162
translate Paloslios day2_drink_refuse_9f531d85:

    # "With pride barely hidden, a flicker of satisfaction crosses his face. He leans back in his chair, fingers drumming once against the table."
    "Con el orgullo apenas oculto, un destello de satisfacción cruza su rostro. Se recuesta en su silla y tamborilea los dedos contra la mesa."

# game/day2.rpy:164
translate Paloslios day2_drink_refuse_04c24ba1:

    # j "I remembered how you take it."
    j "Recordé cómo lo tomas."

# game/day2.rpy:168
translate Paloslios day2_drink_refuse_f03339c9:

    # "His breath catches before he starts asking you what to do for next time, eyes attentive."
    "Se queda sin aliento antes de comenzar a preguntarte qué hacer la próxima vez, con los ojos atentos."

# game/day2.rpy:170
translate Paloslios day2_drink_refuse_6ad1d6aa:

    # "You tell him what you'd like changed and he nods along."
    "Le dices lo que te gustaría cambiar y él asiente."

# game/day2.rpy:172
translate Paloslios day2_drink_refuse_307347dc:

    # j "I see...I'll remember that for next time."
    j "Ya veo... lo recordaré para la próxima vez."

# game/day2.rpy:175
translate Paloslios day2_drink_refuse_8e60c41e:

    # "Before you know it, you've drank it all. Jim holds out his hand to take your mug and you oblige."
    "Antes de que te des cuenta, lo habrás bebido todo. Jim extiende su mano para tomar tu taza y tú lo haces."

# game/day2.rpy:179
translate Paloslios day2_drink_refuse_add6daab:

    # "Then he busies himself with taking your mugs to the sink, but you catch the way his thumb rubs over the spot your lips just touched."
    "Luego se ocupa de llevar tus tazas al fregadero, pero captas la forma en que su pulgar frota el lugar que tus labios acaban de tocar."

# game/day2.rpy:183
translate Paloslios day2_drink_refuse_830bd1cd:

    # "Jim's gaze lingers on your throat. Waiting."
    "La mirada de Jim se detiene en tu garganta. Espera."

# game/day2.rpy:185
translate Paloslios day2_drink_refuse_32249a6e:

    # "When you set the mug down his eyes narrow, just for a second, before he reaches for it."
    "Cuando dejas la taza, sus ojos se entrecierran, sólo por un segundo, antes de alcanzarla."

# game/day2.rpy:186
translate Paloslios day2_drink_refuse_a9adfcd9:

    # j "Too hot?"
    j "¿Demasiado calor?"

# game/day2.rpy:192
translate Paloslios day2_drink_refuse_c2e9426d:

    # "He hums, noncommittal, as he busies himself with his mug again."
    "Tararea, evasivo, mientras se ocupa de nuevo con su taza."

# game/day2.rpy:194
translate Paloslios day2_drink_refuse_91a83db8:

    # "The mug sits between you awkwardly, the steam becoming as cold as the air between you."
    "La taza queda incómoda entre ustedes y el vapor se vuelve tan frío como el aire entre ustedes."

# game/day2.rpy:198
translate Paloslios day2_drink_refuse_113043ff:

    # "His jaw tightens- knuckles white on his mug's handle."
    "Su mandíbula se aprieta, los nudillos blancos en el asa de su taza."

# game/day2.rpy:199
translate Paloslios day2_drink_refuse_d5994a3d:

    # j "I see..."
    j "Ya veo..."

# game/day2.rpy:204
translate Paloslios day2_drink_refuse_66db51f2:

    # "He takes the abandoned mug roughly and the mug disappears into the sink with a clatter."
    "Toma la taza abandonada con brusquedad y la taza desaparece en el fregadero con estrépito."

# game/day2.rpy:206
translate Paloslios day2_drink_refuse_8191a9ad:

    # "But the way he watches you now- like he's memorizing the shape of your distrust."
    "Pero la forma en que te mira ahora... como si estuviera memorizando la forma de tu desconfianza."

# game/day2.rpy:211
translate Paloslios day2_drink_refuse_1a0e2b5f:

    # "The mug sits untouched between you. Jim's fingers flex against his mug."
    "La taza permanece intacta entre ustedes. Los dedos de Jim se flexionan contra su taza."

# game/day2.rpy:212
translate Paloslios day2_drink_refuse_c9bcf740:

    # "Jim's next words are a whisper."
    "Las siguientes palabras de Jim son un susurro."

# game/day2.rpy:214
translate Paloslios day2_drink_refuse_c9eb5b60:

    # j "{size=*0.75}You think it's poisoned or something?{/size}"
    j "{size=*0.75}¿Crees que está envenenado o algo así?{/size}"

# game/day2.rpy:215
translate Paloslios day2_drink_refuse_c556ac06:

    # "There's no anger in his voice. Just something hollow. If he was joking, it was hard to tell."
    "No hay ira en su voz. Sólo algo hueco. Si estaba bromeando, era difícil saberlo."

# game/day2.rpy:219
translate Paloslios day2_drink_refuse_ae80c876:

    # "He cuts you off with a shake of his head. His expression is unreadable."
    "Él te interrumpe con un movimiento de cabeza. Su expresión es ilegible."

# game/day2.rpy:220
translate Paloslios day2_drink_refuse_5bcfda07:

    # j "Don't."
    j "No."

# game/day2.rpy:221
translate Paloslios day2_drink_refuse_d6fda896:

    # "The word is final. A stiff silence covers you both."
    "La palabra es definitiva. Un rígido silencio los cubre a ambos."

# game/day2.rpy:224
translate Paloslios day2_drink_refuse_0a0f79c1:

    # "His jaw tightens at your silence."
    "Su mandíbula se aprieta ante tu silencio."

# game/day2.rpy:228
translate Paloslios day2_drink_refuse_fd66b458:

    # "Something flashes in his eyes- hurt, fury, hunger-"
    "Algo brilla en sus ojos: dolor, furia, hambre."

# game/day2.rpy:230
translate Paloslios day2_drink_refuse_ded834b1:

    # "-before he reigns in his expression."
    "-antes de que reine en su expresión."

# game/day2.rpy:231
translate Paloslios day2_drink_refuse_5fc0eb37:

    # j "Fair enough."
    j "Me parece bien."

# game/day2.rpy:235
translate Paloslios day2_drink_refuse_d2a0a729:

    # "Jim stands up suddenly, his gaze lowering directly towards yours, and grabs your mug."
    "Jim se levanta de repente, su mirada baja directamente hacia la tuya y agarra tu taza."

# game/day2.rpy:236
translate Paloslios day2_drink_refuse_6b31bd01:

    # "He drains your mug himself in one long swallow. A challenge."
    "Él mismo apura tu taza de un largo trago. Un desafío."

# game/day2.rpy:238
translate Paloslios day2_drink_refuse_8191a9ad_1:

    # "But the way he watches you now- like he's memorizing the shape of your distrust."
    "Pero la forma en que te mira ahora... como si estuviera memorizando la forma de tu desconfianza."

# game/day2.rpy:270
translate Paloslios day2_cold_route_961c9fa5:

    # "Jim's face shutters. He sets his cold mug down with deliberate care, then retreats to his room without a word."
    "La cara de Jim se contrae. Deja su taza fría con cuidado deliberado y luego se retira a su habitación sin decir una palabra."

# game/day2.rpy:274
translate Paloslios day2_cold_route_d5ee4b52:

    # "The click of his door latch is deafening in the quiet cabin. You are alone- for now."
    "El clic del pestillo de la puerta es ensordecedor en la silenciosa cabina. Estás solo, por ahora."

# game/day2.rpy:275
translate Paloslios day2_cold_route_82304254:

    # "The snowstorm howls outside, relentless. Jim's silent retreat to his room leaves you standing alone in the dim cabin, the air thick with unspoken tension."
    "Afuera la tormenta de nieve aúlla implacable. La retirada silenciosa de Jim a su habitación te deja solo en la cabina en penumbra, con el aire cargado de una tensión tácita."

# game/day2.rpy:279
translate Paloslios day2_cold_route_d594df8e:

    # "You retreat to your room, the walls pressing in as you consider your options."
    "Te retiras a tu habitación, las paredes presionan mientras consideras tus opciones."

# game/day2.rpy:280
translate Paloslios day2_cold_route_f1bc4c9c:

    # "But for now, you have time. Time to think. Time to explore."
    "Pero por ahora tienes tiempo. Es hora de pensar. Es hora de explorar."

# game/day2.rpy:288
translate Paloslios day2_cold_route_9fdb851d:

    # "You sit on the edge of your bed, listening to the muffled creak of the cabin under the weight of the snow."
    "Te sientas en el borde de tu cama y escuchas el crujido ahogado de la cabaña bajo el peso de la nieve."

# game/day2.rpy:290
translate Paloslios day2_cold_route_dff66e64:

    # "The quiet is oppressive, broken only by the occasional gust of wind rattling the windowpane."
    "El silencio es opresivo, roto sólo por alguna que otra ráfaga de viento que golpea el cristal de la ventana."

# game/day2.rpy:291
translate Paloslios day2_cold_route_579f484d:

    # "Without being able to leave the shrinking cabin, what will you do?"
    "Sin poder salir de la cabina menguante, ¿qué harás?"

# game/day2.rpy:298
translate Paloslios day2_cold_route_29f17192:

    # "You head out back into the main room to see if there's anything to pass the time."
    "Regresas a la sala principal para ver si hay algo para pasar el tiempo."

# game/day2.rpy:300
translate Paloslios day2_cold_route_98d5c00a:

    # "The storm rattles the windows in the cabin's dim living room."
    "La tormenta hace temblar las ventanas del oscuro salón de la cabaña."

# game/day2.rpy:301
translate Paloslios day2_cold_route_f15d8083:

    # "Jim is nowhere to be seen- must still be in his room."
    "Jim no está por ninguna parte; todavía debe estar en su habitación."

# game/day2.rpy:302
translate Paloslios day2_cold_route_fe380a5f:

    # "What now?"
    "¿Y ahora qué?"

# game/day2.rpy:311
translate Paloslios day2_cold_route_menu_46109ab2:

    # "You approach the small, sparse bookcase and read the titles as you run your fingers along the spines."
    "Te acercas a la pequeña y escasa estantería y lees los títulos mientras pasas los dedos por los lomos."

# game/day2.rpy:312
translate Paloslios day2_cold_route_menu_50f6d8d8:

    # "Wilderness survival... edible plants... The History of Knot-Tying? Seriously?"
    "Supervivencia en la naturaleza... plantas comestibles... ¿La historia de hacer nudos? ¿En serio?"

# game/day2.rpy:313
translate Paloslios day2_cold_route_menu_a94fc92f:

    # "Your fingers pause on a worn leather spine tucked between two larger volumes. It doesn't have a title."
    "Tus dedos se detienen en un lomo de cuero desgastado escondido entre dos volúmenes más grandes. No tiene título."

# game/day2.rpy:315
translate Paloslios day2_cold_route_menu_293fb323:

    # "You pull out a small journal. The leather is soft with age, and the edges are frayed."
    "Sacas un pequeño diario. El cuero está blando con el tiempo y los bordes están deshilachados."

# game/day2.rpy:316
translate Paloslios day2_cold_route_menu_d7403c33:

    # "There's just a faint crescent moon embossed on the cover."
    "Sólo hay una tenue luna creciente grabada en la portada."

# game/day2.rpy:326
translate Paloslios day2_cold_route_menu_67a1538b:

    # "You hesitate only momentarily- then open it."
    "Dudas sólo un momento y luego lo abres."

# game/day2.rpy:327
translate Paloslios day2_cold_route_menu_b4f9e4f2:

    # "The first few pages are dated entries in neat, careful handwriting."
    "Las primeras páginas están fechadas y escritas a mano con cuidado y pulcritud."

# game/day2.rpy:331
translate Paloslios day2_cold_route_menu_22eb23e4:

    # "You flip further in. The entries become less frequent, the handwriting changing - sometimes neat, sometimes jagged."
    "Hojeas más hacia adentro. Las entradas se vuelven menos frecuentes, la escritura cambia: a veces clara, a veces irregular."

# game/day2.rpy:333
translate Paloslios day2_cold_route_menu_15188dab:

    # "Some pages have sketches - plants and animal tracks."
    "Algunas páginas tienen bocetos: plantas y huellas de animales."

# game/day2.rpy:334
translate Paloslios day2_cold_route_menu_ddb138f8:

    # "Then you reach a section where the writing changes dramatically."
    "Luego llegas a una sección donde la escritura cambia dramáticamente."

# game/day2.rpy:339
translate Paloslios day2_cold_route_menu_0ae9bcd0:

    # ""
    ""

# game/day2.rpy:347
translate Paloslios day2_cold_route_menu_5e6851ca:

    # "Your breath catches. 'Them'? You flip faster now. Near the end, the most recent entry."
    "Se te corta el aliento. 'A ellos'? Ahora giras más rápido. Cerca del final, la entrada más reciente."

# game/day2.rpy:351
translate Paloslios day2_cold_route_menu_0ae9bcd0_1:

    # ""
    ""

# game/day2.rpy:355
translate Paloslios day2_cold_route_menu_feb924af:

    # "As you turn the page, a dried flower falls into your lap. A white bloom, perfectly preserved."
    "Al pasar la página, una flor seca cae en tu regazo. Una flor blanca, perfectamente conservada."

# game/day2.rpy:360
translate Paloslios day2_cold_route_menu_0e6657c9:

    # "You stare at the flower in your palm, breathless from what you just read. The cabin seems too quiet suddenly."
    "Te quedas mirando la flor en tu palma, sin aliento por lo que acabas de leer. De repente, la cabina parece demasiado silenciosa."

# game/day2.rpy:363
translate Paloslios day2_cold_route_menu_4cff6f02:

    # "Then- a floorboard creaks behind you."
    "Entonces, una tabla del suelo cruje detrás de ti."

# game/day2.rpy:365
translate Paloslios day2_cold_route_menu_6a27275b:

    # "You snap the journal shut, but it's too late."
    "Cierras el diario, pero ya es demasiado tarde."

# game/day2.rpy:368
translate Paloslios day2_cold_route_menu_0cafb87f:

    # "You spin to see Jim leaning in the bedroom doorway. How long has he been watching?"
    "Te giras para ver a Jim apoyado en la puerta del dormitorio. ¿Cuánto tiempo lleva mirando?"

# game/day2.rpy:370
translate Paloslios day2_cold_route_menu_84ccb7e7:

    # j "Find anything interesting?"
    j "¿Encontraste algo interesante?"

# game/day2.rpy:372
translate Paloslios day2_cold_route_menu_d794bf29:

    # "His expression is unreadable as he watches you with those too-blue eyes, fingers flexing at his side."
    "Su expresión es ilegible mientras te mira con esos ojos demasiado azules y los dedos flexionados a los costados."

# game/day2.rpy:373
translate Paloslios day2_cold_route_menu_9e122ea2:

    # "The flower feels colder in your hand."
    "La flor se siente más fría en tu mano."

# game/day2.rpy:378
translate Paloslios day2_cold_route_menu_6b68f046:

    # "You slide the journal back casually."
    "Deslizas el diario hacia atrás casualmente."

# game/day2.rpy:379
translate Paloslios day2_cold_route_menu_3852a607:

    # "He steps closer, his gaze dropping to the journal that you just put back on the shelf."
    "Se acerca y su mirada se posa en el diario que acabas de dejar en el estante."

# game/day2.rpy:381
translate Paloslios day2_cold_route_menu_9bc75f75:

    # j "You should be careful with my things."
    j "Deberías tener cuidado con mis cosas."

# game/day2.rpy:383
translate Paloslios day2_cold_route_menu_360b7d10:

    # j "Somethings...you shouldn't see."
    j "Algunas cosas... no deberías ver."

# game/day2.rpy:384
translate Paloslios day2_cold_route_menu_08ddb537:

    # "He smiles at you, but it doesn't reach his eyes."
    "Te sonríe, pero no llega a sus ojos."

# game/day2.rpy:388
translate Paloslios day2_cold_route_menu_726844ec:

    # "You hold the journal up, testing his reaction. Watching his face closely."
    "Sostienes el diario en alto, probando su reacción. Observando su rostro de cerca."

# game/day2.rpy:390
translate Paloslios day2_cold_route_menu_5356083e:

    # "His jaw tightens and he holds out his hand expectantly."
    "Su mandíbula se aprieta y extiende su mano expectante."

# game/day2.rpy:392
translate Paloslios day2_cold_route_menu_ad08274e:

    # j "Private thoughts. You wouldn't like it if I went through your things."
    j "Pensamientos privados. No te gustaría que revisara tus cosas."

# game/day2.rpy:394
translate Paloslios day2_cold_route_menu_c1dadcb3:

    # "He pointedly glances at your half-open bedroom door."
    "Él mira intencionadamente la puerta entreabierta de tu dormitorio."

# game/day2.rpy:395
translate Paloslios day2_cold_route_menu_9b5cc344:

    # "You hand back the book, unsatisfied but doesn't look like Jim will say any more on the subject."
    "Le devuelves el libro, insatisfecho, pero no parece que Jim vaya a decir nada más sobre el tema."

# game/day2.rpy:397
translate Paloslios day2_cold_route_menu_bce3c807:

    # "He slides the journal back into its spot."
    "Desliza el diario de nuevo en su lugar."

# game/day2.rpy:401
translate Paloslios day2_cold_route_menu_1e8e0991:

    # "You let the silence stretch until he's the one to break."
    "Dejas que el silencio se alargue hasta que sea él quien rompa."

# game/day2.rpy:403
translate Paloslios day2_cold_route_menu_7a69c340:

    # "Jim finally exhales through his nose and he holds out his hand expectantly."
    "Jim finalmente exhala por la nariz y extiende su mano expectante."

# game/day2.rpy:405
translate Paloslios day2_cold_route_menu_0ff84938:

    # "Wordlessly, you hand him back his journal and he returns it to its place on the shelf."
    "Sin decir palabra, le devuelves su diario y él lo devuelve a su lugar en el estante."

# game/day2.rpy:408
translate Paloslios day2_cold_route_menu_1823a632:

    # "The moment stretches. The fire pops."
    "El momento se alarga. El fuego estalla."

# game/day2.rpy:409
translate Paloslios day2_cold_route_menu_971e7b17:

    # "Jim's gaze locks onto your clenched fist where the flower rests, icy against your palm."
    "La mirada de Jim se fija en tu puño cerrado donde descansa la flor, helada contra tu palma."

# game/day2.rpy:411
translate Paloslios day2_cold_route_menu_311fa5be:

    # "His expression flickers- something between panic and hunger- before smoothing into careful neutrality."
    "Su expresión parpadea, algo entre el pánico y el hambre, antes de suavizarse y adoptar una cuidadosa neutralidad."

# game/day2.rpy:413
translate Paloslios day2_cold_route_menu_8ddc9620:

    # j "What else is in your hand?"
    j "¿Qué más hay en tu mano?"

# game/day2.rpy:414
translate Paloslios day2_cold_route_menu_8da84cfb:

    # "Your fingers tremble. The flower feels heavier than it should."
    "Tus dedos tiemblan. La flor se siente más pesada de lo que debería."

# game/day2.rpy:415
translate Paloslios day2_cold_route_menu_d8cec504:

    # "When you unfurl your hand, the white petals are now slightly crumpled, edges blackened with frostbite."
    "Cuando extiendes la mano, los pétalos blancos ahora están ligeramente arrugados y los bordes ennegrecidos por la congelación."

# game/day2.rpy:417
translate Paloslios day2_cold_route_menu_f9076c21:

    # "Jim's breath catches- just for a second before he slowly, carefully speaks."
    "A Jim se le corta el aliento, sólo por un segundo antes de hablar lenta y cuidadosamente."

# game/day2.rpy:419
translate Paloslios day2_cold_route_menu_9643d08f:

    # j "Is that yours?"
    j "¿Eso es tuyo?"

# game/day2.rpy:424
translate Paloslios day2_cold_route_menu_4c67077a:

    # "Jim grabs your wrist to pull you towards him, peering at the flower."
    "Jim te agarra de la muñeca para atraerte hacia él y mira la flor."

# game/day2.rpy:426
translate Paloslios day2_cold_route_menu_678e2017:

    # j "Hmm, I don't think so..."
    j "Mmmm, no lo creo..."

# game/day2.rpy:427
translate Paloslios day2_cold_route_menu_5dbc3607:

    # "His thumb brushes your wrist as he pulls away- warning."
    "Su pulgar roza tu muñeca mientras se aleja, advertencia."

# game/day2.rpy:430
translate Paloslios day2_cold_route_menu_c8ccb9b6:

    # "Jim tilts his head, the picture of confusion, as he regards the thing in your hand."
    "Jim inclina la cabeza, la imagen de confusión, mientras mira la cosa en tu mano."

# game/day2.rpy:431
translate Paloslios day2_cold_route_menu_35a2a418:

    # j "No...I didn't do that."
    j "No...yo no hice eso."

# game/day2.rpy:436
translate Paloslios day2_cold_route_menu_8873aeb0:

    # "Jim goes deathly still but watches you."
    "Jim se queda mortalmente quieto pero te observa."

# game/day2.rpy:437
translate Paloslios day2_cold_route_menu_c1d347e7:

    # j "Now why'd you go and do that?"
    j "¿Por qué fuiste y hiciste eso?"

# game/day2.rpy:438
translate Paloslios day2_cold_route_menu_f1553026:

    # "When you open your hand, the flower is intact- but now damp as if weeping."
    "Cuando abres la mano, la flor está intacta, pero ahora húmeda como si llorara."

# game/day2.rpy:442
translate Paloslios day2_cold_route_menu_4b648f8f:

    # "Jim looks at you blankly."
    "Jim te mira sin comprender."

# game/day2.rpy:443
translate Paloslios day2_cold_route_menu_c342032b:

    # j "Hmm, wonder how it got there then."
    j "Hmm, me pregunto cómo llegó allí entonces."

# game/day2.rpy:447
translate Paloslios day2_cold_route_menu_1b37a4d7:

    # "He takes the flower from your hand, turns it over like a curiosity, and then pockets it while giving you an unreadable look."
    "Toma la flor de tu mano, le da la vuelta como si fuera una curiosidad y luego se la guarda en el bolsillo mientras te da una mirada ilegible."

# game/day2.rpy:449
translate Paloslios day2_cold_route_menu_eb47f8b1:

    # j "It's just a flower."
    j "Es sólo una flor."

# game/day2.rpy:450
translate Paloslios day2_cold_route_menu_525d18e0:

    # "You still feel the coolness lingering in your trembling hand."
    "Todavía sientes el frescor persistente en tu mano temblorosa."

# game/day2.rpy:455
translate Paloslios day2_cold_route_menu_92eebdda:

    # "Your fingers hover over the worn leather journal for only a second before you push it back into place."
    "Tus dedos se ciernen sobre el desgastado diario de cuero durante sólo un segundo antes de volver a colocarlo en su lugar."

# game/day2.rpy:456
translate Paloslios day2_cold_route_menu_fcb8ef08:

    # "Something about the crescent moon embossing makes your skin prickle."
    "Algo en el relieve de la luna creciente hace que te pique la piel."

# game/day2.rpy:458
translate Paloslios day2_cold_route_menu_fe33b2b7:

    # "Instead, you pull out a thick novel titled: Surviving the Wilds."
    "En lugar de eso, sacas una novela espesa titulada: Surviving the Wilds."

# game/day2.rpy:461
translate Paloslios day2_cold_route_menu_685e6fbb:

    # "Its spine cracked from frequent reading. It promises to be a tale of one man's heroic journey in the wilderness."
    "Su lomo se quebró por la lectura frecuente. Promete ser la historia del heroico viaje de un hombre por el desierto."

# game/day2.rpy:462
translate Paloslios day2_cold_route_menu_a05719bb:

    # "As you settle into the chair, you catch a faint scent- like snow and something metallic. The fire pops. You ignore it."
    "Mientras te acomodas en la silla, percibes un leve olor, como a nieve y algo metálico. El fuego estalla. Lo ignoras."

# game/day2.rpy:463
translate Paloslios day2_cold_route_menu_aba0a7a8:

    # "You notice a dog-eared page and flip to it curiously."
    "Observas una página con las orejas dobladas y la hojeas con curiosidad."

# game/day2.rpy:465
translate Paloslios day2_cold_route_menu_e3a258d7:

    # "It's titled: Winter Isolation and the margins are filled with notes."
    "Se titula: Winter Isolation y los márgenes están llenos de notas."

# game/day2.rpy:466
translate Paloslios day2_cold_route_menu_9ada4aaf:

    # "Jim's handwriting perhaps?"
    "¿Quizás la letra de Jim?"

# game/day2.rpy:469
translate Paloslios day2_cold_route_menu_0ae9bcd0_2:

    # ""
    ""

# game/day2.rpy:480
translate Paloslios day2_cold_route_menu_66c20ac3:

    # "A sound behind you- the creak of a floorboard. Jim stands in the doorway."
    "Un sonido detrás de ti: el crujido de una tabla del piso. Jim está en la puerta."

# game/day2.rpy:482
translate Paloslios day2_cold_route_menu_c1a9ca33:

    # "His posture is relaxed, but his eyes track your every move- until they land on the book in your hands. Something in his expression softens."
    "Su postura es relajada, pero sus ojos siguen cada uno de tus movimientos, hasta que aterrizan en el libro que tienes en las manos. Algo en su expresión se suaviza."

# game/day2.rpy:483
translate Paloslios day2_cold_route_menu_2eb7ba28:

    # j "Good choice."
    j "Buena elección."

# game/day2.rpy:485
translate Paloslios day2_cold_route_menu_4f5b1eb0:

    # "He pushes off the doorframe and steps closer."
    "Empuja el marco de la puerta y se acerca."

# game/day2.rpy:487
translate Paloslios day2_cold_route_menu_70b54b7a:

    # "His fingers brush yours as he takes the novel from you- not roughly, but with a quiet certainty. He slides it back onto the shelf."
    "Sus dedos rozan los tuyos mientras te quita la novela, no con brusquedad, pero sí con una tranquila certeza. Lo desliza nuevamente sobre el estante."

# game/day2.rpy:489
translate Paloslios day2_cold_route_menu_2a97ef27:

    # j "But you should read this instead."
    j "Pero deberías leer esto en su lugar."

# game/day2.rpy:491
translate Paloslios day2_cold_route_menu_745f9ddf:

    # "Then, he reaches over to you and you flinch-"
    "Luego, se acerca a ti y tú te estremeces."

# game/day2.rpy:494
translate Paloslios day2_cold_route_menu_46eb9e8c:

    # "His gaze holds yours as he slowly pulls out a book from the shelf next to you and hands it to you firmly. The cover reads: Wilderness First-aid Manual."
    "Su mirada sostiene la tuya mientras lentamente saca un libro del estante junto a ti y te lo entrega con firmeza. En la portada se lee: Manual de primeros auxilios para zonas silvestres."

# game/day2.rpy:496
translate Paloslios day2_cold_route_menu_75480787:

    # j "Read this. It's good for you. Never know when you'll need it."
    j "Lee esto. Es bueno para ti. Nunca se sabe cuándo lo necesitará."

# game/day2.rpy:497
translate Paloslios day2_cold_route_menu_bf678f3d:

    # "His finger taps the back- right over an advertisement of: Learn how to Treat Frostbite. His gaze flicks to your exposed fingertips, then back to your face. A silent message."
    "Su dedo golpea la parte posterior derecha de un anuncio de: Aprenda cómo tratar la congelación. Su mirada se dirige a las yemas de tus dedos expuestos y luego vuelve a tu cara. Un mensaje silencioso."

# game/day2.rpy:500
translate Paloslios day2_cold_route_menu_9b5c70c6:

    # j "Especially with what you tried to pull the other day..."
    j "Especialmente con lo que intentaste hacer el otro día..."

# game/day2.rpy:501
translate Paloslios day2_cold_route_menu_94ae5fbe:

    # "Jim bitterly scowls at the memory of you passing out in the cold."
    "Jim frunce el ceño con amargura al recordar que te desmayaste por el frío."

# game/day2.rpy:504
translate Paloslios day2_cold_route_menu_9748cc46:

    # "The moment stretches. The storm rattles the windows, but Jim doesn't move away."
    "El momento se alarga. La tormenta hace temblar las ventanas, pero Jim no se aleja."

# game/day2.rpy:511
translate Paloslios day2_cold_route_menu_8fc653c0:

    # "Jim stills. His fingers flex, then curl into fists."
    "Jim se queda quieto. Sus dedos se flexionan y luego se cierran en puños."

# game/day2.rpy:513
translate Paloslios day2_cold_route_menu_382f07db:

    # j "Well, you should."
    j "Bueno, deberías hacerlo."

# game/day2.rpy:515
translate Paloslios day2_cold_route_menu_93acae4c:

    # j "Because out here, not knowing can kill you."
    j "Porque aquí afuera el no saber puede matarte."

# game/day2.rpy:517
translate Paloslios day2_cold_route_menu_7452658d:

    # j "And I'd hate for that to happen."
    j "Y odiaría que eso sucediera."

# game/day2.rpy:518
translate Paloslios day2_cold_route_menu_e8f8742b:

    # "His words are spoken like a promise- a threat."
    "Sus palabras son pronunciadas como una promesa, una amenaza."

# game/day2.rpy:520
translate Paloslios day2_cold_route_menu_d26dec25:

    # "He gives you a final withering look before leaving again."
    "Te lanza una última mirada fulminante antes de marcharse de nuevo."

# game/day2.rpy:528
translate Paloslios day2_cold_route_menu_0e9a7c0e:

    # "Jim's lips twitch-not quite a smile, but close. He steps back, satisfied."
    "Los labios de Jim se contraen; no es una sonrisa, pero sí cerca. Da un paso atrás, satisfecho."

# game/day2.rpy:530
translate Paloslios day2_cold_route_menu_a09e760d:

    # j "Smart."
    j "Elegante."

# game/day2.rpy:532
translate Paloslios day2_cold_route_menu_44ca1076:

    # "He turns to the fire, but you catch him watching you from the corner of his eye."
    "Se vuelve hacia el fuego, pero lo pillas mirándote por el rabillo del ojo."

# game/day2.rpy:536
translate Paloslios day2_cold_route_menu_f2a92152:

    # "Soon, he heads back to his room without another word."
    "Pronto, regresa a su habitación sin decir una palabra más."

# game/day2.rpy:537
translate Paloslios day2_cold_route_menu_26ac183e:

    # "You sit and try to read some of the manual, but Jim's appearance leaves you slightly unsettled."
    "Te sientas e intentas leer parte del manual, pero la apariencia de Jim te deja un poco inquieto."

# game/day2.rpy:540
translate Paloslios day2_cold_route_menu_c7df99ba:

    # "Even though Jim has retreated to his room, you still somehow feel his eyes on you."
    "Aunque Jim se ha retirado a su habitación, de alguna manera todavía sientes sus ojos puestos en ti."

# game/day2.rpy:541
translate Paloslios day2_cold_route_menu_2b729219:

    # "Maybe you can look into the bookcase more later...when Jim is occupied elsewhere."
    "Tal vez puedas mirar más dentro de la estantería más tarde... cuando Jim esté ocupado en otra parte."

# game/day2.rpy:542
translate Paloslios day2_cold_route_menu_fe380a5f:

    # "What now?"
    "¿Y ahora qué?"

# game/day2.rpy:547
translate Paloslios day2_cold_route_menu_9c8fd294:

    # "You're hungry. Jim hasn't offered to cook so it's time to fend for yourself."
    "Tienes hambre. Jim no se ha ofrecido a cocinar, así que es hora de valerse por sí mismo."

# game/day2.rpy:552
translate Paloslios day2_cold_route_menu_cff49560:

    # "The cabin's kitchen is cramped- a propane stove, a scarred wooden counter, and a fridge groaning in the corner."
    "La cocina de la cabaña es estrecha: una estufa de propano, una encimera de madera desgastada y un refrigerador que cruje en un rincón."

# game/day2.rpy:554
translate Paloslios day2_cold_route_menu_a93fad01:

    # "But when you tug open the fridge, the chill that rolls out feels...mocking. The shelves are nearly bare."
    "Pero cuando abres el refrigerador, el frío que se extiende se siente... burlón. Los estantes están casi vacíos."

# game/day2.rpy:555
translate Paloslios day2_cold_route_menu_fd32e41d:

    # "There's a small carton of eggs, half a stick of butter, and a jar of preserves- unlabeled, the contents dark and clotted."
    "Hay un pequeño cartón de huevos, media barra de mantequilla y un frasco de conservas, sin etiqueta y con el contenido oscuro y coagulado."

# game/day2.rpy:556
translate Paloslios day2_cold_route_menu_e2c08a69:

    # "You could've sworn there was more yesterday. But the fridge hums innocently, its emptiness glaring."
    "Podrías haber jurado que ayer hubo más. Pero el frigorífico zumba inocentemente y su vacío es evidente."

# game/day2.rpy:558
translate Paloslios day2_cold_route_menu_f53879b7:

    # "As you clink around the kitchenette looking for more food- a shadow falls across the floorboards."
    "Mientras recorres la cocina en busca de más comida, una sombra cae sobre el suelo."

# game/day2.rpy:560
translate Paloslios day2_cold_route_menu_a5310905:

    # "Jim leans against the doorframe. His voice is light, but his posture is anything but."
    "Jim se apoya contra el marco de la puerta. Su voz es ligera, pero su postura es todo lo contrario."

# game/day2.rpy:561
translate Paloslios day2_cold_route_menu_66c9fd96:

    # j "Looking for something?"
    j "¿Buscas algo?"

# game/day2.rpy:565
translate Paloslios day2_cold_route_menu_d7cd7720:

    # "His gaze flicks to the empty fridge, then back to you. A silent challenge."
    "Su mirada se dirige al refrigerador vacío y luego vuelve a ti. Un desafío silencioso."

# game/day2.rpy:570
translate Paloslios day2_cold_route_menu_01e75bca:

    # "Jim sighs, pushing off the door frame to rummage under the sink. He crouches, muscles flexing under his shirt as he drags out a dented, padlocked cooler."
    "Jim suspira, empujando el marco de la puerta para hurgar debajo del fregadero. Se agacha, los músculos se flexionan debajo de la camisa mientras saca una hielera abollada y cerrada con candado."

# game/day2.rpy:572
translate Paloslios day2_cold_route_menu_105ef7c8:

    # j "Fridge compressor's acting up. Had to move almost everything to the cellar last night."
    j "El compresor del frigorífico está funcionando mal. Anoche tuve que trasladar casi todo al sótano."

# game/day2.rpy:574
translate Paloslios day2_cold_route_menu_37cf6652:

    # j "There's some more stuff in the cooler, but it's for emergencies."
    j "Hay algunas cosas más en la hielera, pero es para emergencias."

# game/day2.rpy:581
translate Paloslios day2_cold_route_menu_bd007059:

    # "As you reach for the egg, Jim's hand closes over yours- just shy of painful."
    "Mientras alcanzas el huevo, la mano de Jim se cierra sobre la tuya, casi dolorosa."

# game/day2.rpy:582
translate Paloslios day2_cold_route_menu_c7a5aa3e:

    # j "Use the jar."
    j "Usa el frasco."

# game/day2.rpy:585
translate Paloslios day2_cold_route_menu_0e55c1cd:

    # "He nudges the unlabeled preserves toward you."
    "Él empuja las conservas sin etiqueta hacia ti."

# game/day2.rpy:587
translate Paloslios day2_cold_route_menu_1081db38:

    # "You turn your nose at the appearance, but you try to open it."
    "Giras la nariz ante la apariencia, pero intentas abrirla."

# game/day2.rpy:589
translate Paloslios day2_cold_route_menu_0bc433be:

    # "The lid is sealed too tight to open. Jim watches you struggle- your arms shaking before taking the jar from you."
    "La tapa está demasiado sellada para abrirla. Jim te observa luchar y te tiemblan los brazos antes de quitarte el frasco."

# game/day2.rpy:591
translate Paloslios day2_cold_route_menu_57ed8add:

    # "Jim pries it open with one twist and a loud pop. The preserves inside smell disgustingly sweet- like fermented fruit. And something else."
    "Jim lo abre con un giro y un fuerte pop. Las conservas del interior huelen asquerosamente dulces, como a fruta fermentada. Y algo más."

# game/day2.rpy:596
translate Paloslios day2_cold_route_menu_e7e6eaa3:

    # "Jim watches you intensely- for a moment before moving closer to you."
    "Jim te observa intensamente por un momento antes de acercarse a ti."

# game/day2.rpy:598
translate Paloslios day2_cold_route_menu_a20243fa:

    # "Jim guides you away from the fridge by your elbows- gentle but inescapable. His chest brushes your back."
    "Jim te aleja del refrigerador por los codos, gentil pero ineludible. Su pecho roza tu espalda."

# game/day2.rpy:601
translate Paloslios day2_cold_route_menu_66da942f:

    # "You notice some bread is visible in the high cabinet- but there's no step stool. Jim follows your gaze upward."
    "Notas que se ve algo de pan en el gabinete alto, pero no hay ningún taburete. Jim sigue tu mirada hacia arriba."

# game/day2.rpy:603
translate Paloslios day2_cold_route_menu_180deae0:

    # "Jim waits, arms crossed, to see if you'll climb the counters like a misbehaving child."
    "Jim espera, con los brazos cruzados, para ver si te subes a los mostradores como un niño que se porta mal."

# game/day2.rpy:608
translate Paloslios day2_cold_route_menu_8478dbd8:

    # "You consider it, but let Jim help you."
    "Lo consideras, pero deja que Jim te ayude."

# game/day2.rpy:610
translate Paloslios day2_cold_route_menu_ee3f1c49:

    # "Jim smiles slightly at your cooperation."
    "Jim sonríe levemente ante su cooperación."

# game/day2.rpy:616
translate Paloslios day2_cold_route_menu_8ff7f1e6:

    # "You strain for the bread, legs shaking to balance on the countertop."
    "Te esfuerzas por coger el pan y te tiemblan las piernas para mantener el equilibrio sobre la encimera."

# game/day2.rpy:617
translate Paloslios day2_cold_route_menu_57b9a1ec:

    # "Jim lets you teeter before catching your waist."
    "Jim te deja tambalear antes de atrapar tu cintura."

# game/day2.rpy:619
translate Paloslios day2_cold_route_menu_4c1bfe7b:

    # j "Stubborn, aren't you?"
    j "Testarudo, ¿no?"

# game/day2.rpy:621
translate Paloslios day2_cold_route_menu_9481eb57:

    # "He gives you a frustrated look before pushing you aside."
    "Él te mira frustrado antes de hacerte a un lado."

# game/day2.rpy:625
translate Paloslios day2_cold_route_menu_64de26ea:

    # "Jim reaches up there and grabs each of you a single slice."
    "Jim se acerca y agarra a cada uno de ustedes una porción."

# game/day2.rpy:626
translate Paloslios day2_cold_route_menu_f6eaac91:

    # "The kitchen feels smaller with Jim in it. His presence fills the space, shoulders nearly brushing the cabinets as he moves."
    "La cocina parece más pequeña con Jim dentro. Su presencia llena el espacio, sus hombros casi rozan los gabinetes mientras se mueve."

# game/day2.rpy:627
translate Paloslios day2_cold_route_menu_ccf5edac:

    # "He doesn't wait for your answer- just steps forward, his voice leaving no room for argument."
    "Él no espera tu respuesta, simplemente da un paso adelante, su voz no deja lugar a discusión."

# game/day2.rpy:629
translate Paloslios day2_cold_route_menu_ac0632a7:

    # j "Let me cook. I know my way around my own kitchen."
    j "Déjame cocinar. Conozco mi propia cocina."

# game/day2.rpy:636
translate Paloslios day2_cold_route_menu_a978a390:

    # pov "I can cook myself."
    pov "Puedo cocinar yo mismo."

# game/day2.rpy:638
translate Paloslios day2_cold_route_menu_786ca569:

    # "Jim's jaw tightens. He doesn't step back, forcing you to brush past him. His arm twitches like he might block you, but stops just short."
    "La mandíbula de Jim se aprieta. Él no da un paso atrás, lo que te obliga a pasar junto a él. Su brazo se mueve como si fuera a bloquearte, pero se detiene en seco."

# game/day2.rpy:639
translate Paloslios day2_cold_route_menu_91276d9c:

    # j "Fine."
    j "Bien."

# game/day2.rpy:640
translate Paloslios day2_cold_route_menu_776705aa:

    # "The way he says it makes your skin prickle- not quite mocking, not quite concerned. Just...waiting."
    "La forma en que lo dice hace que te pique la piel, ni del todo burlón ni del todo preocupado. Sólo...esperando."

# game/day2.rpy:641
translate Paloslios day2_cold_route_menu_fffb65e0:

    # "The space feels alien- pans just out of reach, utensils in odd drawers. The stove clicks stubbornly but doesn't ignite."
    "El espacio parece extraño: sartenes fuera de su alcance, utensilios en cajones extraños. La estufa hace ruido con obstinación pero no se enciende."

# game/day2.rpy:642
translate Paloslios day2_cold_route_menu_edd88413:

    # "You were able to get it to work yesterday..."
    "Pudiste hacerlo funcionar ayer..."

# game/day2.rpy:644
translate Paloslios day2_cold_route_menu_5818ef9d:

    # j "Flint's temperamental. Needs the right touch."
    j "Flint es temperamental. Necesita el toque adecuado."

# game/day2.rpy:645
translate Paloslios day2_cold_route_menu_a707d9eb:

    # "Jim's presence looms nearby the whole time, tracking all of your clumsy movements."
    "La presencia de Jim acecha cerca todo el tiempo, siguiendo todos tus movimientos torpes."

# game/day2.rpy:647
translate Paloslios day2_cold_route_menu_eafe7946:

    # "Eventually, he reaches around you to fix the stove. His chest presses against your back just a second too long."
    "Finalmente, se acerca a ti para arreglar la estufa. Su pecho presiona contra tu espalda sólo un segundo de más."

# game/day2.rpy:649
translate Paloslios day2_cold_route_menu_905b7cc2:

    # j "Should've let me do it. Now we're both hungry."
    j "Debería haberme dejado hacerlo. Ahora ambos tenemos hambre."

# game/day2.rpy:650
translate Paloslios day2_cold_route_menu_3b69f7bd:

    # "You ignore the shiver that runs through you and continue trying to cook without his help."
    "Ignoras el escalofrío que te recorre y continúas intentando cocinar sin su ayuda."

# game/day2.rpy:655
translate Paloslios day2_cold_route_menu_9d4ce616:

    # "Your meal is meager. Edible, but barely. Jim doesn't comment. He just takes a simple slice of toast with some butter."
    "Tu comida es escasa. Comestible, pero apenas. Jim no comenta. Simplemente toma una simple tostada con un poco de mantequilla."

# game/day2.rpy:657
translate Paloslios day2_cold_route_menu_e840aa1f:

    # j "Next time, let me help."
    j "La próxima vez déjame ayudarte."

# game/day2.rpy:659
translate Paloslios day2_cold_route_menu_5383eac8:

    # "Jim exhales- disappointed. And he heads back to his room."
    "Jim exhala decepcionado. Y regresa a su habitación."

# game/day2.rpy:664
translate Paloslios day2_cold_route_menu_702e52eb:

    # "You finish your meal and your hunger is satiated enough. For now."
    "Terminas tu comida y tu hambre está lo suficientemente saciada. Por ahora."

# game/day2.rpy:670
translate Paloslios day2_cold_route_menu_1adcad97:

    # "Jim's posture relaxes almost imperceptibly as he moves past you to the stove."
    "La postura de Jim se relaja casi imperceptiblemente cuando pasa junto a ti hacia la estufa."

# game/day2.rpy:671
translate Paloslios day2_cold_route_menu_8d468ab2:

    # j "Should've said you were hungry earlier. I'll handle it."
    j "Deberías haber dicho que tenías hambre antes. Yo me encargaré."

# game/day2.rpy:672
translate Paloslios day2_cold_route_menu_5deed782:

    # j "It's not too fancy...but it'll do."
    j "No es demasiado sofisticado... pero servirá."

# game/day2.rpy:675
translate Paloslios day2_cold_route_menu_780c494a:

    # "His hands work with practiced efficiency- too fast for you to track what spices he adds to the cast iron pan."
    "Sus manos trabajan con practicada eficiencia, demasiado rápido para que puedas rastrear qué especias agrega a la sartén de hierro fundido."

# game/day2.rpy:678
translate Paloslios day2_cold_route_menu_947e6396:

    # "The portion he serves you is...precise."
    "La porción que te sirve es... precisa."

# game/day2.rpy:681
translate Paloslios day2_cold_route_menu_e0ab44cf:

    # "But he made some pancakes with raw ingredients around. The jar of preserves sits open on the table for you."
    "Pero hizo unas tortitas con ingredientes crudos por ahí. El tarro de conservas está abierto sobre la mesa."

# game/day2.rpy:683
translate Paloslios day2_cold_route_menu_8eb704c2:

    # "Your stomach grumbles loudly at the sight and smell."
    "Su estómago gruñe fuertemente ante la vista y el olfato."

# game/day2.rpy:686
translate Paloslios day2_cold_route_menu_2b5e9973:

    # j "Good, you have an appetite. Go on and dig in."
    j "Bien, tienes apetito. Continúe y profundice."

# game/day2.rpy:687
translate Paloslios day2_cold_route_menu_f2b1e16e:

    # "He doesn't eat until you take the first bite. His gaze never leaves your face."
    "No come hasta que le das el primer bocado. Su mirada nunca abandona tu rostro."

# game/day2.rpy:688
translate Paloslios day2_cold_route_menu_d3abd100:

    # "Jim put the effort into making it, so now it's time to eat."
    "Jim se esforzó en hacerlo, así que ahora es el momento de comer."

# game/day2.rpy:691
translate Paloslios day2_cold_route_menu_a6a460f1:

    # "The pancakes are just sweet enough. The preserves taste like blackberries and something darker- iron? No, just your imagination."
    "Los panqueques son lo suficientemente dulces. Las conservas saben a moras y algo más oscuro: ¿hierro? No, sólo tu imaginación."

# game/day2.rpy:692
translate Paloslios day2_cold_route_menu_98852a87:

    # "The food is delicious but leaves you oddly drowsy."
    "La comida es deliciosa pero te deja extrañamente somnoliento."

# game/day2.rpy:694
translate Paloslios day2_cold_route_menu_8c9506b3:

    # "He smiles- watching you eat and noting how you feel from the look on your face."
    "Él sonríe, mirándote comer y notando cómo te sientes por la expresión de tu rostro."

# game/day2.rpy:695
translate Paloslios day2_cold_route_menu_dde99ea5:

    # j "Good food will make you sleepy, huh?"
    j "La buena comida te dará sueño, ¿eh?"

# game/day2.rpy:696
translate Paloslios day2_cold_route_menu_583d16a5:

    # "His voice is light, but his fingers quickly tap the table twice- like he's counting."
    "Su voz es ligera, pero sus dedos rápidamente golpean la mesa dos veces, como si estuviera contando."

# game/day2.rpy:700
translate Paloslios day2_cold_route_menu_8fe8266c:

    # "Both of you finish up quickly and Jim takes your plates to the sink."
    "Ambos terminan rápidamente y Jim lleva sus platos al fregadero."

# game/day2.rpy:704
translate Paloslios day2_cold_route_menu_8ed1e8e1:

    # "As he's washing up, Jim hums- the tune is unfamiliar, oddly rhythmic. You've never heard it before."
    "Mientras lava los platos, Jim tararea: la melodía no le resulta familiar y tiene un extraño ritmo. Nunca lo has oído antes."

# game/day2.rpy:705
translate Paloslios day2_cold_route_menu_79fbc26b:

    # "Almost like a lullaby. Or a chant."
    "Casi como una canción de cuna. O un canto."

# game/day2.rpy:709
translate Paloslios day2_cold_route_menu_7e46c3fd:

    # "When Jim notices your attention, he stops abruptly and turns away."
    "Cuando Jim nota tu atención, se detiene abruptamente y se da vuelta."

# game/day2.rpy:710
translate Paloslios day2_cold_route_menu_8b062115:

    # j "It's...just a song from my childhood."
    j "Es... sólo una canción de mi infancia."

# game/day2.rpy:716
translate Paloslios day2_cold_route_menu_fa3a138a:

    # "Jim finishes the dishes and gives you a short nod before heading back to his room again."
    "Jim termina los platos y asiente brevemente antes de regresar a su habitación nuevamente."

# game/day2.rpy:718
translate Paloslios day2_cold_route_menu_fe380a5f_1:

    # "What now?"
    "¿Y ahora qué?"

# game/day2.rpy:723
translate Paloslios day2_cold_route_menu_d7ea7a92:

    # "You reach into your pocket to retrieve your phone."
    "Mete la mano en el bolsillo para recuperar el teléfono."

# game/day2.rpy:724
translate Paloslios day2_cold_route_menu_6c7bee01:

    # "The wind howls outside as you stare at the blank screen- no signal, no bars, just the mocking 'No Service' blinking back at you."
    "El viento aúlla afuera mientras miras la pantalla en blanco: no hay señal, no hay barras, solo el burlón \"Sin servicio\" parpadeando hacia ti."

# game/day2.rpy:725
translate Paloslios day2_cold_route_menu_4dafffd5:

    # "The landline on the counter catches your eye. Worth a try."
    "Llama la atención el teléfono fijo del mostrador. Vale la pena intentarlo."

# game/day2.rpy:730
translate Paloslios day2_cold_route_menu_a58c6be6:

    # "You lift the receiver. Dead silence. No dial tone. Just the hollow echo of your breathing."
    "Levantas el auricular. Silencio de muerte. Sin tono de marcado. Sólo el eco hueco de tu respiración."

# game/day2.rpy:732
translate Paloslios day2_cold_route_menu_4c9d9f6f:

    # "A floorboard creaks behind you. You don't need to turn to know- Jim's there. Watching. Again."
    "Una tabla del suelo cruje detrás de ti. No necesitas girarte para saberlo: Jim está ahí. Mirando. De nuevo."

# game/day2.rpy:735
translate Paloslios day2_cold_route_menu_353910c9:

    # j "Storm took the lines down last night. Happens all the time out here."
    j "Storm derribó las líneas anoche. Pasa todo el tiempo aquí."

# game/day2.rpy:737
translate Paloslios day2_cold_route_menu_cc44f9e8:

    # "He reaches past you to jiggle the cord- his sleeve brushes your shoulder- as if that might help."
    "Pasa a tu lado para agitar el cordón (su manga roza tu hombro) como si eso pudiera ayudar."

# game/day2.rpy:739
translate Paloslios day2_cold_route_menu_cdcadaa6:

    # j "Yeah...I'm sorry. I'm sure you wanna let someone know what's happened."
    j "Sí... lo siento. Estoy seguro de que quieres contarle a alguien lo que pasó."

# game/day2.rpy:741
translate Paloslios day2_cold_route_menu_b5b2fabb:

    # j "But it'll be back up and runnin' soon."
    j "Pero pronto volverá a funcionar."

# game/day2.rpy:743
translate Paloslios day2_cold_route_menu_5edda503:

    # j "Who exactly were you tryin' to call?"
    j "¿A quién exactamente intentabas llamar?"

# game/day2.rpy:744
translate Paloslios day2_cold_route_menu_9be1344d:

    # "Jim is leaning against the doorframe, arms crossed. His expression is neutral, but his eyes track the way your fingers clutch the receiver."
    "Jim está apoyado contra el marco de la puerta, con los brazos cruzados. Su expresión es neutral, pero sus ojos siguen la forma en que tus dedos agarran el auricular."

# game/day2.rpy:746
translate Paloslios day2_cold_route_menu_299ab6e3:

    # j "It's not like anyone can come or go right now anyway."
    j "De todos modos, no es como si alguien pudiera entrar o salir ahora mismo."

# game/day2.rpy:748
translate Paloslios day2_cold_route_menu_25cbb5d0:

    # "His tone is icy and his eyes narrow on you. Tracking you- knowing how stubborn you've been."
    "Su tono es gélido y sus ojos se estrechan hacia ti. Rastreándote, sabiendo lo terco que has sido."

# game/day2.rpy:749
translate Paloslios day2_cold_route_menu_cb35b2cf:

    # "Jim's patience is running thin."
    "La paciencia de Jim se está agotando."

# game/day2.rpy:754
translate Paloslios day2_cold_route_menu_af32ff95:

    # "Jim shrugs, stepping closer to examine the phone himself. His shoulder brushes yours- too close, too intentional."
    "Jim se encoge de hombros y se acerca para examinar el teléfono él mismo. Su hombro roza el tuyo, demasiado cerca, demasiado intencional."

# game/day2.rpy:755
translate Paloslios day2_cold_route_menu_b6b37edb:

    # j "I'm not sure..."
    j "No estoy seguro..."

# game/day2.rpy:756
translate Paloslios day2_cold_route_menu_454192a2:

    # "He taps the receiver gently back into its cradle."
    "Golpea suavemente el auricular para volver a colocarlo en su soporte."

# game/day2.rpy:758
translate Paloslios day2_cold_route_menu_91cbc577:

    # j "No one comes up here much in winter."
    j "Nadie viene mucho aquí en invierno."

# game/day2.rpy:764
translate Paloslios day2_cold_route_menu_c78bd219:

    # "Jim's lips twitch. He reaches past you to jiggle the phone cord, his chest nearly pressed against your back."
    "Los labios de Jim se contraen. Pasa a tu lado para mover el cable del teléfono, su pecho casi presiona contra tu espalda."

# game/day2.rpy:766
translate Paloslios day2_cold_route_menu_1a050095:

    # j "Why would I lie? You're safe here."
    j "¿Por qué mentiría? Estás a salvo aquí."

# game/day2.rpy:767
translate Paloslios day2_cold_route_menu_7a602a16:

    # "The word lingers, heavy and wrong."
    "La palabra persiste, pesada y equivocada."

# game/day2.rpy:774
translate Paloslios day2_cold_route_menu_60376c7a:

    # "Jim doesn't move. His hand snaps out to grip your wrist- not enough to hurt, just enough to stop you."
    "Jim no se mueve. Su mano se extiende para agarrar tu muñeca, no lo suficiente como para hacerte daño, sólo lo suficiente para detenerte."

# game/day2.rpy:775
translate Paloslios day2_cold_route_menu_c031b2ad:

    # j "Where exactly are you going to go?"
    j "¿Adónde vas a ir exactamente?"

# game/day2.rpy:777
translate Paloslios day2_cold_route_menu_4c68a7c0:

    # "His thumb brushes your pulse point."
    "Su pulgar roza tu punto de pulso."

# game/day2.rpy:779
translate Paloslios day2_cold_route_menu_fe35a5a1:

    # j "Road's buried. And the wolves...they're hungry this time of year."
    j "El camino está enterrado. Y los lobos... tienen hambre en esta época del año."

# game/day2.rpy:781
translate Paloslios day2_cold_route_menu_d2c55a3e:

    # "The silence stretches too long. His gaze darkens, the polite mask slipping just enough for you to see the ice beneath."
    "El silencio se prolonga demasiado. Su mirada se oscurece, la cortés máscara se desliza lo suficiente para que puedas ver el hielo debajo."

# game/day2.rpy:783
translate Paloslios day2_cold_route_menu_a94f4743:

    # j "Think you should go to your room for a while."
    j "Creo que deberías ir a tu habitación un rato."

# game/day2.rpy:784
translate Paloslios day2_cold_route_menu_0f2cbfec:

    # "He doesn't move from the doorway. The unspoken command lingers in the air between you- this isn't a suggestion."
    "No se mueve del umbral. La orden tácita permanece en el aire entre ustedes; esto no es una sugerencia."

# game/day2.rpy:785
translate Paloslios day2_cold_route_menu_d55a0f2f:

    # "You hesitate, weighing defiance."
    "Dudas, sopesando el desafío."

# game/day2.rpy:786
translate Paloslios day2_cold_route_menu_f2dff86b:

    # "But the facts are undeniable- his broad frame blocks the only exit, the storm shrieks outside, a reminder of the wilderness's indifference..."
    "Pero los hechos son innegables: su amplio cuerpo bloquea la única salida, la tormenta ruge afuera, un recordatorio de la indiferencia de la naturaleza..."

# game/day2.rpy:788
translate Paloslios day2_cold_route_menu_49af2ee8:

    # "And that look in his eyes...patient, but not endlessly so..."
    "Y esa mirada en sus ojos... paciente, pero no infinitamente..."

# game/day2.rpy:789
translate Paloslios day2_cold_route_menu_f1883416:

    # "Your feet move before you decide to obey."
    "Tus pies se mueven antes de que decidas obedecer."

# game/day2.rpy:791
translate Paloslios day2_cold_route_menu_c96d3490:

    # "Jim follows just too close behind as you trudge down to your room."
    "Jim te sigue muy de cerca mientras caminas penosamente hacia tu habitación."

# game/day2.rpy:792
translate Paloslios day2_cold_route_menu_1dbcc7f4:

    # j "Rest up. I'll get you for supper later."
    j "Descansa. Te invitaré a cenar más tarde."

# game/day2.rpy:796
translate Paloslios day2_cold_route_menu_7ceacdbf:

    # "And with that, your bedroom door creaks shut behind you."
    "Y con eso, la puerta de tu dormitorio se cierra con un chirrido detrás de ti."

# game/day2.rpy:799
translate Paloslios day2_cold_route_menu_3c8f6f7b:

    # "You figure you'll just go back and rest in your room for a while."
    "Crees que volverás y descansarás un rato en tu habitación."

# game/day2.rpy:803
translate Paloslios day2_cold_route_menu_47865f98:

    # "The bedroom door clicks shut behind you."
    "La puerta del dormitorio se cierra detrás de ti."

# game/day2.rpy:836
translate Paloslios day2_afternoon_nap_c7dfb080:

    # "The sound is soft, final. You sit on the edge of the bed, the weight of the day pressing into your shoulders like hands."
    "El sonido es suave, definitivo. Te sientas en el borde de la cama y el peso del día presiona tus hombros como si fueran manos."

# game/day2.rpy:837
translate Paloslios day2_afternoon_nap_c56af530:

    # "You stare out the frost-veined glass. The storm still rages, snow piling in drifts against the pane. Your breath fogs the cold surface."
    "Miras por el cristal veteado de escarcha. La tormenta todavía arrecia y la nieve se acumula en montones contra el cristal. Tu aliento empaña la fría superficie."

# game/day2.rpy:840
translate Paloslios day2_afternoon_nap_05cecb7f:

    # "You scoff as you peer out of your cage."
    "Te burlas mientras miras fuera de tu jaula."

# game/day2.rpy:841
translate Paloslios day2_afternoon_nap_56d0cb97:

    # "You consider writing a plea, a curse, a name. But who would see it? The trees? The wolves?"
    "Consideras escribir una súplica, una maldición, un nombre. ¿Pero quién lo vería? ¿Los árboles? ¿Los lobos?"

# game/day2.rpy:842
translate Paloslios day2_afternoon_nap_6aaf7259:

    # "A single finger scrapes across the frost, etching half a word- before letters sweat and blur almost immediately as if the house itself rejects your defiance."
    "Un solo dedo raspa la escarcha, grabando media palabra, antes de que las letras suden y se desdibujen casi de inmediato, como si la casa misma rechazara su desafío."

# game/day2.rpy:843
translate Paloslios day2_afternoon_nap_4ca8909a:

    # "Jim's presence was an inescapable shadow over you."
    "La presencia de Jim era una sombra ineludible sobre ti."

# game/day2.rpy:845
translate Paloslios day2_afternoon_nap_fafd6773:

    # "Your breath evens out, fogging the glass in rhythmic pulses."
    "Tu respiración se estabiliza y empaña el cristal en pulsaciones rítmicas."

# game/day2.rpy:846
translate Paloslios day2_afternoon_nap_9f3cf79f:

    # "Without realizing it, you trace the same looping pattern Jim uses to stir his coffee into the glass."
    "Sin darte cuenta, trazas el mismo patrón circular que Jim usa para revolver el café en el vaso."

# game/day2.rpy:847
translate Paloslios day2_afternoon_nap_0c43d403:

    # "You were feeling more accepting of your situation. Or maybe resigned is a better word."
    "Te sentías más tolerante con tu situación. O tal vez resignado sea una palabra mejor."

# game/day2.rpy:848
translate Paloslios day2_afternoon_nap_0a873fdd:

    # "The snow no longer looks threatening- just inevitable, like the turn of seasons."
    "La nieve ya no parece amenazadora: simplemente inevitable, como el cambio de estaciones."

# game/day2.rpy:854
translate Paloslios day2_afternoon_nap_5160cca1:

    # "The wind howls outside as you lie stiffly beneath the quilt, staring at the ceiling."
    "El viento aúlla afuera mientras tú te acuestas rígidamente debajo de la colcha, mirando al techo."

# game/day2.rpy:855
translate Paloslios day2_afternoon_nap_a8632c40:

    # "You reflect on what you've seen today- the first day staying in the cabin with Jim."
    "Reflexionas sobre lo que has visto hoy: el primer día que estuviste en la cabaña con Jim."

# game/day2.rpy:857
translate Paloslios day2_afternoon_nap_450755fc:

    # "Memory flickers-"
    "La memoria parpadea"

# game/day2.rpy:858
translate Paloslios day2_afternoon_nap_4fb511aa:

    # "The rough drag of aged leather under your fingertips, the dry crack of its spine splitting open like a secret."
    "El áspero arrastre del cuero envejecido bajo las yemas de los dedos, el seco crujido de su lomo abriéndose como un secreto."

# game/day2.rpy:859
translate Paloslios day2_afternoon_nap_0ba02ac2:

    # "The sketches and scribbled writings swim behind your eyelids."
    "Los bocetos y los escritos garabateados nadan detrás de tus párpados."

# game/day2.rpy:860
translate Paloslios day2_afternoon_nap_56433d37:

    # "The contents of the journal sent a chill through you. Your brows furrow as you try to make out what it all means."
    "El contenido del diario te provocó un escalofrío. Tus cejas se fruncen mientras intentas entender lo que significa todo esto."

# game/day2.rpy:861
translate Paloslios day2_afternoon_nap_7e4bd5d2:

    # "'They're coming. The storm will bring them.'"
    "'Ya vienen. La tormenta los traerá."

# game/day2.rpy:862
translate Paloslios day2_afternoon_nap_798deea2:

    # "You turn onto your side, pulse quickening at the memory."
    "Te pones de lado y el pulso se acelera ante el recuerdo."

# game/day2.rpy:863
translate Paloslios day2_afternoon_nap_e237d514:

    # "Who was he writing about? And why does the date on the last entry match this week?"
    "¿Sobre quién estaba escribiendo? ¿Y por qué la fecha de la última entrada coincide con esta semana?"

# game/day2.rpy:865
translate Paloslios day2_afternoon_nap_ce3d18aa:

    # "Your palm tingles where the petals touched you- a phantom chill that won't fade."
    "Tu palma hormiguea donde los pétalos te tocaron: un escalofrío fantasma que no desaparecerá."

# game/day2.rpy:866
translate Paloslios day2_afternoon_nap_04770374:

    # "You press your hand to the mattress, but the cold lingers like a brand."
    "Presionas tu mano contra el colchón, pero el frío permanece como una marca."

# game/day2.rpy:867
translate Paloslios day2_afternoon_nap_116f00f1:

    # "That flower was- too cold, too perfect."
    "Esa flor era... demasiado fría, demasiado perfecta."

# game/day2.rpy:869
translate Paloslios day2_afternoon_nap_e9afb89d:

    # "Jim's voice, low and satisfied, replays in your skull."
    "La voz de Jim, baja y satisfecha, se repite en tu cráneo."

# game/day2.rpy:870
translate Paloslios day2_afternoon_nap_f90b1b4c:

    # "The flower rests heavy in your pocket, its unnatural chill seeping through the fabric."
    "La flor reposa pesadamente en tu bolsillo, su frío antinatural se filtra a través de la tela."

# game/day2.rpy:871
translate Paloslios day2_afternoon_nap_ecc70a76:

    # "Perhaps it's just a chilly draft."
    "Quizás sea sólo una corriente fría."

# game/day2.rpy:873
translate Paloslios day2_afternoon_nap_4677e1ff:

    # "And Jim's reaction was playing on a loop- dismissive, even when his breath stilled."
    "Y la reacción de Jim fue continua: desdeñosa, incluso cuando su respiración se detuvo."

# game/day2.rpy:874
translate Paloslios day2_afternoon_nap_92dd0889:

    # "You clench your fist. The scent of frost and iron still clings to your skin."
    "Aprietas el puño. El olor a escarcha y hierro todavía se pega a tu piel."

# game/day2.rpy:876
translate Paloslios day2_afternoon_nap_96ce0035:

    # "The fridge's hollow interior glares in your memory."
    "El interior hueco del frigorífico brilla en tu memoria."

# game/day2.rpy:877
translate Paloslios day2_afternoon_nap_1194b2ac:

    # "Is that really what happened?"
    "¿Es eso realmente lo que pasó?"

# game/day2.rpy:878
translate Paloslios day2_afternoon_nap_4cdfd823:

    # "The fridge was working fine yesterday. At least, you didn't notice anything wrong with it."
    "Ayer la nevera funcionaba bien. Al menos no notaste nada malo en ello."

# game/day2.rpy:879
translate Paloslios day2_afternoon_nap_0b048aac:

    # "And the way he watched as you struggled with the empty shelves- like an animal playing with its food."
    "Y la forma en que te observaba mientras luchabas con los estantes vacíos, como un animal jugando con su comida."

# game/day2.rpy:880
translate Paloslios day2_afternoon_nap_e008532b:

    # "Your stomach growls. The hunger feels intentional now."
    "Tu estómago gruñe. El hambre parece intencionada ahora."

# game/day2.rpy:882
translate Paloslios day2_afternoon_nap_fed5937d:

    # "You could still picture the way the puzzle pieces had fit together under Jim's sure hands."
    "Todavía podías imaginar la forma en que las piezas del rompecabezas habían encajado bajo las manos seguras de Jim."

# game/day2.rpy:883
translate Paloslios day2_afternoon_nap_9af8699e:

    # "The shadow of the cabin, the lurking wolf with its golden eyes, the figure at the tree line..."
    "La sombra de la cabaña, el lobo al acecho con sus ojos dorados, la figura en la línea de árboles..."

# game/day2.rpy:884
translate Paloslios day2_afternoon_nap_d3db7490:

    # "But the piece it held had been missing."
    "Pero faltaba la pieza que contenía."

# game/day2.rpy:885
translate Paloslios day2_afternoon_nap_53517b57:

    # "Now, in the quiet of your room, the memory nagged at you."
    "Ahora, en el silencio de tu habitación, el recuerdo te atormentaba."

# game/day2.rpy:887
translate Paloslios day2_afternoon_nap_5bc277ad:

    # "The landline's dead static still rings in your ears."
    "La estática muerta del teléfono fijo todavía resuena en tus oídos."

# game/day2.rpy:888
translate Paloslios day2_afternoon_nap_c58bfc9d:

    # "You roll over and dig your phone from your pocket- No Service mocks you in glowing letters."
    "Te das la vuelta y sacas el teléfono del bolsillo. No Service se burla de ti con letras brillantes."

# game/day2.rpy:889
translate Paloslios day2_afternoon_nap_870e6009:

    # "You toss in bed in frustration, your phone a heavyweight in your pocket. You might as well put it in your luggage for now."
    "Te revuelves en la cama con frustración, tu teléfono es un peso pesado en tu bolsillo. Por ahora también puedes guardarlo en tu equipaje."

# game/day2.rpy:890
translate Paloslios day2_afternoon_nap_c294d583:

    # "The storm was roaring...what bad luck for the landline to go down."
    "La tormenta rugía... que mala suerte que se cortara el teléfono fijo."

# game/day2.rpy:892
translate Paloslios day2_afternoon_nap_8342ec18:

    # "He's been a surprisingly attentive host, in his own way. The breakfast was hearty."
    "Ha sido un anfitrión sorprendentemente atento, a su manera. El desayuno fue abundante."

# game/day2.rpy:893
translate Paloslios day2_afternoon_nap_330d4c1a:

    # "He remembers the little things. The way you take your [drink]."
    "Recuerda las pequeñas cosas. La forma en que tomas tu [drink]."

# game/day2.rpy:894
translate Paloslios day2_afternoon_nap_55c4b68c:

    # "There's something almost...comforting in the way he moves, like he's memorized the shape of this solitude and simply let you step inside it."
    "Hay algo casi... reconfortante en la forma en que se mueve, como si hubiera memorizado la forma de esta soledad y simplemente te hubiera dejado entrar en ella."

# game/day2.rpy:895
translate Paloslios day2_afternoon_nap_bd3b220a:

    # "Jim's still careful with his words and still watches you a little too closely, but there's no denying it- you've gotten closer today."
    "Jim todavía es cuidadoso con sus palabras y todavía te observa demasiado de cerca, pero no se puede negar: hoy te has acercado más."

# game/day2.rpy:897
translate Paloslios day2_afternoon_nap_fa1de716:

    # "You close your eyes and try to rest, tossing fitfully."
    "Cierras los ojos y tratas de descansar, dando vueltas a intervalos."

# game/day2.rpy:898
translate Paloslios day2_afternoon_nap_ef150673:

    # "Something unsettled you as you tried to sleep, if at all. It was hard to tell the time with the snowstorm roaring."
    "Algo te inquietó mientras intentabas dormir, en todo caso. Era difícil saber la hora con la tormenta de nieve rugiendo."

# game/day2.rpy:902
translate Paloslios day2_afternoon_nap_f6630fbc:

    # "The shadows stretch across your room and you begin to wonder if it's evening time yet."
    "Las sombras se extienden por tu habitación y empiezas a preguntarte si ya es de noche."

# game/day2.rpy:903
translate Paloslios day2_afternoon_nap_a9fc9f93:

    # "Jim hasn't come to get you, but the hunger in your stomach pulls you out of bed."
    "Jim no ha venido a buscarte, pero el hambre en tu estómago te saca de la cama."

# game/day2.rpy:908
translate Paloslios day2_afternoon_nap_1c1327f7:

    # "When you get up, you notice the door is slightly ajar."
    "Cuando te levantas, notas que la puerta está entreabierta."

# game/day2.rpy:909
translate Paloslios day2_afternoon_nap_b3ad9292:

    # "You could've sworn that you had closed it..."
    "Podrías jurar que lo habías cerrado..."

# game/day2.rpy:943
translate Paloslios day2_warm_route_f0a2844b:

    # j "You must be hungry. I'll make you some food to go with your drink."
    j "Debes tener hambre. Te prepararé algo de comida para acompañar tu bebida."

# game/day2.rpy:945
translate Paloslios day2_warm_route_d2a86ff0:

    # "He crouches down and pulls out a cooler from under the sink."
    "Se agacha y saca una hielera de debajo del fregadero."

# game/day2.rpy:947
translate Paloslios day2_warm_route_4b28914e:

    # "You think you hear the click of a lock, but you can't see past Jim's form."
    "Crees que escuchas el clic de una cerradura, pero no puedes ver más allá de la forma de Jim."

# game/day2.rpy:948
translate Paloslios day2_warm_route_0ddac2b4:

    # "He places some ingredients on the counter: flour, potatoes, onion, eggs, and toast."
    "Coloca algunos ingredientes sobre la encimera: harina, patatas, cebolla, huevos y tostadas."

# game/day2.rpy:950
translate Paloslios day2_warm_route_5deed782:

    # j "It's not too fancy...but it'll do."
    j "No es demasiado sofisticado... pero servirá."

# game/day2.rpy:952
translate Paloslios day2_warm_route_6ef3ccaa:

    # "Jim moves with quiet efficiency at the stove as he layers ingredients into a cast-iron pan."
    "Jim se mueve con silenciosa eficiencia en la estufa mientras coloca los ingredientes en una sartén de hierro fundido."

# game/day2.rpy:958
translate Paloslios day2_warm_route_d7f6593f:

    # "You step beside him, reaching for a knife to chop vegetables. Jim's hand catches yours- not to stop you, just to guide your grip."
    "Te pones a su lado y tomas un cuchillo para picar verduras. La mano de Jim atrapa la tuya, no para detenerte, sólo para guiar tu agarre."

# game/day2.rpy:960
translate Paloslios day2_warm_route_e80692ea:

    # j "Knife's sharper than it looks. Here-"
    j "El cuchillo está más afilado de lo que parece. Aquí-"

# game/day2.rpy:961
translate Paloslios day2_warm_route_0ce6799c:

    # "He adjusts your fingers, his palm warm against yours."
    "Él ajusta tus dedos, su palma cálida contra la tuya."

# game/day2.rpy:963
translate Paloslios day2_warm_route_afa5d4cf:

    # j "Smaller cuts. They'll cook even."
    j "Cortes más pequeños. Se cocinarán parejos."

# game/day2.rpy:966
translate Paloslios day2_warm_route_256e1b07:

    # "You work in comfortable silence, shoulders brushing occasionally."
    "Trabajas en un cómodo silencio, rozándote los hombros de vez en cuando."

# game/day2.rpy:969
translate Paloslios day2_warm_route_ea8dfca7:

    # "When the meal is ready, he plates it carefully, nudging the best portions toward your side."
    "Cuando la comida está lista, la sirve en el plato con cuidado, empujando las mejores porciones hacia tu lado."

# game/day2.rpy:971
translate Paloslios day2_warm_route_b55e832b:

    # "His boot knocks lightly against yours under the table. A tiny, grounding touch."
    "Su bota golpea ligeramente la tuya debajo de la mesa. Un pequeño toque de conexión a tierra."

# game/day2.rpy:972
translate Paloslios day2_warm_route_f181b307:

    # j "We make a good team."
    j "Hacemos un buen equipo."

# game/day2.rpy:978
translate Paloslios day2_warm_route_0a3ac31a:

    # "You lean against the counter, arms crossed, observing. Jim doesn't rush- every motion is deliberate, practiced."
    "Te apoyas en el mostrador, con los brazos cruzados, observando. Jim no se apresura: cada movimiento es deliberado y practicado."

# game/day2.rpy:981
translate Paloslios day2_warm_route_780c494a:

    # "His hands work with practiced efficiency- too fast for you to track what spices he adds to the cast iron pan."
    "Sus manos trabajan con practicada eficiencia, demasiado rápido para que puedas rastrear qué especias agrega a la sartén de hierro fundido."

# game/day2.rpy:984
translate Paloslios day2_warm_route_d8e73724:

    # "He cracks eggs one-handed, whisks them smooth, and hums under his breath when he thinks you're not listening."
    "Rompe huevos con una mano, los bate suavemente y tararea en voz baja cuando cree que no estás escuchando."

# game/day2.rpy:986
translate Paloslios day2_warm_route_7994482a:

    # "At one point, he glances over, catching your stare."
    "En un momento, él mira hacia arriba y capta tu mirada."

# game/day2.rpy:988
translate Paloslios day2_warm_route_e80f13de:

    # j "See something you like?"
    j "¿Ves algo que te gusta?"

# game/day2.rpy:989
translate Paloslios day2_warm_route_a5c530e5:

    # "His voice is teasing, but his ears are faintly pink."
    "Su voz es burlona, pero sus orejas están ligeramente rosadas."

# game/day2.rpy:991
translate Paloslios day2_warm_route_7473d2e0:

    # "He turns back to the stove, but not before you catch the smile he can't suppress."
    "Se vuelve hacia la estufa, pero no antes de captar la sonrisa que no puede reprimir."

# game/day2.rpy:994
translate Paloslios day2_warm_route_3502cffa:

    # "When he serves you, he leans in close as he sets the plate down."
    "Cuando te sirve, se acerca mientras deja el plato."

# game/day2.rpy:995
translate Paloslios day2_warm_route_6d794128:

    # j "Hope you like it."
    j "Espero que te guste."

# game/day2.rpy:998
translate Paloslios day2_warm_route_0f749cf5:

    # "The food is simple but perfect- fluffy eggs, crispy potatoes, pancakes, toast slathered in some kind of jam."
    "La comida es sencilla pero perfecta: huevos esponjosos, patatas crujientes, tortitas y tostadas untadas con una especie de mermelada."

# game/day2.rpy:1001
translate Paloslios day2_warm_route_6154730d:

    # "Jim left the jar of preserves open on the table for you, wafting a sweet scent to you- in case you wanted more."
    "Jim dejó el frasco de conservas abierto sobre la mesa para ti, despidiendo un dulce aroma hacia ti, en caso de que quisieras más."

# game/day2.rpy:1002
translate Paloslios day2_warm_route_8eb704c2:

    # "Your stomach grumbles loudly at the sight and smell."
    "Su estómago gruñe fuertemente ante la vista y el olfato."

# game/day2.rpy:1004
translate Paloslios day2_warm_route_2b5e9973:

    # j "Good, you have an appetite. Go on and dig in."
    j "Bien, tienes apetito. Continúe y profundice."

# game/day2.rpy:1005
translate Paloslios day2_warm_route_fa2446e0:

    # "He doesn't eat until you do. His gaze never leaves your face."
    "Él no come hasta que tú lo hagas. Su mirada nunca abandona tu rostro."

# game/day2.rpy:1008
translate Paloslios day2_warm_route_1a4e6dc2:

    # "Jim watches you take the first bite, his fingers drumming the table until you nod approval."
    "Jim te observa dar el primer bocado, sus dedos tamborilean en la mesa hasta que asientes con aprobación."

# game/day2.rpy:1009
translate Paloslios day2_warm_route_a6a460f1:

    # "The pancakes are just sweet enough. The preserves taste like blackberries and something darker- iron? No, just your imagination."
    "Los panqueques son lo suficientemente dulces. Las conservas saben a moras y algo más oscuro: ¿hierro? No, sólo tu imaginación."

# game/day2.rpy:1010
translate Paloslios day2_warm_route_98852a87:

    # "The food is delicious but leaves you oddly drowsy."
    "La comida es deliciosa pero te deja extrañamente somnoliento."

# game/day2.rpy:1011
translate Paloslios day2_warm_route_8c9506b3:

    # "He smiles- watching you eat and noting how you feel from the look on your face."
    "Él sonríe, mirándote comer y notando cómo te sientes por la expresión de tu rostro."

# game/day2.rpy:1012
translate Paloslios day2_warm_route_dde99ea5:

    # j "Good food will make you sleepy, huh?"
    j "La buena comida te dará sueño, ¿eh?"

# game/day2.rpy:1013
translate Paloslios day2_warm_route_583d16a5:

    # "His voice is light, but his fingers quickly tap the table twice- like he's counting."
    "Su voz es ligera, pero sus dedos rápidamente golpean la mesa dos veces, como si estuviera contando."

# game/day2.rpy:1016
translate Paloslios day2_warm_route_c34d07bf:

    # "Halfway through, he pushes his mug toward you."
    "A mitad de camino, empuja su taza hacia ti."

# game/day2.rpy:1017
translate Paloslios day2_warm_route_9941a19d:

    # j "Try this."
    j "Prueba esto."

# game/day2.rpy:1019
translate Paloslios day2_warm_route_30fac78d:

    # "Before you realize it, you take a sip of his spiced tea and it's just sweet enough."
    "Antes de que te des cuenta, tomas un sorbo de su té especiado y es lo suficientemente dulce."

# game/day2.rpy:1020
translate Paloslios day2_warm_route_7c0bae78:

    # "When you hand it back, his thumb brushes the place your lips touched."
    "Cuando se lo devuelves, su pulgar roza el lugar donde tocaron tus labios."

# game/day2.rpy:1025
translate Paloslios day2_warm_route_8fe8266c:

    # "Both of you finish up quickly and Jim takes your plates to the sink."
    "Ambos terminan rápidamente y Jim lleva sus platos al fregadero."

# game/day2.rpy:1026
translate Paloslios day2_warm_route_8ed1e8e1:

    # "As he's washing up, Jim hums- the tune is unfamiliar, oddly rhythmic. You've never heard it before."
    "Mientras lava los platos, Jim tararea: la melodía no le resulta familiar y tiene un extraño ritmo. Nunca lo has oído antes."

# game/day2.rpy:1027
translate Paloslios day2_warm_route_79fbc26b:

    # "Almost like a lullaby. Or a chant."
    "Casi como una canción de cuna. O un canto."

# game/day2.rpy:1031
translate Paloslios day2_warm_route_7e46c3fd:

    # "When Jim notices your attention, he stops abruptly and turns away."
    "Cuando Jim nota tu atención, se detiene abruptamente y se da vuelta."

# game/day2.rpy:1032
translate Paloslios day2_warm_route_8b062115:

    # j "It's...just a song from my childhood."
    j "Es... sólo una canción de mi infancia."

# game/day2.rpy:1034
translate Paloslios day2_warm_route_5b9ff09d:

    # "Jim pauses at the sink, looking out the window. The storm still rages, but he has a serene look on his face."
    "Jim se detiene en el fregadero y mira por la ventana. La tormenta todavía arrecia, pero él tiene una expresión serena en su rostro."

# game/day2.rpy:1035
translate Paloslios day2_warm_route_ebc454d6:

    # j "{size=*0.75}Could get used to this.{/size}"
    j "{size=*0.75}Podría acostumbrarme a esto.{/size}"

# game/day2.rpy:1042
translate Paloslios day2_warm_route_1364a46a:

    # "The fireplace crackles as Jim moves to kneel by the hearth, rearranging logs with unnecessary focus."
    "La chimenea crepita cuando Jim se arrodilla junto al hogar, reorganizando los leños con una concentración innecesaria."

# game/day2.rpy:1043
translate Paloslios day2_warm_route_3424c52a:

    # "His sleeves are rolled up slightly as he works- pale scars peek beneath the fabric."
    "Sus mangas están ligeramente arremangadas mientras trabaja; cicatrices pálidas se asoman debajo de la tela."

# game/day2.rpy:1045
translate Paloslios day2_warm_route_f8efcc52:

    # "When he notices you watching, he smiles, but his fingers twitch like he's counting something under his breath."
    "Cuando se da cuenta de que estás mirando, sonríe, pero sus dedos se mueven como si estuviera contando algo en voz baja."

# game/day2.rpy:1046
translate Paloslios day2_warm_route_0dff8409:

    # j "Not much to do indoors, I'm afraid. Never really had guests before."
    j "Me temo que no hay mucho que hacer en el interior. Realmente nunca antes había tenido invitados."

# game/day2.rpy:1048
translate Paloslios day2_warm_route_39439a9f:

    # j "Just...me and the quiet."
    j "Sólo... yo y el silencio."

# game/day2.rpy:1049
translate Paloslios day2_warm_route_8b3956e0:

    # "The firelight catches the edges of the wolf carvings on the mantel."
    "La luz del fuego ilumina los bordes de los lobos tallados en la repisa de la chimenea."

# game/day2.rpy:1051
translate Paloslios day2_warm_route_b4ae82a8:

    # j "I've got books. And a puzzle. If you'd like..."
    j "Tengo libros. Y un rompecabezas. Si quieres..."

# game/day2.rpy:1053
translate Paloslios day2_warm_route_91b3da79:

    # j "Could make do?"
    j "¿Podría arreglárselas?"

# game/day2.rpy:1061
translate Paloslios day2_warm_activities_29ff76ca:

    # "Jim produces a dusty puzzle box from a cabinet and directs you to the table."
    "Jim saca una caja de rompecabezas polvorienta de un gabinete y te dirige a la mesa."

# game/day2.rpy:1064
translate Paloslios day2_warm_activities_4170ed66:

    # "The pieces are worn, the image on the box faded- a snow-laden forest, the trees too familiar, the shadows between them too deep."
    "Las piezas están gastadas, la imagen de la caja se ha descolorido: un bosque cargado de nieve, los árboles demasiado familiares, las sombras entre ellos demasiado profundas."

# game/day2.rpy:1066
translate Paloslios day2_warm_activities_f051c1dc:

    # j "Found this in the cellar. Might be missing a few pieces."
    j "Encontré esto en el sótano. Puede que le falten algunas piezas."

# game/day2.rpy:1069
translate Paloslios day2_warm_activities_368d3061:

    # "He spreads the pieces across the table and then settles beside you. Close, but not quite touching."
    "Él extiende las piezas sobre la mesa y luego se sienta a tu lado. Cerca, pero no del todo tocándose."

# game/day2.rpy:1071
translate Paloslios day2_warm_activities_8d8a6512:

    # "The puzzle is old with some edges frayed, others darkened with age or something else."
    "El rompecabezas es viejo con algunos bordes deshilachados, otros oscurecidos por el tiempo o algo más."

# game/day2.rpy:1073
translate Paloslios day2_warm_activities_6a6a2875:

    # "At first, it's easy. Border pieces first, then the cabin emerges- crooked chimney, claw marks on the door. "
    "Al principio es fácil. Primero los trozos del borde, luego emerge la cabaña: chimenea torcida, marcas de garras en la puerta. "

# game/day2.rpy:1074
translate Paloslios day2_warm_activities_5d178140:

    # "As fire crackles, the puzzle takes shape- a cabin, a wolf, a figure standing at the tree line."
    "Mientras el fuego crepita, el rompecabezas toma forma: una cabaña, un lobo, una figura parada junto a la línea de árboles."

# game/day2.rpy:1076
translate Paloslios day2_warm_activities_d1381721:

    # "Jim's fingers move with surprising precision, slotting pieces into place before you even find their match."
    "Los dedos de Jim se mueven con sorprendente precisión, colocando piezas en su lugar incluso antes de que encuentres su coincidencia."

# game/day2.rpy:1077
translate Paloslios day2_warm_activities_d9a9b450:

    # "He doesn't look at the box. He doesn't need to."
    "No mira la caja. No es necesario."

# game/day2.rpy:1079
translate Paloslios day2_warm_activities_ee040123:

    # j "Funny how things fit together when you know where they belong..."
    j "Es curioso cómo las cosas encajan cuando sabes a dónde pertenecen..."

# game/day2.rpy:1082
translate Paloslios day2_warm_activities_c588b180:

    # "At one point, his knee brushes yours. He doesn't pull away. It's warm, deliberate."
    "En un momento, su rodilla roza la tuya. Él no se aleja. Es cálido, deliberado."

# game/day2.rpy:1084
translate Paloslios day2_warm_activities_a669986b:

    # "The puzzle grows- a wolf at the tree line, golden eyes gleaming even in the dim light. "
    "El rompecabezas crece: un lobo en la línea de árboles, ojos dorados que brillan incluso en la penumbra. "

# game/day2.rpy:1087
translate Paloslios day2_warm_activities_e92e14e1:

    # "Then, the figure. A silhouette, standing just beyond the cabin's reach. Their hand is outstretched, holding-"
    "Luego, la figura. Una silueta, de pie justo fuera del alcance de la cabina. Su mano está extendida, sosteniendo-"

# game/day2.rpy:1089
translate Paloslios day2_warm_activities_57d831bf:

    # "-nothing. The piece is missing."
    "-nada. Falta la pieza."

# game/day2.rpy:1091
translate Paloslios day2_warm_activities_85e43f6a:

    # "You look at the table, but there's nothing left. The figure's hand is empty. A void."
    "Miras la mesa, pero no queda nada. La mano de la figura está vacía. Evitar."

# game/day2.rpy:1093
translate Paloslios day2_warm_activities_64ac19a1:

    # j "That's too bad."
    j "Eso es una lástima."

# game/day2.rpy:1094
translate Paloslios day2_warm_activities_f725af1b:

    # "The figure in the puzzle is holding something- a flower? A knife? But that piece is gone."
    "La figura del rompecabezas sostiene algo: ¿una flor? ¿Un cuchillo? Pero esa pieza ya no está."

# game/day2.rpy:1095
translate Paloslios day2_warm_activities_01ecd209:

    # "You ask if he knows what it is while squinting at the missing figure's hand."
    "Le preguntas si sabe qué es mientras entrecierras los ojos ante la mano de la figura desaparecida."

# game/day2.rpy:1097
translate Paloslios day2_warm_activities_56f94b49:

    # j "Not sure. Don't remember."
    j "No estoy seguro. No lo recuerdo."

# game/day2.rpy:1100
translate Paloslios day2_warm_activities_3110bbae:

    # "His thumb brushes the empty space where the piece should be, before leaning over to grab your hand."
    "Su pulgar roza el espacio vacío donde debería estar la pieza, antes de inclinarse para agarrar tu mano."

# game/day2.rpy:1102
translate Paloslios day2_warm_activities_403c8d00:

    # "His gaze lowers to find yours, full of unspoken meaning."
    "Su mirada baja para encontrar la tuya, llena de significado tácito."

# game/day2.rpy:1103
translate Paloslios day2_warm_activities_a206e738:

    # j "Guess some things stay lost."
    j "Supongo que algunas cosas permanecen perdidas."

# game/day2.rpy:1106
translate Paloslios day2_warm_activities_41963695:

    # "Jim's smile falters and then his thumb idly presses on your wrist- making your pulse jump."
    "La sonrisa de Jim falla y luego su pulgar presiona distraídamente tu muñeca, haciendo que tu pulso se acelere."

# game/day2.rpy:1108
translate Paloslios day2_warm_activities_c8aab1b4:

    # j "...Had a lot of time to practice."
    j "...Tuve mucho tiempo para practicar."

# game/day2.rpy:1110
translate Paloslios day2_warm_activities_30c3f73d:

    # j "Nights get long when you're waiting."
    j "Las noches se hacen largas cuando esperas."

# game/day2.rpy:1113
translate Paloslios day2_warm_activities_91d5d0aa:

    # "Jim releases your hand. His fingers uncurl slowly as if resisting the separation."
    "Jim suelta tu mano. Sus dedos se abren lentamente como si se resistieran a la separación."

# game/day2.rpy:1118
translate Paloslios day2_warm_activities_44fd3be9:

    # "Jim's grip tightens for a heartbeat- then releases."
    "El agarre de Jim se aprieta durante un latido del corazón y luego se suelta."

# game/day2.rpy:1119
translate Paloslios day2_warm_activities_2ebcfc63:

    # j "Guess some pieces don't wanna be found."
    j "Supongo que algunas piezas no quieren ser encontradas."

# game/day2.rpy:1123
translate Paloslios day2_warm_activities_8ab0b27b:

    # "Jim exhales, ragged. His free hand rises, almost cupping your cheek before he catches himself."
    "Jim exhala, harapiento. Su mano libre se levanta, casi ahuecando tu mejilla antes de contenerse."

# game/day2.rpy:1125
translate Paloslios day2_warm_activities_82f31238:

    # j "...Knew you'd understand."
    j "...Sabía que lo entenderías."

# game/day2.rpy:1127
translate Paloslios day2_warm_activities_91d5d0aa_1:

    # "Jim releases your hand. His fingers uncurl slowly as if resisting the separation."
    "Jim suelta tu mano. Sus dedos se abren lentamente como si se resistieran a la separación."

# game/day2.rpy:1129
translate Paloslios day2_warm_activities_4451685c:

    # "For a moment, his palm hovers like he might reach back, but then he exhales, flexing his hand as if shaking off a thought."
    "Por un momento, su palma flota como si fuera a estirar la mano hacia atrás, pero luego exhala, flexionando la mano como si se sacudiera un pensamiento."

# game/day2.rpy:1131
translate Paloslios day2_warm_activities_16288c5f:

    # "Jim studies the puzzle, lips pressed thin, before pushing back from the table to get the puzzle's box."
    "Jim estudia el rompecabezas, con los labios apretados, antes de alejarse de la mesa para coger la caja del rompecabezas."

# game/day2.rpy:1132
translate Paloslios day2_warm_activities_fe31a9fd:

    # j "Maybe that missing piece will turn up later."
    j "Quizás esa pieza faltante aparezca más tarde."

# game/day2.rpy:1133
translate Paloslios day2_warm_activities_6df3f139:

    # "His gaze lingers on the empty space where the last piece should be."
    "Su mirada se detiene en el espacio vacío donde debería estar la última pieza."

# game/day2.rpy:1136
translate Paloslios day2_warm_activities_6049bf87:

    # "Then, he carefully gathers the incomplete puzzle and puts it back in its box."
    "Luego, recoge con cuidado el rompecabezas incompleto y lo devuelve a su caja."

# game/day2.rpy:1140
translate Paloslios day2_warm_activities_a37a7db1:

    # "He stands, stretching with forced casualness."
    "Se pone de pie y se estira con forzada naturalidad."

# game/day2.rpy:1142
translate Paloslios day2_warm_activities_c56f343c:

    # j "...Let's see. Anything else?"
    j "...Vamos a ver. ¿Algo más?"

# game/day2.rpy:1153
translate Paloslios day2_warm_activities_e8df2355:

    # "Jim's smile flickers as he goes over to his small bookcase."
    "La sonrisa de Jim parpadea mientras se acerca a su pequeña estantería."

# game/day2.rpy:1155
translate Paloslios day2_warm_activities_48d3c3fd:

    # "He runs a finger along the bookshelf, hesitating over titles like Folk Remedies of the Valley and Surviving the Wilds."
    "Pasa un dedo por la estantería, dudando sobre títulos como Remedios populares del valle y Sobreviviendo en la selva."

# game/day2.rpy:1157
translate Paloslios day2_warm_activities_5ec5f69a:

    # j "Most of these are...not exactly light reading."
    j "La mayoría de estos son... no exactamente lecturas ligeras."

# game/day2.rpy:1159
translate Paloslios day2_warm_activities_a4210c52:

    # "He plucks a battered novel with a pressed flower bookmark."
    "Coge una novela maltrecha con un marcapáginas de flores prensadas."

# game/day2.rpy:1161
translate Paloslios day2_warm_activities_9939902b:

    # j "But...this one's okay. Romance. Well. Sort of."
    j "Pero... éste está bien. Romance. Bien. Más o menos."

# game/day2.rpy:1163
translate Paloslios day2_warm_activities_b6cfc893:

    # "He hands you the book and the flower to look at."
    "Te entrega el libro y la flor para que los mires."

# game/day2.rpy:1166
translate Paloslios day2_warm_activities_902ecff6:

    # "The flower feels a bit chilly in your hand- your imagination?"
    "La flor se siente un poco fría en tu mano, ¿tu imaginación?"

# game/day2.rpy:1168
translate Paloslios day2_warm_activities_89cb67a6:

    # "The cover is faded, but you catch the title: The Hare and the Hollow."
    "La portada está descolorida, pero se ve el título: La liebre y el hueco."

# game/day2.rpy:1169
translate Paloslios day2_warm_activities_8a14dd0f:

    # "You flip it open to 'Chapter 12: The First Snow', there are handwritten notes crowding the margins- "
    "Lo abres en 'Capítulo 12: La primera nieve', hay notas escritas a mano en los márgenes. "

# game/day2.rpy:1172
translate Paloslios day2_warm_activities_0ae9bcd0:

    # ""
    ""

# game/day2.rpy:1174
translate Paloslios day2_warm_activities_1d15016f:

    # "Jim sees what you're looking at and reaches to take it back flustered."
    "Jim ve lo que estás mirando y se acerca para retirarlo, nervioso."

# game/day2.rpy:1178
translate Paloslios day2_warm_activities_869b6bfd:

    # j "Uh- maybe not that one."
    j "Uh, tal vez no ese."

# game/day2.rpy:1180
translate Paloslios day2_warm_activities_4c32aec1:

    # j "How about you pick something yourself?"
    j "¿Qué tal si eliges algo tú mismo?"

# game/day2.rpy:1182
translate Paloslios day2_warm_activities_46109ab2:

    # "You approach the small, sparse bookcase and read the titles as you run your fingers along the spines."
    "Te acercas a la pequeña y escasa estantería y lees los títulos mientras pasas los dedos por los lomos."

# game/day2.rpy:1184
translate Paloslios day2_warm_activities_2ef2fe94:

    # "Wilderness survival...edible plants...The History of Knot-Tying? Seriously?"
    "Supervivencia en la naturaleza... plantas comestibles... ¿La historia de hacer nudos? ¿En serio?"

# game/day2.rpy:1186
translate Paloslios day2_warm_activities_a94fc92f:

    # "Your fingers pause on a worn leather spine tucked between two larger volumes. It doesn't have a title."
    "Tus dedos se detienen en un lomo de cuero desgastado escondido entre dos volúmenes más grandes. No tiene título."

# game/day2.rpy:1188
translate Paloslios day2_warm_activities_9049b6fb:

    # "When you reach for the untitled book, Jim's breath hitches- then he laughs, too loud."
    "Cuando alcanzas el libro sin título, a Jim se le corta la respiración y luego se ríe demasiado fuerte."

# game/day2.rpy:1189
translate Paloslios day2_warm_activities_0bac1d35:

    # j "Ah- that's just my...weather log. Terrible handwriting. Here-"
    j "Ah, ese es sólo mi... registro meteorológico. Letra terrible. Aquí-"

# game/day2.rpy:1193
translate Paloslios day2_warm_activities_1196ff88:

    # "He snatches a battered poetry collection from the shelf, thumbing to a random page."
    "Coge una colección de poesía maltrecha del estante y hojea una página al azar."

# game/day2.rpy:1195
translate Paloslios day2_warm_activities_605eba37:

    # j "I like this poetry book. Let's see..."
    j "Me gusta este libro de poesía. Veamos..."

# game/day2.rpy:1197
translate Paloslios day2_warm_activities_ce6d0253:

    # "His voice smooths to a reverent murmur as he reads."
    "Su voz se suaviza hasta convertirse en un murmullo reverente mientras lee."

# game/day2.rpy:1198
translate Paloslios day2_warm_activities_eadafc55:

    # j "The moon's bride forgets their name,\n their fingers rooted in his ribs..."
    j "La novia de la luna olvida su nombre, \n sus dedos enraizados en sus costillas..."

# game/day2.rpy:1201
translate Paloslios day2_warm_activities_782c0e41:

    # "He stops abruptly, snapping the book shut. The fire pops. His smile doesn't reach his eyes."
    "Se detiene abruptamente y cierra el libro de golpe. El fuego estalla. Su sonrisa no llega a sus ojos."

# game/day2.rpy:1203
translate Paloslios day2_warm_activities_6f5ca779:

    # j "Maybe...let's do something else..."
    j "Tal vez... hagamos algo más..."

# game/day2.rpy:1205
translate Paloslios day2_warm_activities_0b911b79:

    # "The poetry book lies forgotten between you and you suddenly realize that the pressed flower bookmark is still in your palm."
    "El libro de poesía yace olvidado entre ustedes y de repente se da cuenta de que el marcador de flores prensadas todavía está en su palma."

# game/day2.rpy:1206
translate Paloslios day2_warm_activities_70c2b524:

    # "It feels oddly cool against your skin."
    "Se siente extrañamente frío contra tu piel."

# game/day2.rpy:1208
translate Paloslios day2_warm_activities_3ef9adcb:

    # "Jim catches you looking at the flower and gazes at you expectantly."
    "Jim te pilla mirando la flor y te mira expectante."

# game/day2.rpy:1213
translate Paloslios day2_warm_activities_6ab4bcfd:

    # "You press the petal into your palm, its coolness seeping into your skin like ink in water."
    "Presionas el pétalo en tu palma y su frescura se filtra en tu piel como tinta en agua."

# game/day2.rpy:1214
translate Paloslios day2_warm_activities_6e64b6cd:

    # "The veins beneath your wrist darken for a fleeting second or was it a trick of the firelight?"
    "Las venas debajo de tu muñeca se oscurecen por un fugaz segundo o ¿fue un truco de la luz del fuego?"

# game/day2.rpy:1216
translate Paloslios day2_warm_activities_a32c9566:

    # "You gently tuck it into your pocket."
    "Lo guardas suavemente en tu bolsillo."

# game/day2.rpy:1218
translate Paloslios day2_warm_activities_b9587c35:

    # "Jim's breath stills. He leans forward, voice feather-light but intent."
    "La respiración de Jim se detiene. Se inclina hacia adelante, con voz ligera pero intensa."

# game/day2.rpy:1220
translate Paloslios day2_warm_activities_41406db4:

    # j "...Why did you keep it?"
    j "... ¿Por qué lo guardaste?"

# game/day2.rpy:1221
translate Paloslios day2_warm_activities_833a78c3:

    # "His gaze fixes on your pocket where the flower sits."
    "Su mirada se fija en tu bolsillo donde está la flor."

# game/day2.rpy:1223
translate Paloslios day2_warm_activities_4f27bd96:

    # j "Did it feel like it was...yours?"
    j "¿Se sintió como si fuera… tuyo?"

# game/day2.rpy:1228
translate Paloslios day2_warm_activities_c480e6d7:

    # "Jim's pupils dilate. He exhales through his nose, slow, like he is savoring the moment."
    "Las pupilas de Jim se dilatan. Exhala por la nariz, lentamente, como si estuviera saboreando el momento."

# game/day2.rpy:1230
translate Paloslios day2_warm_activities_05da2d6a:

    # j "Knew it."
    j "Lo sabía."

# game/day2.rpy:1232
translate Paloslios day2_warm_activities_28c96b64:

    # "He laughs and it is raw, relieved. Then, he reaches out, almost touching the petal in your pocket, but pulls back."
    "Él se ríe y se siente crudo, aliviado. Luego, extiende la mano, casi tocando el pétalo en tu bolsillo, pero se retira."

# game/day2.rpy:1234
translate Paloslios day2_warm_activities_5bd91db8:

    # j "...Things find their way where they're needed. Even here."
    j "...Las cosas encuentran su camino donde se necesitan. Incluso aquí."

# game/day2.rpy:1237
translate Paloslios day2_warm_activities_0304d264:

    # "His smile stays, but his fingers dig into his knees for a heartbeat before relaxing."
    "Su sonrisa permanece, pero sus dedos se hunden en sus rodillas durante un segundo antes de relajarse."

# game/day2.rpy:1239
translate Paloslios day2_warm_activities_dded6f89:

    # j "It...is a pretty thing isn't it. It can be."
    j "Es... es algo bonito, ¿no? Puede ser."

# game/day2.rpy:1241
translate Paloslios day2_warm_activities_c88d51b5:

    # "Jim turns his attention to the fire and it dims. The cabin feels smaller."
    "Jim dirige su atención al fuego y este se apaga. La cabina parece más pequeña."

# game/day2.rpy:1242
translate Paloslios day2_warm_activities_0b74e232:

    # j "Funny how ordinary things can cling. Like they're waiting for you to...understand them."
    j "Es curioso cómo las cosas ordinarias pueden aferrarse. Como si estuvieran esperando que tú... los entiendas."

# game/day2.rpy:1245
translate Paloslios day2_warm_activities_6b036830:

    # "Jim tilts his head, studying you like a specimen. The silence stretches too long."
    "Jim inclina la cabeza, estudiándote como a un espécimen. El silencio se prolonga demasiado."

# game/day2.rpy:1247
translate Paloslios day2_warm_activities_38d7281f:

    # j "...That's alright. You will."
    j "...Está bien. Vas a."

# game/day2.rpy:1248
translate Paloslios day2_warm_activities_e8d376a5:

    # "The flower in your pocket feels like it has doubled in weight."
    "La flor en tu bolsillo se siente como si hubiera duplicado su peso."

# game/day2.rpy:1250
translate Paloslios day2_warm_activities_07b9e6f8:

    # "You absentmindedly touch the flower in your pocket, yet a chill lingers on your palm. "
    "Tocas distraídamente la flor en tu bolsillo, pero un escalofrío persiste en tu palma. "

# game/day2.rpy:1253
translate Paloslios day2_warm_activities_19f2f7ca:

    # "You decide to offer it back to him with a shrug."
    "Decides devolvérselo encogiéndose de hombros."

# game/day2.rpy:1255
translate Paloslios day2_warm_activities_1fead312:

    # "You hold it out to him and Jim's smile falters."
    "Se lo tiendes y la sonrisa de Jim falla."

# game/day2.rpy:1257
translate Paloslios day2_warm_activities_feac7fbc:

    # "He doesn't take it- just stares at the petal in your hand like you've handed him a wounded bird."
    "Él no lo acepta, simplemente mira fijamente el pétalo en tu mano como si le hubieras entregado un pájaro herido."

# game/day2.rpy:1258
translate Paloslios day2_warm_activities_21278c07:

    # j "Oh...I thought you'd..."
    j "Oh... pensé que tú..."

# game/day2.rpy:1260
translate Paloslios day2_warm_activities_b9e2499a:

    # j "Nevermind."
    j "No importa."

# game/day2.rpy:1262
translate Paloslios day2_warm_activities_db2a51bb:

    # "There's an awkward beat- then Jim finally plucks the petal from your hand, tucking it into his pocket."
    "Hay un ritmo incómodo, entonces Jim finalmente te quita el pétalo de la mano y se lo guarda en el bolsillo."

# game/day2.rpy:1264
translate Paloslios day2_warm_activities_2fdb76a0:

    # j "I'll save it for you. In case you...change your mind."
    j "Te lo guardaré. En caso de que... cambies de opinión."

# game/day2.rpy:1270
translate Paloslios day2_warm_activities_837ea237:

    # j "Hmm...what now?"
    j "Mmmm… ¿y ahora qué?"

# game/day2.rpy:1275
translate Paloslios day2_warm_activities_dc2d209b:

    # "Jim freezes for a beat, then laughs- a strained, breathy sound."
    "Jim se congela por un momento, luego se ríe, un sonido tenso y entrecortado."

# game/day2.rpy:1279
translate Paloslios day2_warm_activities_5817dc59:

    # "You both go to sit by the fireplace. He sits too close, knees bumping yours."
    "Ambos van a sentarse junto a la chimenea. Se sienta demasiado cerca y sus rodillas chocan con las tuyas."

# game/day2.rpy:1281
translate Paloslios day2_warm_activities_7f0f76b7:

    # j "Talk. Right. Sure. What about?"
    j "Hablar. Bien. Seguro. ¿Qué pasa?"

# game/day2.rpy:1283
translate Paloslios day2_warm_activities_fed9d721:

    # "He toys with his sleeve, tugging it down, as he thinks about what to say next."
    "Juega con su manga, bajándola, mientras piensa qué decir a continuación."

# game/day2.rpy:1285
translate Paloslios day2_warm_activities_479ede31:

    # "You ask about the carvings. Jim's shoulders relax too much as he lifts the large wolf from the mantel."
    "Preguntas sobre las tallas. Los hombros de Jim se relajan demasiado mientras levanta al gran lobo de la repisa de la chimenea."

# game/day2.rpy:1288
translate Paloslios day2_warm_activities_7d28a6ba:

    # "He runs a thumb along the wolf's spine, where the grain splits like an old wound."
    "Pasa el pulgar por la columna del lobo, donde el grano se parte como una vieja herida."

# game/day2.rpy:1289
translate Paloslios day2_warm_activities_3029f061:

    # j "Started whittling after I left...home. Kept my hands busy."
    j "Comencé a tallar después de que me fui... de casa. Mantuve mis manos ocupadas."

# game/day2.rpy:1290
translate Paloslios day2_warm_activities_b479c531:

    # j "Funny thing. The wood carries a lot of memories."
    j "Cosa curiosa. La madera trae muchos recuerdos."

# game/day2.rpy:1293
translate Paloslios day2_warm_activities_f83b7b38:

    # "He leans in and hands it to you, pressing the carving into your palm. His fingers linger, too warm."
    "Se inclina y te lo entrega, presionando la talla en tu palma. Sus dedos permanecen demasiado calientes."

# game/day2.rpy:1294
translate Paloslios day2_warm_activities_90eb0c3e:

    # j "Tell me something you remember. Doesn't matter what. Something true."
    j "Dime algo que recuerdes. No importa qué. Algo cierto."

# game/day2.rpy:1295
translate Paloslios day2_warm_activities_4cb1d454:

    # "His thumb presses your wrist. For a second, the pulse you feel isn't yours."
    "Su pulgar presiona tu muñeca. Por un segundo, el pulso que sientes no es el tuyo."

# game/day2.rpy:1301
translate Paloslios day2_warm_activities_bbaa08a1:

    # "Jim's grip tightens, just for a second, before he forces a chuckle."
    "El agarre de Jim se aprieta, sólo por un segundo, antes de forzar una risa."

# game/day2.rpy:1303
translate Paloslios day2_warm_activities_c4516af2:

    # j "Bet you got far, didn't you? Real far."
    j "Apuesto a que llegaste lejos, ¿no? Muy lejos."

# game/day2.rpy:1304
translate Paloslios day2_warm_activities_786fe9f2:

    # "His thumb traces the veins in your wrist, following their path like a map."
    "Su pulgar traza las venas de tu muñeca, siguiendo su camino como un mapa."

# game/day2.rpy:1306
translate Paloslios day2_warm_activities_398b8cac:

    # j "...Storm's different out here, though. Roads vanish. Trees move. Easy to get turned around."
    j "...Sin embargo, aquí la tormenta es diferente. Los caminos desaparecen. Los árboles se mueven. Es fácil darse la vuelta."

# game/day2.rpy:1311
translate Paloslios day2_warm_activities_9c454b0f:

    # "Jim goes very still. The shadows behind him sway."
    "Jim se queda muy quieto. Las sombras detrás de él se balancean."

# game/day2.rpy:1313
translate Paloslios day2_warm_activities_bdf6d3d2:

    # j "I'm sorry 'bout that."
    j "Lo siento por eso."

# game/day2.rpy:1315
translate Paloslios day2_warm_activities_4f9e5af4:

    # j "But dreams can just be dreams. Not real."
    j "Pero los sueños pueden ser sólo sueños. No es real."

# game/day2.rpy:1317
translate Paloslios day2_warm_activities_0a15251d:

    # "Jim's expression softens- his thumb traces your wrist like he's counting your pulse."
    "La expresión de Jim se suaviza: su pulgar recorre tu muñeca como si estuviera contando tu pulso."

# game/day2.rpy:1318
translate Paloslios day2_warm_activities_e69acb71:

    # j "Sometimes though...I think dreams are doors."
    j "Aunque a veces... creo que los sueños son puertas."

# game/day2.rpy:1320
translate Paloslios day2_warm_activities_4ab5ef0d:

    # j "You oughta be careful what you...invite in."
    j "Deberías tener cuidado con lo que... invitas a entrar."

# game/day2.rpy:1324
translate Paloslios day2_warm_activities_85e0ac4b:

    # "Jim's smile tightens. His thumb presses harder into your pulse point- searching."
    "La sonrisa de Jim se tensa. Su pulgar presiona con más fuerza tu punto de pulso, buscando."

# game/day2.rpy:1325
translate Paloslios day2_warm_activities_db77e2ad:

    # j "...That's aight. I'm sure you'll remember something eventually."
    j "... Eso está bien. Estoy seguro de que eventualmente recordarás algo."

# game/day2.rpy:1327
translate Paloslios day2_warm_activities_c10fc308:

    # "He looks distantly into the fire, eyes unfocused, as his grip on you flexes."
    "Mira a lo lejos el fuego, con los ojos desenfocados, mientras su agarre sobre ti se flexiona."

# game/day2.rpy:1329
translate Paloslios day2_warm_activities_4095e787:

    # j "Memories are like wood grain. Cut deep enough, they bleed."
    j "Los recuerdos son como las vetas de la madera. Si se cortan lo suficientemente profundo, sangran."

# game/day2.rpy:1332
translate Paloslios day2_warm_activities_4f3549f9:

    # "You stroke the wooden wolf's back- its grooves look familiar."
    "Acaricias el lomo del lobo de madera; sus surcos te resultan familiares."

# game/day2.rpy:1334
translate Paloslios day2_warm_activities_c801c244:

    # "His breath catches, his thumb freezing against your wrist."
    "Se queda sin aliento y su pulgar se congela contra tu muñeca."

# game/day2.rpy:1335
translate Paloslios day2_warm_activities_0f963a46:

    # j "...Yeah? What was its name?"
    j "...¿Sí? ¿Cuál era su nombre?"

# game/day2.rpy:1337
translate Paloslios day2_warm_activities_3bfd81a9:

    # "You answer and then he exhales a soft, shuddering sound. Jim gives you a strained smile."
    "Respondes y luego él exhala un sonido suave y estremecedor. Jim te da una sonrisa forzada."

# game/day2.rpy:1339
translate Paloslios day2_warm_activities_ce426210:

    # j "Funny. Had a pup once. Loyal thing. Followed me everywhere."
    j "Divertido. Una vez tuve un cachorro. Cosa leal. Me siguió a todas partes."

# game/day2.rpy:1341
translate Paloslios day2_warm_activities_25e881af:

    # j "Even when it shouldn't have."
    j "Incluso cuando no debería haberlo hecho."

# game/day2.rpy:1344
translate Paloslios day2_warm_activities_85d0f334:

    # "He seems to catch himself, clearing his throat awkwardly."
    "Parece recuperarse y se aclara la garganta con torpeza."

# game/day2.rpy:1349
translate Paloslios day2_warm_activities_d3cb2ec7:

    # "His fingers finally uncurled around your wrist as he got up."
    "Sus dedos finalmente se soltaron alrededor de tu muñeca mientras se levantaba."

# game/day2.rpy:1351
translate Paloslios day2_warm_activities_1ee8f88d:

    # j "Anything else you want to do?"
    j "¿Algo más que quieras hacer?"

# game/day2.rpy:1355
translate Paloslios day2_warm_activities_44815075:

    # "You mention heading to your room and Jim stills- thinking."
    "Mencionas que te diriges a tu habitación y Jim sigue pensando."

# game/day2.rpy:1359
translate Paloslios day2_warm_activities_cf528086:

    # "Jim smiles, satisfied with how you've spent your day."
    "Jim sonríe, satisfecho con cómo has pasado el día."

# game/day2.rpy:1360
translate Paloslios day2_warm_activities_5133f025:

    # "He leans back, remembering all the things you've done together with a slow, catlike satisfaction."
    "Se recuesta, recordando todas las cosas que habéis hecho juntos con una satisfacción lenta y felina."

# game/day2.rpy:1362
translate Paloslios day2_warm_activities_4100087b:

    # j "Knew you'd be good at this. Knew it."
    j "Sabía que serías bueno en esto. Lo sabía."

# game/day2.rpy:1363
translate Paloslios day2_warm_activities_47c64481:

    # j "Guess we've done all I could think of for now."
    j "Supongo que hemos hecho todo lo que se me ocurrió por ahora."

# game/day2.rpy:1366
translate Paloslios day2_warm_activities_29bc1045:

    # "His fingers tap once, sharp, against his arm. Then he smiles, but it doesn't reach his eyes."
    "Sus dedos golpean una vez, con fuerza, contra su brazo. Luego sonríe, pero no llega a sus ojos."

# game/day2.rpy:1368
translate Paloslios day2_warm_activities_603ef1c7:

    # j "...Tired already?"
    j "... ¿Ya estás cansado?"

# game/day2.rpy:1369
translate Paloslios day2_warm_activities_f04aa678:

    # "He doesn't move to stop you. But as you turn, you catch his reflection in the darkened window."
    "Él no se mueve para detenerte. Pero al girarte, ves su reflejo en la ventana oscurecida."

# game/day2.rpy:1371
translate Paloslios day2_warm_activities_ef456182:

    # j "Guess the cold gets to folks faster than I remember. Used to it, myself."
    j "Supongo que el frío afecta a la gente más rápido de lo que recuerdo. Yo también estoy acostumbrado."

# game/day2.rpy:1372
translate Paloslios day2_warm_activities_c10620e4:

    # "His expression is raw, jaw clenched, like a man watching something precious slip through his fingers."
    "Su expresión es cruda, con la mandíbula apretada, como un hombre viendo algo precioso deslizarse entre sus dedos."

# game/day2.rpy:1374
translate Paloslios day2_warm_activities_b7b59cbf:

    # j "I'll come get you when it's dinner time."
    j "Iré a buscarte cuando sea la hora de cenar."

# game/day2.rpy:1375
translate Paloslios day2_warm_activities_0406ec8f:

    # j "Get some rest for now."
    j "Descansa un poco por ahora."

# game/day2.rpy:1380
translate Paloslios day2_warm_activities_61c7bcd3:

    # "You head back to your room, for now, the door clicking closed behind you."
    "Regresas a tu habitación, por ahora, y la puerta se cierra detrás de ti."

# game/day2.rpy:1414
translate Paloslios day2_carving_83eedd57:

    # "The storm has trapped you both inside for another day. The wind howls through the cracks in the cabin walls, but Jim seems almost...content."
    "La tormenta los ha atrapado a ambos adentro por un día más. El viento aúlla a través de las grietas de las paredes de la cabaña, pero Jim parece casi... contento."

# game/day2.rpy:1416
translate Paloslios day2_carving_ab4e92ae:

    # "He sits at the table, a small knife in hand, whittling away at a block of oak. His movements are careful and precise- like a man performing a sacred rite."
    "Está sentado a la mesa, con un pequeño cuchillo en la mano, tallando un bloque de roble. Sus movimientos son cuidadosos y precisos, como los de un hombre realizando un rito sagrado."

# game/day2.rpy:1417
translate Paloslios day2_carving_5be0871c:

    # "He doesn't look at you, but you catch the way his fingers linger over the wood, shaping it with something like reverence."
    "Él no te mira, pero captas la forma en que sus dedos permanecen sobre la madera, dándole forma con algo parecido a reverencia."

# game/day2.rpy:1422
translate Paloslios day2_carving_a8eccc00:

    # "You stay planted where you are hoping not to disturb him. The sound of scrapping continues."
    "Te quedas plantado donde esperas no molestarlo. El sonido del desguace continúa."

# game/day2.rpy:1424
translate Paloslios day2_carving_f7631410:

    # "Eventually, Jim begins to become aware of your gaze as he finishes his work."
    "Con el tiempo, Jim comienza a tomar conciencia de tu mirada mientras termina su trabajo."

# game/day2.rpy:1427
translate Paloslios day2_carving_0279b3a4:

    # "You softly clear your throat and purposely creak the wood underneath as you approach."
    "Te aclaras la garganta suavemente y crujes deliberadamente la madera de debajo mientras te acercas."

# game/day2.rpy:1429
translate Paloslios day2_carving_1ea4686a:

    # "Jim looks up at you with clear eyes."
    "Jim te mira con ojos claros."

# game/day2.rpy:1430
translate Paloslios day2_carving_d6eb0fba:

    # j "Ah...[povname]. I'm almost done."
    j "Ah...[povname]. Ya casi termino."

# game/day2.rpy:1432
translate Paloslios day2_carving_2e9b133e:

    # j "...There."
    j "...Allá."

# game/day2.rpy:1436
translate Paloslios day2_carving_30387522:

    # "Jim jolts to your presence and nearly nicks himself."
    "Jim se sobresalta ante tu presencia y casi se corta."

# game/day2.rpy:1437
translate Paloslios day2_carving_cb0e0693:

    # j "[povname]- I...didn't realize you were there..."
    j "[povname]- Yo...no me di cuenta de que estabas allí..."

# game/day2.rpy:1444
translate Paloslios day2_carving_3b5b970f:

    # "It's a carving of a rabbit."
    "Es una talla de un conejo."

# game/day2.rpy:1445
translate Paloslios day2_carving_26a962a6:

    # "A small, fragile thing- ears folded back, body coiled as if ready to flee."
    "Una cosa pequeña y frágil: orejas dobladas hacia atrás y cuerpo enrollado como si estuviera listo para huir."

# game/day2.rpy:1450
translate Paloslios day2_carving_b1b67e17:

    # "It's a carving of a fox."
    "Es una talla de un zorro."

# game/day2.rpy:1451
translate Paloslios day2_carving_b9674114:

    # "Sleek and clever with a sly tilt to its head."
    "Elegante e inteligente con una astuta inclinación de cabeza."

# game/day2.rpy:1456
translate Paloslios day2_carving_42066d56:

    # "It's a carving of a wolf."
    "Es una talla de un lobo."

# game/day2.rpy:1457
translate Paloslios day2_carving_6152fa5a:

    # "Fangs bared and shoulders hunched. Not a plea- a warning."
    "Colmillos al descubierto y hombros encorvados. No es una súplica, sino una advertencia."

# game/day2.rpy:1461
translate Paloslios day2_carving_1f993522:

    # "When the carving is finished, Jim hesitates. His thumb brushes over the creature's back, passing over its form."
    "Cuando termina la talla, Jim duda. Su pulgar roza la espalda de la criatura, pasando por su forma."

# game/day2.rpy:1465
translate Paloslios day2_carving_6e6dc10b:

    # "He sets it on the table, facing away from you, to look at the finished carving. A silent offering, unacknowledged."
    "Lo coloca sobre la mesa, de espaldas a ti, para observar la talla terminada. Una ofrenda silenciosa, no reconocida."

# game/day2.rpy:1466
translate Paloslios day2_carving_21f806b7:

    # "It is not for you. Not yet. Maybe never."
    "No es para ti. Aún no. Quizás nunca."

# game/day2.rpy:1473
translate Paloslios day2_carving_8cc0ad9a:

    # "Jim looks surprised but doesn't stop you."
    "Jim parece sorprendido pero no te detiene."

# game/day2.rpy:1478
translate Paloslios day2_carving_00826ac9:

    # "Jim takes the carving and pockets it."
    "Jim toma la talla y se la guarda en el bolsillo."

# game/day2.rpy:1482
translate Paloslios day2_carving_85d844ea:

    # "Jim wordlessly leaves the room to retire for the night. Not even bothering to say goodnight."
    "Jim sin decir palabra sale de la habitación para retirarse a pasar la noche. Ni siquiera molestarme en decir buenas noches."

# game/day2.rpy:1489
translate Paloslios day2_carving_80c83e71:

    # "The sound is too loud in the quiet cabin, like a bone breaking."
    "El sonido es demasiado fuerte en la cabina silenciosa, como el de un hueso rompiéndose."

# game/day2.rpy:1491
translate Paloslios day2_carving_43b18f8c:

    # "Jim carefully gathers the shattered remains of the carving."
    "Jim recoge con cuidado los restos destrozados de la talla."

# game/day2.rpy:1497
translate Paloslios day2_carving_119ec47a:

    # "His eyes grow dark and he looks at you with outright disdain. But he leaves the room wordlessly."
    "Sus ojos se oscurecen y te mira con absoluto desdén. Pero sale de la habitación sin decir palabra."

# game/day2.rpy:1498
translate Paloslios day2_carving_bfdb00fa:

    # "He has nothing to say to you."
    "No tiene nada que decirte."

# game/day2.rpy:1503
translate Paloslios day2_carving_cf9d5325:

    # "He seems to consider the object in his hands before putting the carving away into his pocket without another word."
    "Parece considerar el objeto en sus manos antes de guardar la talla en su bolsillo sin decir una palabra más."

# game/day2.rpy:1505
translate Paloslios day2_carving_7be986d6:

    # "You note a flash of pain across his face before he turns away."
    "Notas un destello de dolor en su rostro antes de que se dé vuelta."

# game/day2.rpy:1509
translate Paloslios day2_carving_7d95fa0b:

    # "Jim freezes, his fingers tightening around the carving."
    "Jim se congela y sus dedos se aprietan alrededor de la talla."

# game/day2.rpy:1511
translate Paloslios day2_carving_bf30c245:

    # "When he turns back, his gaze is searching, wary- but there's a fragile hope there too, like he's bracing for rejection."
    "Cuando se da vuelta, su mirada es inquisitiva, cautelosa, pero también hay una frágil esperanza allí, como si se estuviera preparando para el rechazo."

# game/day2.rpy:1513
translate Paloslios day2_carving_cab8e455:

    # j "Do...you want it?"
    j "¿...lo quieres?"

# game/day2.rpy:1517
translate Paloslios day2_carving_6c01e4a9:

    # "You say nothing. Jim hesitates for a heartbeat, as if waiting, hoping, for you to stop him."
    "No dices nada. Jim duda por un instante, como si esperara, deseara que lo detuvieras."

# game/day2.rpy:1518
translate Paloslios day2_carving_831397f3:

    # "When you don't, his jaw tightens."
    "Cuando no lo haces, su mandíbula se aprieta."

# game/day2.rpy:1519
translate Paloslios day2_carving_2e43b976:

    # j "Well, good night then."
    j "Bueno, buenas noches entonces."

# game/day2.rpy:1523
translate Paloslios day2_carving_2b929726:

    # "He doesn't look at you as he walks away. His footsteps are too measured, his shoulders rigid. The door to his room clicks shut behind him."
    "No te mira mientras se aleja. Sus pasos son demasiado mesurados y sus hombros rígidos. La puerta de su habitación se cierra detrás de él."

# game/day2.rpy:1528
translate Paloslios day2_carving_87fcc8c2:

    # "With a twitch of his lip, he seems to decide to pick up his knife again and whittles away quickly."
    "Con un movimiento de su labio, parece decidir tomar su cuchillo nuevamente y lo corta rápidamente."

# game/day2.rpy:1531
translate Paloslios day2_carving_93d62d11:

    # "He carves a small hole through its heart, threads it onto a leather cord, and ties it around your neck without asking."
    "Hace un pequeño agujero en su corazón, lo enrosca en un cordón de cuero y lo ata alrededor de tu cuello sin preguntar."

# game/day2.rpy:1532
translate Paloslios day2_carving_1b34c529:

    # "His fingers linger too long on your pulse which jumps at his touch."
    "Sus dedos permanecen demasiado tiempo en tu pulso, que salta ante su toque."

# game/day2.rpy:1534
translate Paloslios day2_carving_9fb8a9b6:

    # j "So you remember..."
    j "Entonces recuerdas..."

# game/day2.rpy:1535
translate Paloslios day2_carving_554662e7:

    # "His voice is a gentle murmur with something dangerously close to tenderness."
    "Su voz es un suave murmullo con algo peligrosamente cercano a la ternura."

# game/day2.rpy:1537
translate Paloslios day2_carving_c77fa967:

    # j "Even when I'm not around."
    j "Incluso cuando no estoy cerca."

# game/day2.rpy:1550
translate Paloslios necklace_choices_17615cb4:

    # "You trace the carving with your fingertips and you want it around your throat."
    "Trazas la talla con las yemas de los dedos y la quieres alrededor de tu garganta."

# game/day2.rpy:1554
translate Paloslios necklace_choices_aee6bc9d:

    # "Jim seems to read your desire and tentatively takes the carving in his hand."
    "Jim parece leer tu deseo y tentativamente toma la talla en su mano."

# game/day2.rpy:1555
translate Paloslios necklace_choices_c700a4fe:

    # "He carves a small hole through its heart and threads it onto a leather cord."
    "Hace un pequeño agujero en su corazón y lo enrosca en un cordón de cuero."

# game/day2.rpy:1558
translate Paloslios necklace_choices_247f3b72:

    # "He hands it back to you with a wary look."
    "Te lo devuelve con una mirada cautelosa."

# game/day2.rpy:1560
translate Paloslios necklace_choices_4585ca4f:

    # "You awkwardly put the necklace onto yourself as Jim watches attentively."
    "Te pones el collar torpemente mientras Jim observa atentamente."

# game/day2.rpy:1564
translate Paloslios necklace_choices_aee6bc9d_1:

    # "Jim seems to read your desire and tentatively takes the carving in his hand."
    "Jim parece leer tu deseo y tentativamente toma la talla en su mano."

# game/day2.rpy:1565
translate Paloslios necklace_choices_8d67b13b:

    # "With a twitch of his lip, he picks up his knife again and whittles away quickly."
    "Con un movimiento de su labio, toma su cuchillo nuevamente y lo corta rápidamente."

# game/day2.rpy:1566
translate Paloslios necklace_choices_c700a4fe_1:

    # "He carves a small hole through its heart and threads it onto a leather cord."
    "Hace un pequeño agujero en su corazón y lo enrosca en un cordón de cuero."

# game/day2.rpy:1569
translate Paloslios necklace_choices_f6609708:

    # "He hands it back to you with an expectant look."
    "Te lo devuelve con una mirada expectante."

# game/day2.rpy:1575
translate Paloslios necklace_choices_8432a851:

    # "Jim stiffens for a heartbeat- then hurridly obliges you."
    "Jim se pone rígido por un momento y luego rápidamente te complace."

# game/day2.rpy:1579
translate Paloslios necklace_choices_4585ca4f_1:

    # "You awkwardly put the necklace onto yourself as Jim watches attentively."
    "Te pones el collar torpemente mientras Jim observa atentamente."

# game/day2.rpy:1583
translate Paloslios necklace_choices_84017690:

    # "Your hand slowly curls around the necklace that Jim placed on you with acceptance."
    "Tu mano se enrosca lentamente alrededor del collar que Jim te colocó con aceptación."

# game/day2.rpy:1586
translate Paloslios necklace_choices_6eb598d7:

    # "The first thing you notice is that the cord around your neck is tight. A collar disguised as jewelry."
    "Lo primero que notas es que el cordón alrededor de tu cuello está apretado. Un collar disfrazado de joyería."

# game/day2.rpy:1587
translate Paloslios necklace_choices_af5ca440:

    # "The thin leather knotted snug around your throat is not enough to choke, but enough that you always feel it there."
    "El fino cuero anudado alrededor de tu garganta no es suficiente para ahogarte, pero sí para que siempre lo sientas allí."

# game/day2.rpy:1588
translate Paloslios necklace_choices_12b6c281:

    # "The wood is smooth, almost too delicate- like it might splinter if gripped too hard."
    "La madera es lisa, casi demasiado delicada, como si pudiera astillarse si se agarra con demasiada fuerza."

# game/day2.rpy:1590
translate Paloslios necklace_choices_289388f0:

    # "The wood is polished, but the edges are still sharp- if you press too hard, it might draw blood."
    "La madera está pulida, pero los bordes aún están afilados; si presiona demasiado fuerte, podría sacar sangre."

# game/day2.rpy:1592
translate Paloslios necklace_choices_16c9e0d0:

    # "A snarling wolf, teeth bared, the grain of the wood mimicking fur. It's rough, the feeling uncomfortable against your skin."
    "Un lobo gruñendo, enseñando los dientes y la veta de la madera imitando el pelaje. Es áspero, la sensación incómoda contra tu piel."

# game/day2.rpy:1596
translate Paloslios necklace_choices_016be1d3:

    # "Jim looks at the carving around your neck with a complicated expression."
    "Jim mira el grabado alrededor de tu cuello con una expresión complicada."

# game/day2.rpy:1600
translate Paloslios necklace_choices_1dc2643a:

    # "He seems to consider you for an extra beat before going to his room for the night."
    "Parece considerarte un rato más antes de ir a su habitación a pasar la noche."

# game/day2.rpy:1603
translate Paloslios necklace_choices_617c9741:

    # "Jim's eyes burn in the dim light at the sight of you, breath shallow."
    "Los ojos de Jim arden en la tenue luz al verte, con la respiración entrecortada."

# game/day2.rpy:1604
translate Paloslios necklace_choices_8fc04351:

    # j "I knew it would suit you..."
    j "Sabía que te vendría bien..."

# game/day2.rpy:1607
translate Paloslios necklace_choices_f20df3c3:

    # "He shifts closer, his knee brushing yours as he reaches out to adjust the carving."
    "Se acerca, su rodilla roza la tuya mientras extiende la mano para ajustar el tallado."

# game/day2.rpy:1608
translate Paloslios necklace_choices_5445d9fc:

    # "His touch lingers- warm, calloused fingers tracing the curve of the carving's back alongside your skin."
    "Su tacto perdura: dedos cálidos y callosos que trazan la curva del dorso del tallado a lo largo de tu piel."

# game/day2.rpy:1610
translate Paloslios necklace_choices_c8dd7c67:

    # j "You...hmm..."
    j "Tú... mmm..."

# game/day2.rpy:1611
translate Paloslios necklace_choices_39c4e801:

    # j "Fits you better than I thought it would."
    j "Te queda mejor de lo que pensé."

# game/day2.rpy:1612
translate Paloslios necklace_choices_b4ac27ea:

    # "There's a weight to the words, something deeper than just the carving."
    "Las palabras tienen un peso, algo más profundo que el simple grabado."

# game/day2.rpy:1617
translate Paloslios necklace_choices_e23682ba:

    # "He starts pacing around the room. Looking at the fire. Peering at the walls."
    "Comienza a caminar por la habitación. Mirando el fuego. Mirando las paredes."

# game/day2.rpy:1619
translate Paloslios necklace_choices_8f412272:

    # "He's stalling. You can tell by the way his shoulders stay tense, the way his gaze keeps flicking back to you."
    "Está estancado. Puedes notarlo por la forma en que sus hombros se mantienen tensos, la forma en que su mirada sigue moviéndose hacia ti."

# game/day2.rpy:1620
translate Paloslios necklace_choices_46a42850:

    # "Finally, he exhales, running a hand through his hair."
    "Finalmente, exhala y se pasa una mano por el cabello."

# game/day2.rpy:1621
translate Paloslios necklace_choices_a6316771:

    # j "I'll...have to make you more things if you like it..."
    j "Tendré... que hacerte más cosas si te gusta..."

# game/day2.rpy:1624
translate Paloslios necklace_choices_e2489b5c:

    # "When he starts to retreat to his room, his steps are lighter than usual."
    "Cuando comienza a retirarse a su habitación, sus pasos son más ligeros de lo habitual."

# game/day2.rpy:1625
translate Paloslios necklace_choices_dfacab04:

    # j "I'll...see you soon. Night."
    j "Te... veré pronto. Noche."

# game/day2.rpy:1629
translate Paloslios necklace_choices_d51bfeee:

    # "He strides into his room without another word."
    "Entra a su habitación sin decir una palabra más."

# game/day2.rpy:1636
translate Paloslios necklace_choices_cf3b1712:

    # "You trace the carving with your fingertips, but you don't want to wear it."
    "Trazas la talla con las yemas de los dedos, pero no quieres usarla."

# game/day2.rpy:1639
translate Paloslios necklace_choices_2b81ff07:

    # "Jim looks at the carving in your hand with a complicated expression, but doesn't move to take it back."
    "Jim mira la talla en tu mano con una expresión complicada, pero no se mueve para retirarla."

# game/day2.rpy:1643
translate Paloslios necklace_choices_1dc2643a_1:

    # "He seems to consider you for an extra beat before going to his room for the night."
    "Parece considerarte un rato más antes de ir a su habitación a pasar la noche."

# game/day2.rpy:1649
translate Paloslios necklace_choices_386c601f:

    # "You take the carving off, much to Jim's dismay, but he doesn't stop you."
    "Quitas el tallado, para consternación de Jim, pero él no te detiene."

# game/day2.rpy:1651
translate Paloslios necklace_choices_51ef240a:

    # "Jim watches as you turn the wooden carving over in your hands, his usual guarded expression softening at the edges."
    "Jim observa mientras le das la vuelta a la talla de madera en tus manos, su habitual expresión cautelosa se suaviza en los bordes."

# game/day2.rpy:1653
translate Paloslios necklace_choices_f22be58e:

    # j "It looks better in your hands..."
    j "Se ve mejor en tus manos..."

# game/day2.rpy:1655
translate Paloslios necklace_choices_81104d18:

    # "Then Jim clears his throat, suddenly awkward, and turns back to the fire."
    "Entonces Jim se aclara la garganta, repentinamente incómodo, y se vuelve hacia el fuego."

# game/day2.rpy:1657
translate Paloslios necklace_choices_b91ff06d:

    # "But you catch the faintest curve of his mouth before he hides it."
    "Pero captas la más leve curva de su boca antes de que la oculte."

# game/day2.rpy:1659
translate Paloslios necklace_choices_a75f20c5:

    # j "I'm glad you're keeping it."
    j "Me alegro que lo guardes."

# game/day2.rpy:1660
translate Paloslios necklace_choices_0d489a18:

    # "Before he turns in for the night, he hesitates, glancing back at you."
    "Antes de acostarse a pasar la noche, duda y te mira."

# game/day2.rpy:1662
translate Paloslios necklace_choices_960f7a93:

    # j "Well...Night."
    j "Bueno... Noche."

# game/day2.rpy:1666
translate Paloslios necklace_choices_7a3b02b8:

    # "He stands to leave without another word."
    "Se dispone a marcharse sin decir una palabra más."

# game/day2.rpy:1671
translate Paloslios necklace_choices_4e8df410:

    # "You consider it for a moment, but ultimately don't want it."
    "Lo consideras por un momento, pero al final no lo quieres."

# game/day2.rpy:1675
translate Paloslios necklace_choices_7e8b82f9:

    # "You hand the carving back to him."
    "Le devuelves la talla."

# game/day2.rpy:1678
translate Paloslios necklace_choices_64f792fa:

    # "Jim takes the carving back and pockets it wordlessly."
    "Jim recupera la talla y se la guarda en el bolsillo sin decir palabra."

# game/day2.rpy:1683
translate Paloslios necklace_choices_1dc2643a_2:

    # "He seems to consider you for an extra beat before going to his room for the night."
    "Parece considerarte un rato más antes de ir a su habitación a pasar la noche."

# game/day2.rpy:1686
translate Paloslios necklace_choices_7e8b82f9_1:

    # "You hand the carving back to him."
    "Le devuelves la talla."

# game/day2.rpy:1687
translate Paloslios necklace_choices_99a718d3:

    # "His fingers twitch once, curling into his palm like he's been burned. The air between you thickens, the firelight dimming as if the very room recoils."
    "Sus dedos se contraen una vez, curvándose en su palma como si se hubiera quemado. El aire entre ustedes se espesa, la luz del fuego se atenúa como si la propia habitación retrocediera."

# game/day2.rpy:1688
translate Paloslios necklace_choices_d5994a3d:

    # j "I see..."
    j "Ya veo..."

# game/day2.rpy:1690
translate Paloslios necklace_choices_d03398be:

    # "A muscle jumps in his jaw. He doesn't raise his voice. Doesn't have to. The quiet is worse."
    "Un músculo salta en su mandíbula. No levanta la voz. No es necesario. El silencio es peor."

# game/day2.rpy:1691
translate Paloslios necklace_choices_4012efe2:

    # j "Guess I misread things."
    j "Supongo que leí mal las cosas."

# game/day2.rpy:1694
translate Paloslios necklace_choices_e295aa20:

    # "He slips the carving into his pocket with a quiet finality."
    "Desliza la talla en su bolsillo con silenciosa finalidad."

# game/day2.rpy:1696
translate Paloslios necklace_choices_be96391f:

    # j "Maybe you'll want it later."
    j "Quizás lo quieras más tarde."

# game/day2.rpy:1700
translate Paloslios necklace_choices_9dc95a60:

    # "He gets up and hurriedly leaves. The door shuts behind him with a quiet click."
    "Se levanta y se va apresuradamente. La puerta se cierra detrás de él con un suave clic."

# game/day2.rpy:1707
translate Paloslios necklace_choices_932d4a4b:

    # "The snap of wood is louder than you expected. The sound is too loud in the quiet cabin, like a bone breaking."
    "El chasquido de la madera es más fuerte de lo que esperabas. El sonido es demasiado fuerte en la cabina silenciosa, como el de un hueso rompiéndose."

# game/day2.rpy:1709
translate Paloslios necklace_choices_43b18f8c:

    # "Jim carefully gathers the shattered remains of the carving."
    "Jim recoge con cuidado los restos destrozados de la talla."

# game/day2.rpy:1715
translate Paloslios necklace_choices_119ec47a:

    # "His eyes grow dark and he looks at you with outright disdain. But he leaves the room wordlessly."
    "Sus ojos se oscurecen y te mira con absoluto desdén. Pero sale de la habitación sin decir palabra."

# game/day2.rpy:1716
translate Paloslios necklace_choices_bfdb00fa:

    # "He has nothing to say to you."
    "No tiene nada que decirte."

# game/day2.rpy:1748
translate Paloslios day2_kiss_eb559408:

    # "With nothing else to do, you also head back to your room."
    "Sin nada más que hacer, también regresas a tu habitación."

# game/day2.rpy:1760
translate Paloslios day2_kiss_27357b84:

    # "The bed creaks as you settle in, the blankets too stiff, the air too still."
    "La cama cruje cuando te acomodas, las mantas demasiado rígidas y el aire demasiado quieto."

# game/day2.rpy:1765
translate Paloslios day2_kiss_ddf9bc32:

    # "You try to sleep, but it comes in shallow waves."
    "Intentas dormir, pero llega en oleadas poco profundas."

# game/day2.rpy:1769
translate Paloslios day2_kiss_11d5072d:

    # "Each time you start to drift to sleep, the shadows at the edges of the room seem to shift just slightly."
    "Cada vez que empiezas a quedarte dormido, las sombras en los bordes de la habitación parecen cambiar ligeramente."

# game/day2.rpy:1772
translate Paloslios day2_kiss_87c718cd:

    # "A thud. A muffled curse. The creak of floorboards bearing weight. The cabin is too quiet for the sound to be anything but deliberate."
    "Un ruido sordo. Una maldición ahogada. El crujido de las tablas del suelo que soportan peso. La cabina es demasiado silenciosa para que el sonido no sea deliberado."

# game/day2.rpy:1774
translate Paloslios day2_kiss_e47adbc9:

    # "You sit up. A sliver of light bleeds under your door- someone's still awake."
    "Te sientas. Un rayo de luz se filtra debajo de tu puerta: alguien todavía está despierto."

# game/day2.rpy:1779
translate Paloslios day2_kiss_0b1e6d9d:

    # "You are drawn to the noise and venture out of your room."
    "Te atrae el ruido y te aventuras a salir de tu habitación."

# game/day2.rpy:1780
translate Paloslios day2_kiss_b78bba84:

    # "Night falls heavy over the cabin, the fire reduced to embers. The wind has quieted, but the silence is worse- thick with unsaid words."
    "La noche cae pesadamente sobre la cabaña, el fuego reducido a brasas. El viento se ha calmado, pero el silencio es peor: está lleno de palabras no dichas."

# game/day2.rpy:1782
translate Paloslios day2_kiss_2a8354da:

    # "Jim stands by the window, his back to you, fingers absently tracing the edge of the wood carving knife."
    "Jim está de pie junto a la ventana, de espaldas a ti, con los dedos trazando distraídamente el filo del cuchillo para tallar madera."

# game/day2.rpy:1783
translate Paloslios day2_kiss_add6cba6:

    # "You can see the tension in his shoulders, the way his breath fogs the glass in uneven bursts. He knows you're watching. He always knows."
    "Puedes ver la tensión en sus hombros, la forma en que su aliento empaña el cristal en ráfagas desiguales. Él sabe que estás mirando. Él siempre lo sabe."

# game/day2.rpy:1787
translate Paloslios day2_kiss_28ddbe42:

    # "A shudder runs through him when you call out to him. For a long moment, he doesn't move."
    "Un escalofrío lo recorre cuando lo llamas. Durante un largo momento, él no se mueve."

# game/day2.rpy:1788
translate Paloslios day2_kiss_0cad1055:

    # "Then, slowly, he sets the carving knife away and turns to face you."
    "Luego, lentamente, guarda el cuchillo de trinchar y se gira hacia ti."

# game/day2.rpy:1791
translate Paloslios day2_kiss_58a9bb51:

    # "You step closer, the floorboards creaking under your weight."
    "Te acercas y las tablas del suelo crujen bajo tu peso."

# game/day2.rpy:1792
translate Paloslios day2_kiss_fa7abc73:

    # "Jim doesn't turn, but his grip on the carving knife tightens."
    "Jim no se da vuelta, pero aprieta con más fuerza el cuchillo de trinchar."

# game/day2.rpy:1794
translate Paloslios day2_kiss_46334010:

    # "He looks like he might want to be alone...and you also didn't want to face him now."
    "Parece que quisiera estar solo... y tú tampoco querías enfrentarlo ahora."

# game/day2.rpy:1795
translate Paloslios day2_kiss_b8530e68:

    # "So, you quietly start heading to your room."
    "Entonces, silenciosamente comienzas a dirigirte a tu habitación."

# game/day2.rpy:1799
translate Paloslios day2_kiss_4bba67ee:

    # "When Jim turns to face you, the moonlight paints his face in blue and shadow, his eyes dark and unreadable."
    "Cuando Jim se gira para mirarte, la luz de la luna pinta su rostro de azul y sombras, sus ojos son oscuros e ilegibles."

# game/day2.rpy:1800
translate Paloslios day2_kiss_f10f3bf1:

    # "There's something raw in his expression- something hungry and hesitant all at once."
    "Hay algo crudo en su expresión: algo hambriento y vacilante al mismo tiempo."

# game/day2.rpy:1801
translate Paloslios day2_kiss_b29c9546:

    # j "...Couldn't sleep."
    j "...No podía dormir."

# game/day2.rpy:1803
translate Paloslios day2_kiss_827d95d8:

    # j "But you should be asleep."
    j "Pero deberías estar dormido."

# game/day2.rpy:1804
translate Paloslios day2_kiss_6fca0565:

    # "His voice is rough, raw."
    "Su voz es áspera, cruda."

# game/day2.rpy:1808
translate Paloslios day2_kiss_885fb3f6:

    # "You state back at him simply and he tenses."
    "Le respondes simplemente y él se tensa."

# game/day2.rpy:1811
translate Paloslios day2_kiss_c1955f61:

    # j "Then, I'm sorry for bothering you."
    j "Entonces, lamento haberte molestado."

# game/day2.rpy:1814
translate Paloslios day2_kiss_19309647:

    # "Jim exhales and you aren't sure if it's disappointment or relief."
    "Jim exhala y no estás seguro si es decepción o alivio."

# game/day2.rpy:1816
translate Paloslios day2_kiss_55c988d1:

    # "The air between you is charged, electric."
    "El aire entre ustedes está cargado, eléctrico."

# game/day2.rpy:1820
translate Paloslios day2_kiss_62144bb5:

    # "He swallows hard, his gaze flickering to your lips, then away- like he's afraid of what he might do if he looks too long."
    "Traga saliva con dificultad, su mirada va a tus labios y luego se aleja, como si tuviera miedo de lo que podría hacer si mira demasiado."

# game/day2.rpy:1832
translate Paloslios day2_kiss_234b42d5:

    # "Jim hesitates, his hand hovering near your face like he's afraid to touch you."
    "Jim duda, su mano se cierne cerca de tu cara como si tuviera miedo de tocarte."

# game/day2.rpy:1837
translate Paloslios day2_kiss_743faedd:

    # "When you lean in, he lets out a shaky breath, his fingers finally brushing your cheek."
    "Cuando te inclinas, él deja escapar un suspiro tembloroso y sus dedos finalmente rozan tu mejilla."

# game/day2.rpy:1840
translate Paloslios day2_kiss_72df343f:

    # "The kiss is soft, almost tentative- a question, not a demand."
    "El beso es suave, casi vacilante: una pregunta, no una exigencia."

# game/day2.rpy:1841
translate Paloslios day2_kiss_8335f2a1:

    # "His lips are chapped from the cold, but warm, so warm."
    "Sus labios están agrietados por el frío, pero cálidos, muy cálidos."

# game/day2.rpy:1845
translate Paloslios day2_kiss_b1a49329:

    # "When he pulls back, his eyes are wide, vulnerable."
    "Cuando retrocede, sus ojos están muy abiertos, vulnerables."

# game/day2.rpy:1847
translate Paloslios day2_kiss_02dc1e84:

    # j "I- I didn't-"
    j "Yo-yo no-"

# game/day2.rpy:1854
translate Paloslios day2_kiss_0a4ab014:

    # "You kiss him again, and this time, he whimpers against your mouth, his hands trembling where they cradle your face."
    "Lo besas de nuevo, y esta vez, él gime contra tu boca, sus manos tiemblan cuando sostienen tu rostro."

# game/day2.rpy:1858
translate Paloslios day2_kiss_cdf4a64a:

    # "Jim avoids your eyes afterward, his ears red. He touches his lips like he's trying to memorize the feeling."
    "Jim evita tus ojos después, con las orejas rojas. Se toca los labios como si estuviera tratando de memorizar el sentimiento."

# game/day2.rpy:1869
translate Paloslios day2_kiss_11811732:

    # "A look of frustration flashes across his face-"
    "Una mirada de frustración cruza su rostro."

# game/day2.rpy:1874
translate Paloslios day2_kiss_7d240dd2:

    # "-but Jim breaks at your command and closes the distance."
    "-pero Jim se rompe ante tu orden y acorta la distancia."

# game/day2.rpy:1877
translate Paloslios day2_kiss_0341aac4:

    # "In one swift motion, his lips are on yours, his hands gripping your hips hard enough to bruise."
    "En un movimiento rápido, sus labios están sobre los tuyos, sus manos agarran tus caderas con tanta fuerza como para causar moretones."

# game/day2.rpy:1879
translate Paloslios day2_kiss_dd25e647:

    # "The kiss is fierce, all teeth and desperation. He nips at your lower lip, his breath hot against your skin."
    "El beso es feroz, todo dientes y desesperación. Muerde tu labio inferior, su aliento caliente contra tu piel."

# game/day2.rpy:1881
translate Paloslios day2_kiss_bda7d258:

    # "When you gasp, he groans, pressing closer, like he wants to melt into you."
    "Cuando jadeas, él gime, acercándose más, como si quisiera fundirse en ti."

# game/day2.rpy:1883
translate Paloslios day2_kiss_810f51d0:

    # j "Mine..."
    j "El mío..."

# game/day2.rpy:1884
translate Paloslios day2_kiss_7c2ba922:

    # "It's not a request. It's a claim."
    "No es una petición. Es un reclamo."

# game/day2.rpy:1885
translate Paloslios day2_kiss_292640f8:

    # "He doesn't let go, his forehead pressed to yours as he struggles to steady his breathing."
    "Él no te suelta, su frente presiona la tuya mientras lucha por estabilizar su respiración."

# game/day2.rpy:1886
translate Paloslios day2_kiss_5e6c6960:

    # j "I...you-"
    j "Yo...tú-"

# game/day2.rpy:1888
translate Paloslios day2_kiss_ac8f3efb:

    # "He struggles to say something but swallows it instead."
    "Se esfuerza por decir algo, pero se lo traga."

# game/day2.rpy:1892
translate Paloslios day2_kiss_6e95b74c:

    # "Jim turns away and his jaw clenches."
    "Jim se da vuelta y aprieta la mandíbula."

# game/day2.rpy:1894
translate Paloslios day2_kiss_5c932801:

    # "He slowly exhales and you aren't sure if it's disappointment or relief."
    "Exhala lentamente y no estás segura si es decepción o alivio."

# game/day2.rpy:1904
translate Paloslios day2_kiss_lowlove_e98781ad:

    # "He starts leaning towards you, but turns his head at the last second. His jaw clenches."
    "Empieza a inclinarse hacia ti, pero gira la cabeza en el último segundo. Su mandíbula se aprieta."

# game/day2.rpy:1906
translate Paloslios day2_kiss_lowlove_5bcfda07:

    # j "Don't."
    j "No."

# game/day2.rpy:1907
translate Paloslios day2_kiss_lowlove_b3acddbc:

    # "You don't know if he's talking to you or himself."
    "No sabes si te está hablando a ti o a él mismo."

# game/day2.rpy:1910
translate Paloslios day2_kiss_lowlove_8ca65ce9:

    # "But his hands are fisted in your shirt, pulling you closer even as he pushes you away."
    "Pero sus manos están apretadas en tu camisa, acercándote incluso mientras te aleja."

# game/day2.rpy:1918
translate Paloslios day2_kiss_lowlove_b0885e13:

    # "When you try again, he lets you- but the kiss is brief, bitter."
    "Cuando lo intentas de nuevo, te deja, pero el beso es breve, amargo."

# game/day2.rpy:1920
translate Paloslios day2_kiss_lowlove_a447cc29:

    # "He breaks it with a sharp inhale."
    "Lo rompe con una fuerte inhalación."

# game/day2.rpy:1922
translate Paloslios day2_kiss_lowlove_c58f64f9:

    # j "You'll regret this."
    j "Te arrepentirás de esto."

# game/day2.rpy:1928
translate Paloslios day2_kiss_lowlove_72902772:

    # "You reluctantly step back and try to calm yourself from what almost happened."
    "Das un paso atrás de mala gana y tratas de calmarte de lo que casi sucedió."

# game/day2.rpy:1929
translate Paloslios day2_kiss_lowlove_5c932801:

    # "He slowly exhales and you aren't sure if it's disappointment or relief."
    "Exhala lentamente y no estás segura si es decepción o alivio."

# game/day2.rpy:1938
translate Paloslios day2_kiss_averted_1f678f8b:

    # "To your confusion, Jim puts on his jacket and hat by the door."
    "Para tu confusión, Jim se pone la chaqueta y el sombrero junto a la puerta."

# game/day2.rpy:1942
translate Paloslios day2_kiss_averted_f77d3cc5:

    # "Then, he wordlessly goes out of the cabin."
    "Luego, sin decir palabra, sale de la cabina."

# game/day2.rpy:1943
translate Paloslios day2_kiss_averted_ef383b57:

    # "The door clicks shut behind him and there's a beat of silence."
    "La puerta se cierra detrás de él y hay un momento de silencio."

# game/day2.rpy:1945
translate Paloslios day2_kiss_averted_054c16c7:

    # "Then- the unmistakable click of a lock engaging."
    "Luego, el inconfundible clic de una cerradura al abrirse."

# game/day2.rpy:1954
translate Paloslios day2_kiss_ending_addaf1fc:

    # "Jim suddenly pulls away from you, like he's been touched by fire."
    "Jim de repente se aleja de ti, como si hubiera sido tocado por fuego."

# game/day2.rpy:1956
translate Paloslios day2_kiss_ending_25edd202:

    # j "I have to go."
    j "Tengo que irme."

# game/day2.rpy:1960
translate Paloslios day2_kiss_ending_3ed4d1da:

    # "He begins grabbing his heavy winter clothes and heads for the door."
    "Comienza a agarrar su pesada ropa de invierno y se dirige hacia la puerta."

# game/day2.rpy:1962
translate Paloslios day2_kiss_ending_33176867:

    # "You reach out to him, but he gives you a dangerous look."
    "Te acercas a él, pero él te lanza una mirada peligrosa."

# game/day2.rpy:1963
translate Paloslios day2_kiss_ending_5a2ec0d3:

    # j "Don't follow me."
    j "No me sigas."

# game/day2.rpy:1967
translate Paloslios day2_kiss_ending_3a48bd00:

    # "He leaves the cabin, the door slamming behind him. The door clicks shut behind him and there's a beat of silence."
    "Sale de la cabaña, la puerta se cierra de golpe detrás de él. La puerta se cierra detrás de él y hay un momento de silencio."

# game/day2.rpy:1969
translate Paloslios day2_kiss_ending_054c16c7:

    # "Then- the unmistakable click of a lock engaging."
    "Luego, el inconfundible clic de una cerradura al abrirse."

# game/day2.rpy:1978
translate Paloslios day2_kiss_menu_5b1bef78:

    # "You're reaching for the door before you realize it. The handle is cold under your palm, the metal biting into your skin as you twist it."
    "Estás alcanzando la puerta antes de que te des cuenta. El mango está frío bajo la palma de tu mano y el metal te muerde la piel cuando lo giras."

# game/day2.rpy:1979
translate Paloslios day2_kiss_menu_e6357672:

    # "It doesn't budge."
    "No se mueve."

# game/day2.rpy:1984
translate Paloslios day2_kiss_menu_088a8852:

    # "You rattle it harder, throwing your weight against the wood."
    "Lo sacudes más fuerte, lanzando tu peso contra la madera."

# game/day2.rpy:1985
translate Paloslios day2_kiss_menu_e29f21e0:

    # "Nothing. The door doesn't even shake in its frame- it's solid, stubborn, like the trees outside that have spent decades digging their roots deep into the earth."
    "Nada. La puerta ni siquiera tiembla en su marco: es sólida, tenaz, como los árboles de afuera que han pasado décadas cavando sus raíces profundamente en la tierra."

# game/day2.rpy:1992
translate Paloslios day2_kiss_menu_ea8371e1:

    # "It's a double-sided deadbolt. Jim has locked you in the cabin for the night."
    "Es un cerrojo de doble cara. Jim te ha encerrado en la cabaña por la noche."

# game/day2.rpy:1998
translate Paloslios day2_kiss_menu_e902cf0b:

    # "Through the window, you see Jim's retreating figure, his shoulders hunched against the wind and snow."
    "A través de la ventana, ves la figura de Jim alejándose, con los hombros encorvados contra el viento y la nieve."

# game/day2.rpy:1999
translate Paloslios day2_kiss_menu_1bbe667f:

    # "It looks like he's holding something."
    "Parece que está sosteniendo algo."

# game/day2.rpy:2000
translate Paloslios day2_kiss_menu_1db8c335:

    # "He doesn't look back."
    "Él no mira hacia atrás."

# game/day2.rpy:2007
translate Paloslios day2_kiss_menu_3ed530b5:

    # "You hear a distant axe hitting wood outside- over and over and over."
    "Escuchas un hacha distante golpeando madera afuera, una y otra vez."

# game/day2.rpy:2009
translate Paloslios day2_kiss_menu_835cd373:

    # "The night stretches on. And Jim's touch lingers like a brand."
    "La noche se prolonga. Y el toque de Jim permanece como una marca."

# game/day2.rpy:2010
translate Paloslios day2_kiss_menu_4a1d2009:

    # "And Jim seems to have no intention of returning tonight."
    "Y Jim parece no tener intención de regresar esta noche."

# game/day2.rpy:2014
translate Paloslios day2_kiss_menu_5bb6717f:

    # "With nothing else to do, you head back to your room."
    "Sin nada más que hacer, regresas a tu habitación."

# game/day2.rpy:2023
translate Paloslios day2_kiss_menu_aba9173f:

    # "You lay back down in your bed, filled with thoughts of Jim, but you're eyes grow heavy with sleep."
    "Te recuestas en tu cama, pensando en Jim, pero tus ojos se vuelven pesados por el sueño."

# game/day2.rpy:2032
translate Paloslios day2_dream_8074025e:

    # "The storm murmurs against the windows, a lullaby of wind and creaking wood. You drift into sleep and the dream comes like a whisper."
    "La tormenta murmura contra las ventanas, una canción de cuna de viento y madera crujiente. Te quedas dormido y el sueño llega como un susurro."

# game/day2.rpy:2036
translate Paloslios day2_dream_7e224407:

    # "You stand in a cathedral of snow-laden trees, their branches clawing at a sky as deep as oblivion."
    "Te encuentras en una catedral de árboles cargados de nieve, con sus ramas arañando un cielo tan profundo como el olvido."

# game/day2.rpy:2037
translate Paloslios day2_dream_c6980fe5:

    # "The air smells of frost and something older- moss, blood, burnt sugar."
    "El aire huele a escarcha y a algo viejo: musgo, sangre, azúcar quemada."

# game/day2.rpy:2039
translate Paloslios day2_dream_7f4cadbf:

    # "In the cracks between trees, you think you see a large wooden carving watching you. Waiting."
    "En las grietas entre los árboles, crees ver una gran talla de madera mirándote. Espera."

# game/day2.rpy:2041
translate Paloslios day2_dream_311e4be3:

    # "The carving around your neck tightens and drives you forward."
    "La talla alrededor de tu cuello te aprieta y te impulsa hacia adelante."

# game/day2.rpy:2043
translate Paloslios day2_dream_6f24b16d:

    # "The wind howls louder, rattling the trees like something begging to be let in."
    "El viento aúlla más fuerte, sacudiendo los árboles como si algo rogara que lo dejaran entrar."

# game/day2.rpy:2048
translate Paloslios day2_dream_27cbb694:

    # "Before you is a path of white flowers, like piles of snowfall."
    "Ante ti hay un camino de flores blancas, como montones de nieve."

# game/day2.rpy:2049
translate Paloslios day2_dream_7bf0251c:

    # "Their silver veins pulse in time with your heartbeat. One brushes your ankle- familiar, possessive."
    "Sus venas plateadas pulsan al ritmo de los latidos de tu corazón. Uno te roza el tobillo: familiar, posesivo."

# game/day2.rpy:2051
translate Paloslios day2_dream_886fff3e:

    # "Before you is bare earth. The ground twitches where your shadow falls."
    "Ante ti hay tierra desnuda. El suelo se contrae donde cae tu sombra."

# game/day2.rpy:2052
translate Paloslios day2_dream_1f5a3be9:

    # "You feel something between your teeth and when you pick it out-"
    "Sientes algo entre tus dientes y cuando lo sacas-"

# game/day2.rpy:2053
translate Paloslios day2_dream_0f6678f4:

    # "-a white flower, moist from your insides, silver veins throb mockingly at you."
    "-una flor blanca, húmeda por tus entrañas, las venas plateadas palpitan burlonamente hacia ti."

# game/day2.rpy:2055
translate Paloslios day2_dream_f752880b:

    # "You don't recall their name, yet your tongue forms the shape of it anyway."
    "No recuerdas su nombre, pero tu lengua toma su forma de todos modos."

# game/day2.rpy:2056
translate Paloslios day2_dream_d42b242b:

    # "Moonpetals. Is that what they're called? How do you know?"
    "Pétalos de luna. ¿Así se llaman? ¿Cómo lo sabes?"

# game/day2.rpy:2059
translate Paloslios day2_dream_460a82f8:

    # "There are wolf tracks. Deep, deliberate."
    "Hay huellas de lobos. Profundo, deliberado."

# game/day2.rpy:2061
translate Paloslios day2_dream_acbf962c:

    # "You whirl to flee in the other direction, but the woods stretch into the horizon."
    "Te giras para huir en la otra dirección, pero el bosque se extiende hasta el horizonte."

# game/day2.rpy:2063
translate Paloslios day2_dream_f58d493c:

    # "They lead you forward without a choice, the trees seemly curving into you, pulling you in."
    "Te llevan hacia adelante sin opción, los árboles aparentemente se curvan hacia ti, atrayéndote."

# game/day2.rpy:2066
translate Paloslios day2_dream_ad18fe63:

    # "Something moves in the dark. Not a wolf. Not a man. A shape with too many joints, its shadow stretching farther than the light should allow."
    "Algo se mueve en la oscuridad. No un lobo. No un hombre. Una forma con demasiadas articulaciones, cuya sombra se extiende más de lo que debería permitir la luz."

# game/day2.rpy:2069
translate Paloslios day2_dream_0993a429:

    # "And those eyes- they glow impossibly bright, drinking up the shadows."
    "Y esos ojos... brillan increíblemente brillantes, bebiendo las sombras."

# game/day2.rpy:2070
translate Paloslios day2_dream_19d15669:

    # "A voice hums. Jim's voice? No. Deeper. It curls through the trees in fragments."
    "Una voz tararea. ¿La voz de Jim? No. Más profundo. Se enrosca entre los árboles en fragmentos."

# game/day2.rpy:2088
translate Paloslios day2_dream_334753d4:

    # "Your palm grows heavy. You unclench your fist to reveal-"
    "Tu palma se vuelve pesada. Abre el puño para revelar-"

# game/day2.rpy:2091
translate Paloslios day2_dream_51479d5b:

    # "A bone-handled knife, its edge serrated with thorns."
    "Un cuchillo con mango de hueso y el filo dentado por espinas."

# game/day2.rpy:2092
translate Paloslios day2_dream_7d0b20ef:

    # "Its mouth doesn't move. The words form inside your skull."
    "Su boca no se mueve. Las palabras se forman dentro de tu cráneo."

# game/day2.rpy:2114
translate Paloslios day2_dream_f55d5b36:

    # "The wind lashes your face- full of teeth."
    "El viento azota tu cara llena de dientes."

# game/day2.rpy:2116
translate Paloslios day2_dream_c138e6ea:

    # "It's a moonpetal, pressed and dried. It pulses in your hand with secret life."
    "Es un pétalo de luna, prensado y secado. Pulsa en tu mano con vida secreta."

# game/day2.rpy:2117
translate Paloslios day2_dream_6ac88a94:

    # "Its mouth doesn't move. The words echoing off of the trees."
    "Su boca no se mueve. Las palabras resonando entre los árboles."

# game/day2.rpy:2140
translate Paloslios day2_dream_12cf2b5a:

    # "The flower convulses and roots into your skin. You hiss through your teeth as it claws inside."
    "La flor convulsiona y se arraiga en tu piel. Silbas entre dientes mientras se clava en el interior."

# game/day2.rpy:2142
translate Paloslios day2_dream_d631f7b0:

    # "It's a moonpetal, now fully bloomed, its center is a perfect black pupil."
    "Es un pétalo de luna, ahora completamente florecido, su centro es una pupila negra perfecta."

# game/day2.rpy:2143
translate Paloslios day2_dream_4231770d:

    # "Its mouth doesn't move. The words bloom from behind your ribs."
    "Su boca no se mueve. Las palabras brotan de detrás de tus costillas."

# game/day2.rpy:2165
translate Paloslios day2_dream_e452d75a:

    # "The figure laughs, and the sound is Jim's- warped, delighted."
    "La figura se ríe y el sonido es el de Jim, retorcido y encantado."

# game/day2.rpy:2167
translate Paloslios day2_dream_a7a22df9:

    # "The flower roots into your skin. It doesn't hurt. That's worse."
    "La flor se arraiga en tu piel. No duele. Eso es peor."

# game/kinetic_text_tags.rpy:1
translate Paloslios 6c0c3176:

    # "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "Etiquetas de texto cinético Módulo Ren'Py 2021 Daniel Westfall <SoDaRa2595@gmail.com>"

# game/kinetic_text_tags.rpy:1
translate Paloslios 8689f4cd:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"
    "http://twitter.com/sodara9 ¡Apreciaría que me den crédito si terminas usándolo! :D ¡Realmente me alegraría el día saber que ayudé a algunas personas! ¡Realmente espero que esto pueda ayudar a la comunidad a crear formas realmente interesantes de darle vida a su diálogo! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Publicación en el foro: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"

# game/script.rpy:977
translate Paloslios thestart_e820e6b1:

    # "You find yourself in a room with various objects."
    "Te encuentras en una habitación con varios objetos."

# game/script.rpy:982
translate Paloslios thestart_677cacf3:

    # "The room contains several interesting items."
    "La sala contiene varios elementos interesantes."

# game/script.rpy:985
translate Paloslios thestart_15621518:

    # "You check your current collection of items."
    "Verifica su colección actual de artículos."

translate Paloslios thestart_2f2f3f3c:

    "The cage is beautiful because it was built just for you."