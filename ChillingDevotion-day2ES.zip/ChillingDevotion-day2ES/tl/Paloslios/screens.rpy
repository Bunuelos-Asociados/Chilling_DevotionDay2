﻿# TODO: Translation updated at 2025-12-06 19:21

translate Paloslios strings:

    # game/screens.rpy:252
    old "Back"
    new "Volver"

    # game/screens.rpy:253
    old "History"
    new "Historial"
    # game/screens.rpy:254
    old "Skip"
    new "Saltar"

    # game/screens.rpy:255
    old "Auto"
    new "Auto"

    # game/screens.rpy:256
    old "Save"
    new "Guardar"

    # game/screens.rpy:257
    old "Q.Save"
    new "Q.Guardar"
    # game/screens.rpy:258
    old "Q.Load"
    new "Q.Cargar"

    # game/screens.rpy:259
    old "Prefs"
    new "Preferencias"
    # game/screens.rpy:300
    old "Start"
    new "Iniciar"

    # game/screens.rpy:308
    old "Load"
    new "Cargar"
    # game/screens.rpy:310
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:314
    old "End Replay"
    new "Terminar Repetición"

    # game/screens.rpy:318
    old "Main Menu"
    new "Menú Principal"

    # game/screens.rpy:320
    old "About"
    new "Acerca de"
    # game/screens.rpy:325
    old "Help"
    new "Ayuda"

    # game/screens.rpy:331
    old "Quit"
    new "Salir"
    # game/screens.rpy:631
    old "Return"
    new "Regresar"

    # game/screens.rpy:715
    old "Version [config.version!t]\n"
    new "Version [config.version!t]\n"

    # game/screens.rpy:721
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]\n"
    new "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]\n"

    # game/screens.rpy:723
    old "Art, Writing, and Coding: {a=https://linktr.ee/hereisremina/}Hereisremina{/a}\n"
    new "Art, Writing, and Coding: {a=https://linktr.ee/hereisremina/}Hereisremina{/a}\n"

    # game/screens.rpy:725
    old "Some code: {a=https://farzher.com/}Farzher{/a}\n"
    new "Some code: {a=https://farzher.com/}Farzher{/a}\n"

    # game/screens.rpy:727
    old "Music: {a=https://x.com/DamianWinters_}Damian Winters{/a}\n"
    new "Music: {a=https://x.com/DamianWinters_}Damian Winters{/a}\n"

    # game/screens.rpy:729
    old "Sound: {a=https://pixabay.com/music/}Pixabay{/a}\n"
    new "Sound: {a=https://pixabay.com/music/}Pixabay{/a}\n"

    # game/screens.rpy:767
    old "Page {}"
    new "Page {}"

    # game/screens.rpy:767
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:767
    old "Quick saves"
    new "Guardados rápidos"
    # game/screens.rpy:809
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:809
    old "empty slot"
    new "ranura vacía"

    # game/screens.rpy:829
    old "<"
    new "<"

    # game/screens.rpy:833
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:836
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:842
    old ">"
    new ">"

    # game/screens.rpy:847
    old "Upload Sync"
    new "Subir Sincronización"

    # game/screens.rpy:851
    old "Download Sync"
    new "Descargar Sincronización"
    # game/screens.rpy:910
    old "Display"
    new "Pantalla"

    # game/screens.rpy:911
    old "Window"
    new "Ventana"
    # game/screens.rpy:912
    old "Fullscreen"
    new "Pantalla Completa"

    # game/screens.rpy:917
    old "Unseen Text"
    new "Texto No Visto"
    # game/screens.rpy:918
    old "After Choices"
    new "Después de las Elecciones"

    # game/screens.rpy:919
    old "Transitions"
    new "Transiciones"
    # game/screens.rpy:932
    old "Text Speed"
    new "Velocidad del Texto"

    # game/screens.rpy:936
    old "Auto-Forward Time"
    new "Tiempo de Avance Automático"
    # game/screens.rpy:943
    old "Music Volume"
    new "Volumen de Música"

    # game/screens.rpy:950
    old "Sound Volume"
    new "Volumen de Sonido"
    # game/screens.rpy:956
    old "Test"
    new "Probar"

    # game/screens.rpy:960
    old "Voice Volume"
    new "Volumen de Voz"
    # game/screens.rpy:971
    old "Mute All"
    new "Silenciar Todo"

    # game/screens.rpy:1090
    old "The dialogue history is empty."
    new "El historial de diálogo está vacío."

    # game/screens.rpy:1158
    old "Keyboard"
    new "Teclado"
    # game/screens.rpy:1159
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1162
    old "Gamepad"
    new "Gamepad"

    # game/screens.rpy:1175
    old "Enter"
    new "Enter"

    # game/screens.rpy:1176
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."
    # game/screens.rpy:1179
    old "Space"
    new "Space"

    # game/screens.rpy:1180
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1183
    old "Arrow Keys"
    new "Teclas de Flecha"
    # game/screens.rpy:1184
    old "Navigate the interface."
    new "Navegar por la interfaz."

    # game/screens.rpy:1187
    old "Escape"
    new "Escape"

    # game/screens.rpy:1188
    old "Accesses the game menu."
    new "Accede al menú del juego."
    # game/screens.rpy:1191
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1192
    old "Skips dialogue while held down."
    new "Skips dialogue while held down."

    # game/screens.rpy:1195
    old "Tab"
    new "Tab"

    # game/screens.rpy:1196
    old "Toggles dialogue skipping."
    new "Toggles dialogue skipping."

    # game/screens.rpy:1199
    old "Page Up"
    new "Page Up"

    # game/screens.rpy:1200
    old "Rolls back to earlier dialogue."
    new "Rolls back to earlier dialogue."

    # game/screens.rpy:1203
    old "Page Down"
    new "Page Down"

    # game/screens.rpy:1204
    old "Rolls forward to later dialogue."
    new "Rolls forward to later dialogue."

    # game/screens.rpy:1208
    old "Hides the user interface."
    new "Hides the user interface."

    # game/screens.rpy:1212
    old "Takes a screenshot."
    new "Takes a screenshot."

    # game/screens.rpy:1216
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."

    # game/screens.rpy:1220
    old "Opens the accessibility menu."
    new "Opens the accessibility menu."

    # game/screens.rpy:1226
    old "Left Click"
    new "Left Click"

    # game/screens.rpy:1230
    old "Middle Click"
    new "Middle Click"

    # game/screens.rpy:1234
    old "Right Click"
    new "Right Click"

    # game/screens.rpy:1238
    old "Mouse Wheel Up"
    new "Mouse Wheel Up"

    # game/screens.rpy:1242
    old "Mouse Wheel Down"
    new "Mouse Wheel Down"

    # game/screens.rpy:1249
    old "Right Trigger\nA/Bottom Button"
    new "Right Trigger\nA/Bottom Button"

    # game/screens.rpy:1253
    old "Left Trigger\nLeft Shoulder"
    new "Left Trigger\nLeft Shoulder"

    # game/screens.rpy:1257
    old "Right Shoulder"
    new "Right Shoulder"

    # game/screens.rpy:1261
    old "D-Pad, Sticks"
    new "D-Pad, Sticks"

    # game/screens.rpy:1265
    old "Start, Guide, B/Right Button"
    new "Start, Guide, B/Right Button"

    # game/screens.rpy:1269
    old "Y/Top Button"
    new "Y/Top Button"

    # game/screens.rpy:1272
    old "Calibrate"
    new "Calibrate"

    # game/screens.rpy:1337
    old "Yes"
    new "Sí"

    # game/screens.rpy:1338
    old "No"
    new "No"

    # game/screens.rpy:1384
    old "Skipping"
    new "Skipping"

    # game/screens.rpy:1696
    old "Menu"
    new "Menu"

translate es strings:
    old "old:1765066879.215638_9"
    new "new:1765066879.215638_9"

    old "dialogue"
    new "dialogue"

    old "subtitle"
    new "subtitle"

    old "keyboard"
    new "keyboard"

    old "interface"
    new "interface"

    old "preferences"
    new "preferences"

    old "horizontal"
    new "horizontal"

    old "navigation"
    new "navigation"

    old "fullscreen"
    new "fullscreen"

    old "hyperlink"
    new "hyperlink"

    old "Are you sure?"
    new "¿Estás seguro?"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "¿Estás seguro de que quieres eliminar esta partida guardada?"
    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "¿Estás seguro de que quieres sobrescribir tu partida guardada?"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "La carga perderá el progreso no guardado.\n¿Estás seguro de que quieres hacer esto?"

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "¿Estás seguro de que quieres continuar donde lo dejaste?"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "¿Estás seguro de que quieres terminar la repetición?"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "¿Estás seguro de que quieres comenzar a saltar?"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "¿Estás seguro de que quieres saltar a la siguiente opción?"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "¿Estás seguro de que quieres saltar el diálogo no visto hasta la siguiente opción?"
    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Esta partida guardada se creó en un dispositivo diferente. Los archivos de guardado maliciosamente construidos pueden dañar su computadora. ¿Confía en el creador de esta partida guardada y en todos los que podrían haber cambiado el archivo?"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "¿Confía en el dispositivo en el que se creó la partida guardada? Solo debe elegir sí si es el único usuario del dispositivo."

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "No se pudo guardar la captura de pantalla como %s."

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "Captura de pantalla guardada como %s."
    # renpy/common/00library.rpy:248
    old "Skip Mode"
    new "Modo de salto"
 
    old "Unexpected Guest"
    new "Un invitado inesperado"

    old "Day 1"
    new "Dia 1"

    old "Day 2"
    new "Dia 2"

